package com.jarvis.app

import android.app.Application

class ClithelApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Diag.install(this)
    }
}
