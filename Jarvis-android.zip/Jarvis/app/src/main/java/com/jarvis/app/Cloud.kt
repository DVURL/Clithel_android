package com.jarvis.app

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AccountUi(
    val enabled: Boolean = false,
    val signedIn: Boolean = false,
    val email: String = "",
    val skipped: Boolean = false,
    val busy: Boolean = false,
    val message: String = "",
)

class CloudException(message: String) : Exception(message)

/**
 * Cuenta de usuario y copia de la memoria en Firebase (Authentication + Firestore), por REST.
 * La configuración (apiKey y projectId) se lee de assets/cloud.json.
 */
class CloudSync(
    private val ctx: Context,
    private val dao: MemoryDao,
    private val appPrefs: SharedPreferences,
) {
    private val prefs = ctx.getSharedPreferences("cloud", Context.MODE_PRIVATE)
    private val http = OkHttpClient.Builder().callTimeout(30, TimeUnit.SECONDS).build()
    private val json = "application/json".toMediaType()

    private val apiKey: String
    private val projectId: String
    val enabled: Boolean

    init {
        var k = ""
        var p = ""
        try {
            val o = JSONObject(ctx.assets.open("cloud.json").bufferedReader().use { it.readText() })
            k = o.optString("apiKey").trim()
            p = o.optString("projectId").trim()
        } catch (_: Exception) {
        }
        apiKey = k
        projectId = p
        enabled = k.isNotBlank() && p.isNotBlank()
    }

    fun signedIn(): Boolean = prefs.getString("refresh", "").orEmpty().isNotBlank()

    fun ui(): AccountUi = AccountUi(
        enabled = enabled,
        signedIn = signedIn(),
        email = prefs.getString("email", "").orEmpty(),
        skipped = appPrefs.getBoolean("auth_skipped", false),
    )

    private fun friendly(msg: String): String = when {
        msg.startsWith("EMAIL_EXISTS") -> "Ese correo ya tiene una cuenta. Inicia sesión."
        msg.startsWith("INVALID_LOGIN_CREDENTIALS") || msg.startsWith("INVALID_PASSWORD") ||
            msg.startsWith("EMAIL_NOT_FOUND") -> "Correo o contraseña incorrectos."
        msg.startsWith("INVALID_EMAIL") -> "El correo no es válido."
        msg.startsWith("MISSING_EMAIL") -> "Escribe tu correo."
        msg.startsWith("MISSING_PASSWORD") -> "Escribe tu contraseña."
        msg.startsWith("WEAK_PASSWORD") -> "La contraseña debe tener al menos 6 caracteres."
        msg.startsWith("TOO_MANY_ATTEMPTS") -> "Demasiados intentos. Espera unos minutos."
        msg.startsWith("OPERATION_NOT_ALLOWED") -> "El inicio de sesión con correo no está activado en Firebase."
        msg.startsWith("USER_DISABLED") -> "Esta cuenta está desactivada."
        msg.startsWith("CREDENTIAL_TOO_OLD") || msg.startsWith("TOKEN_EXPIRED") ->
            "Por seguridad, cierra sesión, vuelve a entrar y repite la acción."
        msg.contains("API key not valid", ignoreCase = true) || msg.startsWith("API_KEY_INVALID") ->
            "La configuración de la nube no es válida."
        else -> "No pude completar la acción ($msg)."
    }

    private fun post(url: String, body: JSONObject): JSONObject {
        val req = Request.Builder().url(url).post(body.toString().toRequestBody(json)).build()
        http.newCall(req).execute().use { res ->
            val text = res.body?.string().orEmpty()
            val obj = try { JSONObject(text) } catch (_: Exception) { JSONObject() }
            if (!res.isSuccessful) {
                val m = obj.optJSONObject("error")?.optString("message").orEmpty()
                throw CloudException(friendly(m.ifBlank { "HTTP ${res.code}" }))
            }
            return obj
        }
    }

    private fun storeSession(o: JSONObject, email: String) {
        val expires = o.optString("expiresIn", "3600").toLongOrNull() ?: 3600L
        prefs.edit()
            .putString("idToken", o.getString("idToken"))
            .putString("refresh", o.getString("refreshToken"))
            .putString("uid", o.getString("localId"))
            .putString("email", email)
            .putLong("exp", System.currentTimeMillis() + (expires - 60) * 1000)
            .apply()
    }

    /** Token vigente; lo renueva si ya venció. */
    private fun idToken(): String {
        val tok = prefs.getString("idToken", "").orEmpty()
        if (tok.isNotBlank() && System.currentTimeMillis() < prefs.getLong("exp", 0L)) return tok
        val refresh = prefs.getString("refresh", "").orEmpty()
        if (refresh.isBlank()) throw CloudException("Sesión cerrada.")
        val form = FormBody.Builder()
            .add("grant_type", "refresh_token")
            .add("refresh_token", refresh)
            .build()
        val req = Request.Builder()
            .url("https://securetoken.googleapis.com/v1/token?key=$apiKey")
            .post(form)
            .build()
        http.newCall(req).execute().use { res ->
            val text = res.body?.string().orEmpty()
            if (!res.isSuccessful) throw CloudException("No pude renovar tu sesión. Inicia sesión otra vez.")
            val o = JSONObject(text)
            val newTok = o.getString("id_token")
            val expires = o.optString("expires_in", "3600").toLongOrNull() ?: 3600L
            prefs.edit()
                .putString("idToken", newTok)
                .putString("refresh", o.optString("refresh_token", refresh))
                .putLong("exp", System.currentTimeMillis() + (expires - 60) * 1000)
                .apply()
            return newTok
        }
    }

    private fun docUrl(uid: String) =
        "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/users/$uid"

    // ---------- Cuenta ----------

    suspend fun signUp(email: String, pass: String): String? = withContext(Dispatchers.IO) {
        if (!enabled) return@withContext "La nube no está configurada."
        try {
            val o = post(
                "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$apiKey",
                JSONObject().put("email", email).put("password", pass).put("returnSecureToken", true),
            )
            storeSession(o, email)
            try { upload() } catch (_: Exception) { } // la memoria local pasa a la cuenta nueva
            null
        } catch (e: CloudException) {
            e.message
        }
    }

    suspend fun signIn(email: String, pass: String): String? = withContext(Dispatchers.IO) {
        if (!enabled) return@withContext "La nube no está configurada."
        try {
            val o = post(
                "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=$apiKey",
                JSONObject().put("email", email).put("password", pass).put("returnSecureToken", true),
            )
            storeSession(o, email)
            try {
                restoreOrUpload()
                null
            } catch (_: Exception) {
                "Entraste, pero no pude cargar tu memoria. Prueba \"Sincronizar ahora\" en Ajustes."
            }
        } catch (e: CloudException) {
            e.message
        }
    }

    /** Devuelve un mensaje de error, o null si se envió el correo. */
    suspend fun sendReset(email: String): String? = withContext(Dispatchers.IO) {
        if (!enabled) return@withContext "La nube no está configurada."
        try {
            post(
                "https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=$apiKey",
                JSONObject().put("requestType", "PASSWORD_RESET").put("email", email),
            )
            null
        } catch (e: CloudException) {
            e.message
        }
    }

    suspend fun signOut() = withContext(Dispatchers.IO) {
        try { upload() } catch (_: Exception) { }
        // Limpiar lo local para que la siguiente persona no vea tu memoria
        dao.habits().forEach {
            HabitScheduler.cancel(ctx, it.id)
            dao.deleteHabit(it.id)
        }
        dao.clearFacts()
        dao.clearMsgs()
        appPrefs.edit().remove("name").apply()
        prefs.edit().clear().apply()
        Unit
    }

    suspend fun deleteAccount(): String? = withContext(Dispatchers.IO) {
        try {
            val uid = prefs.getString("uid", "").orEmpty()
            val token = idToken()
            http.newCall(
                Request.Builder().url(docUrl(uid)).header("Authorization", "Bearer $token").delete().build()
            ).execute().close()
            post(
                "https://identitytoolkit.googleapis.com/v1/accounts:delete?key=$apiKey",
                JSONObject().put("idToken", token),
            )
            signOut()
            null
        } catch (e: CloudException) {
            e.message
        }
    }

    // ---------- Memoria en la nube ----------

    private suspend fun snapshot(): String {
        val o = JSONObject()
        o.put("v", 1)
        o.put("name", appPrefs.getString("name", "").orEmpty())

        val facts = JSONArray()
        dao.facts().forEach { facts.put(JSONObject().put("text", it.text).put("at", it.createdAt)) }
        o.put("facts", facts)

        val habits = JSONArray()
        dao.habits().forEach {
            habits.put(
                JSONObject().put("title", it.title).put("hour", it.hour).put("minute", it.minute)
                    .put("days", it.days).put("enabled", it.enabled)
            )
        }
        o.put("habits", habits)

        val msgs = JSONArray()
        dao.lastMsgs(60).reversed().forEach {
            msgs.put(JSONObject().put("role", it.role).put("text", it.text).put("at", it.createdAt))
        }
        o.put("msgs", msgs)

        val t = ThemeStore.load(ctx)
        o.put(
            "theme",
            JSONObject().put("palette", t.paletteId).put("hue", t.hue)
                .put("bg", if (t.bg == "imagen") "negro" else t.bg),
        )
        return o.toString()
    }

    suspend fun upload(): Unit = withContext(Dispatchers.IO) {
        if (!enabled || !signedIn()) return@withContext
        val uid = prefs.getString("uid", "").orEmpty()
        val body = JSONObject().put(
            "fields",
            JSONObject()
                .put("data", JSONObject().put("stringValue", snapshot()))
                .put("updatedAt", JSONObject().put("integerValue", System.currentTimeMillis().toString())),
        )
        val req = Request.Builder()
            .url(docUrl(uid))
            .header("Authorization", "Bearer ${idToken()}")
            .patch(body.toString().toRequestBody(json))
            .build()
        http.newCall(req).execute().use { res ->
            if (!res.isSuccessful) throw CloudException("HTTP ${res.code}")
        }
        Unit
    }

    private suspend fun restoreOrUpload() {
        val uid = prefs.getString("uid", "").orEmpty()
        val req = Request.Builder()
            .url(docUrl(uid))
            .header("Authorization", "Bearer ${idToken()}")
            .get()
            .build()
        var data: String? = null
        var missing = false
        http.newCall(req).execute().use { res ->
            if (res.code == 404) {
                missing = true
            } else {
                if (!res.isSuccessful) throw CloudException("HTTP ${res.code}")
                val doc = JSONObject(res.body?.string().orEmpty())
                data = doc.getJSONObject("fields").getJSONObject("data").getString("stringValue")
            }
        }
        if (missing) {
            upload()
        } else {
            data?.let { applySnapshot(JSONObject(it)) }
        }
    }

    private suspend fun applySnapshot(o: JSONObject) {
        appPrefs.edit().putString("name", o.optString("name")).apply()

        dao.habits().forEach {
            HabitScheduler.cancel(ctx, it.id)
            dao.deleteHabit(it.id)
        }
        dao.clearFacts()
        dao.clearMsgs()

        o.optJSONArray("facts")?.let { a ->
            for (i in 0 until a.length()) {
                val f = a.getJSONObject(i)
                dao.addFact(Fact(text = f.getString("text"), createdAt = f.optLong("at", System.currentTimeMillis())))
            }
        }
        o.optJSONArray("msgs")?.let { a ->
            for (i in 0 until a.length()) {
                val m = a.getJSONObject(i)
                dao.addMsg(
                    Msg(role = m.getString("role"), text = m.getString("text"), createdAt = m.optLong("at", System.currentTimeMillis()))
                )
            }
        }
        o.optJSONArray("habits")?.let { a ->
            for (i in 0 until a.length()) {
                val h = a.getJSONObject(i)
                val habit = Habit(
                    title = h.getString("title"),
                    hour = h.optInt("hour"),
                    minute = h.optInt("minute"),
                    days = h.optString("days", ""),
                    enabled = h.optBoolean("enabled", true),
                )
                val id = dao.addHabit(habit)
                if (habit.enabled) HabitScheduler.schedule(ctx, habit.copy(id = id))
            }
        }
        o.optJSONObject("theme")?.let { t ->
            val cur = ThemeStore.load(ctx)
            ThemeStore.save(
                ctx,
                cur.copy(
                    paletteId = t.optString("palette", cur.paletteId),
                    hue = t.optInt("hue", cur.hue),
                    bg = t.optString("bg", cur.bg),
                ),
            )
        }
    }
}
