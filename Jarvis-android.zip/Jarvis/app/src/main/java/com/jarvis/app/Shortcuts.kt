package com.jarvis.app

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale

/** Normaliza texto: minúsculas, sin acentos ni signos. "Música!" -> "musica" */
object Norm {
    private val marks = Regex("\\p{InCombiningDiacriticalMarks}+")
    private val symbols = Regex("[^a-z0-9 ]")
    private val spaces = Regex("\\s+")

    fun of(s: String): String {
        val d = Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        return d.replace(marks, "").replace(symbols, " ").replace(spaces, " ").trim()
    }
}

/** Etiqueta que el usuario le pone a una app: "billar" -> 8 Ball Pool. */
data class AppAlias(val alias: String, val pkg: String, val label: String)

data class AppEntry(val label: String, val pkg: String)

object AliasStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("aliases", Context.MODE_PRIVATE)

    fun load(ctx: Context): List<AppAlias> {
        val s = prefs(ctx).getString("list", null) ?: return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                AppAlias(o.getString("alias"), o.getString("pkg"), o.optString("label", o.getString("pkg")))
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<AppAlias>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("alias", it.alias).put("pkg", it.pkg).put("label", it.label)) }
        prefs(ctx).edit().putString("list", a.toString()).apply()
    }

    fun find(ctx: Context, name: String): AppAlias? {
        val n = Norm.of(name)
        if (n.isEmpty()) return null
        return load(ctx).firstOrNull { Norm.of(it.alias) == n }
    }
}

/** Lista de apps instaladas que se pueden abrir. */
object AppCatalog {
    fun list(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(main, 0)
            .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != ctx.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }
}

/** Atajos locales: "abre billar" no necesita internet ni Gemini. */
object Shortcuts {
    private val VERBS = setOf(
        "abre", "abrir", "abreme", "abrime", "entra", "entrar", "inicia", "iniciar",
        "lanza", "lanzar", "ejecuta", "ejecutar", "ponme", "pon", "ve", "vamos",
        "llevame", "quiero", "necesito", "puedes", "podrias",
    )
    private val FILLERS = setOf(
        "a", "al", "en", "la", "el", "los", "las", "mi", "mis", "aplicacion", "aplicaciones",
        "app", "apps", "de", "del", "por", "favor", "abrir", "entrar", "ver", "jugar", "usar",
        "un", "una", "me", "te",
    )

    fun match(text: String, aliases: List<AppAlias>, selfName: String): AppAlias? {
        if (aliases.isEmpty()) return null
        var words = Norm.of(text).split(" ").filter { it.isNotEmpty() }
        if (words.isEmpty()) return null

        // "Clithel, abre billar": quitar el nombre del asistente al inicio
        val self = Norm.of(selfName)
        if (self.isNotEmpty() && words.first() == self) words = words.drop(1)
        if (words.isEmpty()) return null

        val byNorm = aliases.associateBy { Norm.of(it.alias) }

        // 1) el texto es solo la etiqueta: "billar"
        byNorm[words.joinToString(" ")]?.let { return it }

        // 2) verbo + relleno + etiqueta: "abre mi aplicación de billar"
        if (words.first() !in VERBS) return null
        val rest = words.drop(1).filter { it !in FILLERS }.joinToString(" ")
        return byNorm[rest]
    }
}
