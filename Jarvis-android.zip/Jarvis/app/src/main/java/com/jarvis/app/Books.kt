package com.jarvis.app

import android.content.Context
import android.net.Uri
import android.text.Html
import android.util.Xml
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.util.zip.ZipFile

/** kind: "pdf", "epub" o "txt". sec/chunk = dónde se quedó; total = número de secciones. */
data class Book(
    val id: String,
    val title: String,
    val uri: String,
    val kind: String,
    val sec: Int = 0,
    val chunk: Int = 0,
    val total: Int = 0,
)

data class ReaderUi(
    val active: Boolean = false,
    val paused: Boolean = false,
    val title: String = "",
    val progress: Int = 0,
    val rate: Float = 1f,
)

object BookStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("books", Context.MODE_PRIVATE)

    fun load(ctx: Context): List<Book> {
        val s = prefs(ctx).getString("list", null) ?: return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Book(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    uri = o.getString("uri"),
                    kind = o.optString("kind", "txt"),
                    sec = o.optInt("sec"),
                    chunk = o.optInt("chunk"),
                    total = o.optInt("total"),
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<Book>) {
        val a = JSONArray()
        list.forEach {
            a.put(
                JSONObject().put("id", it.id).put("title", it.title).put("uri", it.uri).put("kind", it.kind)
                    .put("sec", it.sec).put("chunk", it.chunk).put("total", it.total)
            )
        }
        prefs(ctx).edit().putString("list", a.toString()).apply()
    }

    fun lastId(ctx: Context): String? = prefs(ctx).getString("last", null)

    fun setLast(ctx: Context, id: String) {
        prefs(ctx).edit().putString("last", id).apply()
    }

    fun deleteCache(ctx: Context, id: String) {
        File(ctx.cacheDir, "book_$id.pdf").delete()
        File(ctx.cacheDir, "book_$id.epub").delete()
    }
}

/** Parte textos largos en secciones y en trozos cortos para leerlos de a poco. */
object Chunker {
    private val sentenceEnd = Regex("(?<=[.!?…])\\s+")
    private val blankLine = Regex("\n\\s*\n")
    private val spaces = Regex("\\s+")

    fun sections(text: String, size: Int): List<String> {
        val clean = text.replace("\r\n", "\n").trim()
        if (clean.isEmpty()) return emptyList()
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        for (para in clean.split(blankLine)) {
            val p = para.replace(spaces, " ").trim()
            if (p.isEmpty()) continue
            val pieces = if (p.length > size) chunks(p) else listOf(p)
            for (piece in pieces) {
                if (sb.isNotEmpty() && sb.length + piece.length > size) {
                    out.add(sb.toString())
                    sb.clear()
                }
                if (sb.isNotEmpty()) sb.append("\n\n")
                sb.append(piece)
            }
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    /** Trozos de 300 a 700 caracteres, cortando en frases. */
    fun chunks(section: String): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        fun flush() {
            if (sb.isNotBlank()) out.add(sb.toString().trim())
            sb.clear()
        }
        for (sentence in section.split(sentenceEnd)) {
            var s = sentence.trim()
            if (s.isEmpty()) continue
            while (s.length > 700) {
                val at = s.lastIndexOf(' ', 700)
                val cut = if (at < 200) 700 else at
                flush()
                out.add(s.substring(0, cut).trim())
                s = s.substring(cut).trim()
            }
            if (sb.isNotEmpty() && sb.length + s.length > 700) flush()
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(s)
            if (sb.length >= 300) flush()
        }
        flush()
        return out
    }
}

interface BookSource {
    val count: Int
    fun section(i: Int): String
    fun close() {}
}

private fun copyToCache(ctx: Context, book: Book, ext: String): File {
    val file = File(ctx.cacheDir, "book_${book.id}.$ext")
    if (!file.exists() || file.length() == 0L) {
        ctx.contentResolver.openInputStream(Uri.parse(book.uri))?.use { input ->
            file.outputStream().use { input.copyTo(it) }
        }
    }
    return file
}

class TxtSource(ctx: Context, book: Book) : BookSource {
    private val parts: List<String>

    init {
        val bytes = ctx.contentResolver.openInputStream(Uri.parse(book.uri))?.use { it.readBytes() } ?: ByteArray(0)
        var text = String(bytes, Charsets.UTF_8)
        if (text.count { it == '\uFFFD' } > 5) text = String(bytes, Charsets.ISO_8859_1)
        parts = Chunker.sections(text, 4000)
    }

    override val count: Int get() = parts.size
    override fun section(i: Int): String = parts.getOrElse(i) { "" }
}

class EpubSource(ctx: Context, book: Book) : BookSource {
    private val zip: ZipFile = ZipFile(copyToCache(ctx, book, "epub"))
    private val items: List<String> = readSpine(zip)

    override val count: Int get() = items.size

    override fun section(i: Int): String {
        val path = items.getOrNull(i) ?: return ""
        val entry = zip.getEntry(path) ?: return ""
        val html = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).use { it.readText() }
        return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString().replace('\uFFFC', ' ').trim()
    }

    override fun close() {
        try { zip.close() } catch (_: Exception) { }
    }

    private fun opfPath(zip: ZipFile): String? {
        val e = zip.getEntry("META-INF/container.xml") ?: return null
        val p = Xml.newPullParser()
        p.setInput(zip.getInputStream(e), null)
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            if (p.eventType == XmlPullParser.START_TAG && p.name.substringAfterLast(':') == "rootfile") {
                return p.getAttributeValue(null, "full-path")
            }
        }
        return null
    }

    private fun readSpine(zip: ZipFile): List<String> {
        val opf = opfPath(zip) ?: return emptyList()
        val dir = if (opf.contains("/")) opf.substringBeforeLast("/") + "/" else ""
        val e = zip.getEntry(opf) ?: return emptyList()
        val manifest = mutableMapOf<String, String>()
        val spine = mutableListOf<String>()
        val p = Xml.newPullParser()
        p.setInput(zip.getInputStream(e), null)
        while (p.next() != XmlPullParser.END_DOCUMENT) {
            if (p.eventType != XmlPullParser.START_TAG) continue
            when (p.name.substringAfterLast(':')) {
                "item" -> {
                    val id = p.getAttributeValue(null, "id")
                    val href = p.getAttributeValue(null, "href")
                    if (id != null && href != null) manifest[id] = href
                }
                "itemref" -> p.getAttributeValue(null, "idref")?.let { spine.add(it) }
            }
        }
        return spine.mapNotNull { manifest[it] }.map { dir + Uri.decode(it).substringBefore('#') }
    }
}

class PdfSource(ctx: Context, book: Book) : BookSource {
    private val doc: PDDocument
    private val stripper = PDFTextStripper()

    init {
        PDFBoxResourceLoader.init(ctx.applicationContext)
        doc = PDDocument.load(copyToCache(ctx, book, "pdf"))
        stripper.sortByPosition = true
    }

    override val count: Int get() = doc.numberOfPages

    override fun section(i: Int): String {
        stripper.startPage = i + 1
        stripper.endPage = i + 1
        val raw = stripper.getText(doc)
        return raw
            .replace(Regex("-\\n"), "")
            .replace(Regex("(?<!\\n)\\n(?!\\n)"), " ")
            .replace(Regex("[ \\t]+"), " ")
            .trim()
    }

    override fun close() {
        try { doc.close() } catch (_: Exception) { }
    }
}

object BookSources {
    fun open(ctx: Context, book: Book): BookSource = when (book.kind) {
        "pdf" -> PdfSource(ctx, book)
        "epub" -> EpubSource(ctx, book)
        else -> TxtSource(ctx, book)
    }
}

sealed class ReaderCmd {
    object Pause : ReaderCmd()
    object Resume : ReaderCmd()
    object Faster : ReaderCmd()
    object Slower : ReaderCmd()
    object Back : ReaderCmd()
    object Next : ReaderCmd()
    object Stop : ReaderCmd()
    data class Start(val book: Book) : ReaderCmd()
}

/** Comandos de voz para los libros. Se resuelven en el celular, sin Gemini. */
object ReaderCommands {
    private val PAUSE = setOf("pausa", "pausar", "pausalo", "detente", "alto", "espera", "silencio", "basta", "para")
    private val RESUME = setOf("continua", "continuar", "sigue", "seguir", "reanuda", "reanudar")
    private val RESUME_TAIL = setOf("leyendo", "lectura", "libro", "mi", "el", "con")
    private val BACK = setOf("repite", "repetir", "atras", "anterior")
    private val NEXT = setOf("siguiente", "adelante", "salta", "saltar")
    private val START = setOf("lee", "leer", "leeme", "leerme", "lea", "empieza", "empezar", "comienza", "comenzar")
    private val FILLERS = setOf(
        "me", "mi", "mis", "el", "la", "los", "las", "libro", "libros", "pdf", "epub", "documento", "archivo",
        "en", "voz", "alta", "por", "favor", "un", "una", "a", "que", "de", "del", "lo", "te", "nuevo",
        "lee", "leer", "leeme", "leerme", "lea", "ponme", "quiero", "puedes", "empieza", "empezar",
        "comienza", "comenzar", "podrias", "necesito", "ahora",
    )

    fun find(books: List<Book>, query: String): Book? {
        val q = Norm.of(query)
        if (q.isEmpty()) return null
        val tokens = q.split(" ").filter { it.isNotEmpty() }
        var best: Book? = null
        var bestScore = 0
        for (b in books) {
            val t = Norm.of(b.title)
            val titleTokens = t.split(" ").toSet()
            val score = when {
                t.contains(q) -> 100
                tokens.all { it in titleTokens || t.contains(it) } -> 50 + tokens.size
                else -> 0
            }
            if (score > bestScore) {
                best = b
                bestScore = score
            }
        }
        return best
    }

    fun parse(text: String, books: List<Book>, active: Boolean, lastId: String?, selfName: String): ReaderCmd? {
        var words = Norm.of(text).split(" ").filter { it.isNotEmpty() }
        val self = Norm.of(selfName)
        if (self.isNotEmpty() && words.firstOrNull() == self) words = words.drop(1)
        if (words.isEmpty()) return null
        val joined = words.joinToString(" ")

        if (active) {
            if (joined.contains("deja de leer") || joined.contains("para de leer") ||
                joined.contains("detener lectura") || joined.contains("termina la lectura") ||
                joined.contains("cancela la lectura")
            ) return ReaderCmd.Stop
            if (words.size <= 3 && words.first() in PAUSE) return ReaderCmd.Pause
            if (words.size <= 4 && ("rapido" in words || "acelera" in words || "aceleralo" in words)) return ReaderCmd.Faster
            if (words.size <= 4 && ("lento" in words || "despacio" in words)) return ReaderCmd.Slower
            if (words.size <= 3 && (words.first() in BACK || joined == "otra vez")) return ReaderCmd.Back
            if (words.size <= 2 && words.first() in NEXT) return ReaderCmd.Next
        }

        // "continúa", "sigue leyendo"
        if (words.size <= 3 && words.first() in RESUME && words.drop(1).all { it in RESUME_TAIL }) {
            if (active) return ReaderCmd.Resume
            val last = books.firstOrNull { it.id == lastId } ?: books.singleOrNull()
            return last?.let { ReaderCmd.Start(it) }
        }

        // "léeme mi libro X"
        val wantsRead = words.first() in START ||
            ("leer" in words && words.first() in setOf("ponme", "quiero", "puedes", "podrias", "necesito"))
        if (books.isNotEmpty() && wantsRead) {
            val query = words.filter { it !in FILLERS }.joinToString(" ")
            if (query.isEmpty()) {
                val last = books.firstOrNull { it.id == lastId } ?: books.singleOrNull() ?: books.first()
                return ReaderCmd.Start(last)
            }
            return find(books, query)?.let { ReaderCmd.Start(it) }
        }
        return null
    }
}
