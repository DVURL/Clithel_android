package com.jarvis.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.vosk.Model
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/** Estado de la escucha del nombre, para mostrarlo en Ajustes. */
data class WakeUi(val enabled: Boolean = false, val status: String = "")

/** Modelo de voz en español de Vosk: se descarga una sola vez dentro de la app. */
object VoskModel {
    private val CANDIDATES = listOf("vosk-model-small-es-0.42", "vosk-model-small-es-0.3")
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.MINUTES)
        .build()

    private fun root(ctx: Context) = File(ctx.filesDir, "vosk")

    fun path(ctx: Context): String? =
        root(ctx).listFiles()
            ?.firstOrNull { it.isDirectory && File(it, "am").exists() }
            ?.absolutePath

    fun isReady(ctx: Context): Boolean = path(ctx) != null

    fun load(ctx: Context): Model? = try {
        path(ctx)?.let { Model(it) }
    } catch (_: Throwable) {
        null
    }

    /** Descarga y descomprime el modelo si falta. Devuelve un mensaje de error, o null si todo salió bien. */
    suspend fun ensure(ctx: Context, onProgress: (Int) -> Unit): String? = withContext(Dispatchers.IO) {
        if (isReady(ctx)) return@withContext null
        var lastError = "No pude descargar la voz. Revisa tu internet."
        for (name in CANDIDATES) {
            try {
                val zip = File(ctx.cacheDir, "$name.zip")
                download("https://alphacephei.com/vosk/models/$name.zip", zip, onProgress)
                unzip(zip, root(ctx))
                zip.delete()
                if (isReady(ctx)) return@withContext null
                lastError = "El modelo de voz descargado no es válido."
            } catch (e: Exception) {
                lastError = "No pude descargar la voz (${e.message ?: "error"})."
            }
        }
        lastError
    }

    private fun download(url: String, out: File, onProgress: (Int) -> Unit) {
        http.newCall(Request.Builder().url(url).build()).execute().use { res ->
            if (!res.isSuccessful) throw IOException("HTTP ${res.code}")
            val body = res.body ?: throw IOException("respuesta vacía")
            val total = body.contentLength()
            body.byteStream().use { input ->
                out.outputStream().use { output ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var last = -1
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val p = (done * 100 / total).toInt()
                            if (p != last) {
                                last = p
                                onProgress(p)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun unzip(zip: File, dest: File) {
        dest.mkdirs()
        val destPath = dest.canonicalPath + File.separator
        ZipInputStream(zip.inputStream().buffered()).use { zin ->
            while (true) {
                val entry = zin.nextEntry ?: break
                val out = File(dest, entry.name)
                if (!out.canonicalPath.startsWith(destPath)) throw IOException("Ruta no válida en el zip")
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { zin.copyTo(it) }
                }
                zin.closeEntry()
            }
        }
    }
}
