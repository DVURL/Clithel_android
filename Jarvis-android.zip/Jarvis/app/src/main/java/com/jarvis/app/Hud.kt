package com.jarvis.app

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/** Notificaciones con estilo de panel de control (HUD). */
object Hud {
    private const val CHANNEL = "jarvis_alerts"

    /** target: lo que se abre al tocar; timeoutMs: desaparece sola pasado ese tiempo. */
    @SuppressLint("MissingPermission")
    fun notify(
        ctx: Context,
        id: Int,
        title: String,
        message: String,
        target: PendingIntent? = null,
        timeoutMs: Long = 0L,
    ) {
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return

        val channel = NotificationChannel(CHANNEL, "Avisos de ${Brand.NAME}", NotificationManager.IMPORTANCE_HIGH)
        ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)

        val view = RemoteViews(ctx.packageName, R.layout.notification_hud).apply {
            setTextViewText(R.id.hud_title, title)
            setTextViewText(R.id.hud_message, message)
        }
        val open = target ?: PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setCustomContentView(view)
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
        if (timeoutMs > 0) builder.setTimeoutAfter(timeoutMs)
        try {
            nm.notify(id, builder.build())
        } catch (_: SecurityException) {
        }
    }

    fun cancel(ctx: Context, id: Int) {
        NotificationManagerCompat.from(ctx).cancel(id)
    }
}
