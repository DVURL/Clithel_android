package com.jarvis.app

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

private fun userName(ctx: Context): String =
    ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getString("name", "").orEmpty()

object HabitScheduler {

    private fun pending(ctx: Context, id: Long): PendingIntent = PendingIntent.getBroadcast(
        ctx,
        id.toInt(),
        Intent(ctx, HabitReceiver::class.java).putExtra("id", id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun nextTrigger(h: Habit): Long {
        val now = System.currentTimeMillis()
        val days = h.days.split(",").mapNotNull { it.trim().toIntOrNull() }.ifEmpty { (1..7).toList() }
        for (i in 0..7) {
            val c = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, i)
                set(Calendar.HOUR_OF_DAY, h.hour)
                set(Calendar.MINUTE, h.minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (c.timeInMillis > now && c.get(Calendar.DAY_OF_WEEK) in days) return c.timeInMillis
        }
        return now + 24L * 60 * 60 * 1000
    }

    fun schedule(ctx: Context, h: Habit) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val at = nextTrigger(h)
        val p = pending(ctx, h.id)
        try {
            val exact = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p)
        }
    }

    fun cancel(ctx: Context, id: Long) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, id))
    }
}

class HabitReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1L)
        val result = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val h = Db.get(ctx).dao().habit(id)
                if (h != null && h.enabled) {
                    val name = userName(ctx)
                    val who = if (name.isBlank()) "" else ", $name"
                    Hud.notify(
                        ctx,
                        1000 + (h.id % 1000).toInt(),
                        "SYS // HÁBITO // PRIORITY_1",
                        "¡YA ES HORA DE ${h.title.uppercase()}$who! 😉",
                    )
                    HabitScheduler.schedule(ctx, h)
                }
            } finally {
                result.finish()
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val result = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                Db.get(ctx).dao().habits().filter { it.enabled }.forEach { HabitScheduler.schedule(ctx, it) }
            } finally {
                result.finish()
            }
        }
    }
}

class SmsSentReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val name = userName(ctx)
        if (resultCode == Activity.RESULT_OK) {
            val msg = if (name.isBlank()) "Su mensaje ha sido enviado correctamente. 😌"
            else "$name, su mensaje ha sido enviado correctamente. 😌"
            Hud.notify(ctx, 2001, "SYS // COM_LINK // ENVIADO", msg)
        } else {
            val msg = if (name.isBlank()) "No pude enviar el mensaje. 😕"
            else "$name, no pude enviar el mensaje. 😕"
            Hud.notify(ctx, 2002, "SYS // COM_LINK // ERROR", msg)
        }
    }
}
