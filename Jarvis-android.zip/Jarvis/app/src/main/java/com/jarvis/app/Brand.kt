package com.jarvis.app

object Brand {
    const val NAME = "Clithel"
    const val REPO = "DVURL/Jarvis_for_android"
}
