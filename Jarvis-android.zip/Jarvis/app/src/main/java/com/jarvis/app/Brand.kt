package com.jarvis.app

/** Nombre de la app. Para cambiarlo: este valor y app_name en res/values/strings.xml. */
object Brand {
    const val NAME = "Clithel"

    /** Repositorio de GitHub donde se publican las versiones (para actualizar desde la app). */
    const val REPO = "DVURL/Jarvis_for_android"
}
