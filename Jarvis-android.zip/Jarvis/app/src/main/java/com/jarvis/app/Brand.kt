package com.jarvis.app

/** Nombre de la app. Para cambiarlo: este valor y app_name en res/values/strings.xml. */
object Brand {
    const val NAME = "Clithel"
}
