package com.jarvis.app

import android.app.AlarmManager
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Registro de eventos y errores, y reporte para copiar. No guarda claves, correos ni conversaciones:
 * solo qué falló, cuándo y el estado de permisos del celular.
 */
object Diag {
    private const val LOG_FILE = "clithel.log"
    private const val CRASH_FILE = "clithel_crash.txt"
    private const val MAX_BYTES = 60_000L

    @Volatile private var appCtx: Context? = null

    private fun stamp(): String = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date())

    fun install(app: Application) {
        appCtx = app.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, e ->
            try {
                File(app.filesDir, CRASH_FILE).writeText(
                    stamp() + " CIERRE en el hilo " + thread.name + "\n" +
                        Log.getStackTraceString(e).take(6000)
                )
                log("crash", e.javaClass.simpleName + ": " + (e.message ?: ""))
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(thread, e)
        }
        log("app", "inicio, versión ${versionName(app)}")
    }

    @Synchronized
    fun log(tag: String, msg: String) {
        val ctx = appCtx ?: return
        try {
            val f = File(ctx.filesDir, LOG_FILE)
            f.appendText("${stamp()} [$tag] ${msg.take(300)}\n")
            if (f.length() > MAX_BYTES) {
                val lines = f.readLines()
                f.writeText(lines.takeLast(lines.size / 2).joinToString("\n") + "\n")
            }
        } catch (_: Throwable) {
        }
    }

    fun error(tag: String, e: Throwable) = log(tag, "${e.javaClass.simpleName}: ${e.message ?: ""}")

    private fun readLog(ctx: Context): List<String> {
        val f = File(ctx.filesDir, LOG_FILE)
        return if (f.exists()) f.readLines() else emptyList()
    }

    fun hasCrash(ctx: Context): Boolean = File(ctx.filesDir, CRASH_FILE).exists()

    private fun lastCrash(ctx: Context): String? {
        val f = File(ctx.filesDir, CRASH_FILE)
        return if (f.exists()) f.readText() else null
    }

    fun dismissCrash(ctx: Context) {
        File(ctx.filesDir, CRASH_FILE).delete()
    }

    @Synchronized
    fun clear(ctx: Context) {
        File(ctx.filesDir, CRASH_FILE).delete()
        File(ctx.filesDir, LOG_FILE).delete()
    }

    private fun versionName(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (_: Exception) {
        ""
    }

    private fun yn(b: Boolean) = if (b) "sí" else "NO"

    private fun status(ctx: Context): List<String> {
        fun perm(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
        val power = ctx.getSystemService(PowerManager::class.java)
        val alarms = ctx.getSystemService(AlarmManager::class.java)
        val exact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) alarms.canScheduleExactAlarms() else true
        return listOf(
            "Micrófono: ${yn(perm(android.Manifest.permission.RECORD_AUDIO))}",
            "Contactos: ${yn(perm(android.Manifest.permission.READ_CONTACTS))}",
            "Llamadas: ${yn(perm(android.Manifest.permission.CALL_PHONE))}",
            "SMS: ${yn(perm(android.Manifest.permission.SEND_SMS))}",
            "Notificaciones: ${yn(NotificationManagerCompat.from(ctx).areNotificationsEnabled())}",
            "Accesibilidad activa: ${yn(JarvisAccessibilityService.instance != null)}",
            "Mostrar sobre otras apps: ${yn(Settings.canDrawOverlays(ctx))}",
            "Instalar apps desde Clithel: ${yn(ctx.packageManager.canRequestPackageInstalls())}",
            "Batería sin restricciones: ${yn(power.isIgnoringBatteryOptimizations(ctx.packageName))}",
            "Alarmas exactas: ${yn(exact)}",
        )
    }

    /** ¿Se alcanzan los servidores que usa la app? Cualquier respuesta HTTP cuenta como "responde". */
    suspend fun network(): List<String> = withContext(Dispatchers.IO) {
        val client = OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .callTimeout(10, TimeUnit.SECONDS)
            .build()
        listOf(
            "Gemini" to "https://generativelanguage.googleapis.com/",
            "GitHub (actualizaciones)" to "https://api.github.com/",
            "Nube (Firebase)" to "https://firestore.googleapis.com/",
        ).map { (name, url) ->
            val result = try {
                client.newCall(Request.Builder().url(url).head().build()).execute()
                    .use { "responde (HTTP ${it.code})" }
            } catch (e: Exception) {
                "FALLA: ${e.javaClass.simpleName}"
            }
            "$name: $result"
        }
    }

    fun report(ctx: Context, extra: List<String>, net: List<String>): String {
        val sb = StringBuilder()
        sb.appendLine("CLITHEL - REPORTE")
        sb.appendLine("Versión: ${versionName(ctx)} (código ${Updater.installedCode(ctx)})")
        sb.appendLine("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        sb.appendLine("Celular: ${Build.MANUFACTURER} ${Build.MODEL}")
        sb.appendLine("Sistema: ${Build.DISPLAY}")
        sb.appendLine("Idioma: ${Locale.getDefault().toLanguageTag()}")
        sb.appendLine()
        sb.appendLine("ESTADO")
        extra.forEach { sb.appendLine("- $it") }
        status(ctx).forEach { sb.appendLine("- $it") }
        sb.appendLine()
        sb.appendLine("RED")
        net.forEach { sb.appendLine("- $it") }
        val crash = lastCrash(ctx)
        if (crash != null) {
            sb.appendLine()
            sb.appendLine("ÚLTIMO CIERRE POR ERROR")
            sb.appendLine(crash.take(3500))
        }
        sb.appendLine()
        sb.appendLine("REGISTRO RECIENTE")
        val lines = readLog(ctx).takeLast(80)
        if (lines.isEmpty()) sb.appendLine("(vacío)") else lines.forEach { sb.appendLine(it) }
        return sb.toString()
    }
}
