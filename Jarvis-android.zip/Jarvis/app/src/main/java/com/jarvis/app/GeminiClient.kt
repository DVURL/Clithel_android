package com.jarvis.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class ApiException(val code: Int, message: String) : IOException(message)

class GeminiClient(private val apiKey: () -> String) {

    private val http = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    /** history: lista de (rol, texto) con roles "user" o "assistant"; debe terminar en "user". */
    suspend fun ask(system: String, history: List<Pair<String, String>>): String =
        withContext(Dispatchers.IO) {
            val contents = JSONArray()
            history.forEach { (role, text) ->
                contents.put(
                    JSONObject()
                        .put("role", if (role == "assistant") "model" else "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", text)))
                )
            }
            val body = JSONObject()
                .put(
                    "systemInstruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
                )
                .put("contents", contents)
                .put(
                    "generationConfig",
                    JSONObject()
                        .put("maxOutputTokens", 600)
                        .put("responseMimeType", "application/json")
                )
                .toString()
                .toRequestBody("application/json".toMediaType())

            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
                .header("x-goog-api-key", apiKey())
                .post(body)
                .build()

            http.newCall(req).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                if (!res.isSuccessful) throw ApiException(res.code, "Error ${res.code}")
                val candidates = JSONObject(raw).optJSONArray("candidates")
                    ?: throw ApiException(0, "Sin respuesta")
                val parts = candidates.getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                buildString {
                    for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text"))
                }
            }
        }

    companion object {
        const val MODEL = "gemini-2.5-flash-lite"
    }
}
