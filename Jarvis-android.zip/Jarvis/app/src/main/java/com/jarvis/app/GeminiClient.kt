package com.jarvis.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class ApiException(val code: Int, message: String) : IOException(message)

class GeminiClient(private val apiKey: () -> String) {

    private val http = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    // Modelo que funcionó la última vez; se prueba primero.
    @Volatile private var working: String? = null

    /**
     * history: lista de (rol, texto) con roles "user" o "assistant"; debe terminar en "user".
     * Si un modelo ya no existe (404), prueba el siguiente de la lista.
     */
    suspend fun ask(system: String, history: List<Pair<String, String>>): String =
        withContext(Dispatchers.IO) {
            val order = listOfNotNull(working) + MODELS.filter { it != working }
            for (m in order) {
                try {
                    val reply = call(m, system, history)
                    working = m
                    return@withContext reply
                } catch (e: ApiException) {
                    if (e.code != 404) throw e
                }
            }
            throw ApiException(404, "Ningún modelo disponible")
        }

    private fun call(model: String, system: String, history: List<Pair<String, String>>): String {
        val contents = JSONArray()
        history.forEach { (role, text) ->
            contents.put(
                JSONObject()
                    .put("role", if (role == "assistant") "model" else "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
            )
            .put("contents", contents)
            .put(
                "generationConfig",
                JSONObject()
                    .put("maxOutputTokens", 600)
                    .put("responseMimeType", "application/json")
            )
            .toString()
            .toRequestBody("application/json".toMediaType())

        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", apiKey())
            .post(body)
            .build()

        http.newCall(req).execute().use { res ->
            val raw = res.body?.string().orEmpty()
            if (!res.isSuccessful) throw ApiException(res.code, "Error ${res.code}")
            val candidates = JSONObject(raw).optJSONArray("candidates")
                ?: throw ApiException(0, "Sin respuesta")
            val parts = candidates.getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
            return buildString {
                for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text"))
            }
        }
    }

    companion object {
        // De más nuevo/ligero a más antiguo. Google retira modelos con el tiempo.
        val MODELS = listOf(
            "gemini-3.5-flash-lite",
            "gemini-3.8-flash",
            "gemini-3.5-flash",
            "gemini-3.1-flash-lite",
            "gemini-2.5-flash-lite",
        )
    }
}
