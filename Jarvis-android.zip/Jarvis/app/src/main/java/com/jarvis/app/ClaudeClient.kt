package com.jarvis.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class ApiException(val code: Int, message: String) : IOException(message)

class ClaudeClient(private val apiKey: () -> String) {

    private val http = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    /** history: lista de (rol, texto), debe empezar y terminar con "user". */
    suspend fun ask(system: String, history: List<Pair<String, String>>): String =
        withContext(Dispatchers.IO) {
            val msgs = JSONArray()
            history.forEach { (role, text) ->
                msgs.put(JSONObject().put("role", role).put("content", text))
            }
            val body = JSONObject()
                .put("model", MODEL)
                .put("max_tokens", 600)
                .put("system", system)
                .put("messages", msgs)
                .toString()
                .toRequestBody("application/json".toMediaType())

            val req = Request.Builder()
                .url("https://api.anthropic.com/v1/messages")
                .header("x-api-key", apiKey())
                .header("anthropic-version", "2023-06-01")
                .post(body)
                .build()

            http.newCall(req).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                if (!res.isSuccessful) throw ApiException(res.code, "Error ${res.code}")
                val content = JSONObject(raw).getJSONArray("content")
                buildString {
                    for (i in 0 until content.length()) {
                        val b = content.getJSONObject(i)
                        if (b.optString("type") == "text") append(b.getString("text"))
                    }
                }
            }
        }

    companion object {
        const val MODEL = "claude-sonnet-5-5"
    }
}
