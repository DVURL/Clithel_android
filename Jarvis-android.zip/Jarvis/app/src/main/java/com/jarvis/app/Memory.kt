package com.jarvis.app

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Entity
data class Fact(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity
data class Msg(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String, // "user" | "assistant"
    val text: String,
    val createdAt: Long = System.currentTimeMillis(),
)

/** days: "1,2,3" con 1=domingo ... 7=sábado; vacío = todos los días. */
@Entity
data class Habit(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val hour: Int,
    val minute: Int,
    val days: String = "",
    val enabled: Boolean = true,
)

@Dao
interface MemoryDao {
    @Query("SELECT * FROM Fact ORDER BY id")
    suspend fun facts(): List<Fact>

    @Insert
    suspend fun addFact(f: Fact)

    @Query("DELETE FROM Fact")
    suspend fun clearFacts()

    @Query("SELECT * FROM Msg ORDER BY id DESC LIMIT :n")
    suspend fun lastMsgs(n: Int): List<Msg>

    @Insert
    suspend fun addMsg(m: Msg)

    @Query("SELECT * FROM Habit ORDER BY hour, minute")
    suspend fun habits(): List<Habit>

    @Query("SELECT * FROM Habit WHERE id = :id")
    suspend fun habit(id: Long): Habit?

    @Insert
    suspend fun addHabit(h: Habit): Long

    @Query("DELETE FROM Habit WHERE id = :id")
    suspend fun deleteHabit(id: Long)
}

@Database(entities = [Fact::class, Msg::class, Habit::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): MemoryDao
}

private val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `Habit` (" +
                "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`title` TEXT NOT NULL, " +
                "`hour` INTEGER NOT NULL, " +
                "`minute` INTEGER NOT NULL, " +
                "`days` TEXT NOT NULL, " +
                "`enabled` INTEGER NOT NULL)"
        )
    }
}

/** Base de datos única, compartida por la app y los receptores. */
object Db {
    @Volatile private var inst: AppDb? = null

    fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
        inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "jarvis.db")
            .addMigrations(MIGRATION_1_2)
            .build()
            .also { inst = it }
    }
}
