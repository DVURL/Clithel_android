package com.jarvis.app

import androidx.room.*

@Entity
data class Fact(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity
data class Msg(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String, // "user" | "assistant"
    val text: String,
    val createdAt: Long = System.currentTimeMillis(),
)

@Dao
interface MemoryDao {
    @Query("SELECT * FROM Fact ORDER BY id")
    suspend fun facts(): List<Fact>

    @Insert
    suspend fun addFact(f: Fact)

    @Query("DELETE FROM Fact")
    suspend fun clearFacts()

    @Query("SELECT * FROM Msg ORDER BY id DESC LIMIT :n")
    suspend fun lastMsgs(n: Int): List<Msg>

    @Insert
    suspend fun addMsg(m: Msg)
}

@Database(entities = [Fact::class, Msg::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): MemoryDao
}
