package com.jarvis.app

import android.content.Context
import android.net.Uri
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.SamplerConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** mode: "nube" (Gemini), "local" (sin internet) o "auto" (nube y, si falla, local). */
data class LocalUi(
    val mode: String = "nube",
    val hasModel: Boolean = false,
    val modelName: String = "",
    val sizeMb: Int = 0,
    val status: String = "",
)

/** El modelo de IA local (.litertlm) que el usuario importa desde su celular. */
object LocalModel {
    private fun dir(ctx: Context) = File(ctx.filesDir, "local")
    fun file(ctx: Context) = File(dir(ctx), "model.litertlm")
    private fun nameFile(ctx: Context) = File(dir(ctx), "name.txt")

    fun isReady(ctx: Context): Boolean = file(ctx).let { it.exists() && it.length() > 1_000_000L }
    fun name(ctx: Context): String = nameFile(ctx).let { if (it.exists()) it.readText() else "" }
    fun sizeMb(ctx: Context): Int = (file(ctx).length() / (1024 * 1024)).toInt()

    /** Copia el archivo elegido a la memoria de la app. Devuelve un mensaje de error, o null si salió bien. */
    suspend fun copyIn(ctx: Context, uri: Uri, displayName: String, onProgress: (Int) -> Unit): String? =
        withContext(Dispatchers.IO) {
            try {
                dir(ctx).mkdirs()
                val total = ctx.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
                if (total > 0 && ctx.filesDir.usableSpace < total + 100L * 1024 * 1024) {
                    return@withContext "No hay espacio suficiente en el celular para este modelo."
                }
                val tmp = File(dir(ctx), "model.tmp")
                val input = ctx.contentResolver.openInputStream(uri) ?: return@withContext "No pude abrir el archivo."
                input.use { i ->
                    tmp.outputStream().use { out ->
                        val buf = ByteArray(1 shl 20)
                        var done = 0L
                        var last = -1
                        while (true) {
                            val n = i.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val p = (done * 100 / total).toInt()
                                if (p != last) {
                                    last = p
                                    onProgress(p)
                                }
                            }
                        }
                    }
                }
                if (tmp.length() < 50L * 1024 * 1024) {
                    tmp.delete()
                    return@withContext "El archivo es muy pequeño para ser un modelo de IA."
                }
                file(ctx).delete()
                if (!tmp.renameTo(file(ctx))) return@withContext "No pude guardar el modelo."
                nameFile(ctx).writeText(displayName)
                null
            } catch (e: Exception) {
                Diag.error("ia-local", e)
                "No pude importar el modelo (${e.javaClass.simpleName})."
            }
        }

    fun delete(ctx: Context) {
        dir(ctx).deleteRecursively()
    }
}

/** Motor de IA que corre en el celular (LiteRT-LM). Se carga al usarlo y se libera tras 5 minutos sin uso. */
class LocalBrain(private val ctx: Context) {
    private val mutex = Mutex()
    private var engine: Engine? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var idleJob: Job? = null

    private fun createEngine(): Engine {
        val e = Engine(
            EngineConfig(
                modelPath = LocalModel.file(ctx).absolutePath,
                backend = Backend.CPU(),
            )
        )
        e.initialize()
        return e
    }

    /** history: mensajes anteriores (sin el actual), alternando "user" y "assistant". */
    suspend fun reply(system: String, history: List<Pair<String, String>>, text: String): String =
        withContext(Dispatchers.IO) {
            mutex.withLock {
                idleJob?.cancel()
                val eng = engine ?: createEngine().also { engine = it }
                val initial = history
                    .dropWhile { it.first != "user" }
                    .map { (role, t) -> if (role == "assistant") Message.model(t) else Message.user(t) }
                val config = ConversationConfig(
                    systemInstruction = Contents.of(system),
                    initialMessages = initial,
                    samplerConfig = SamplerConfig(topK = 20, topP = 0.9, temperature = 0.7),
                )
                val out = eng.createConversation(config).use { conv -> conv.sendMessage(text).toString() }
                scheduleRelease()
                out.trim()
            }
        }

    private fun scheduleRelease() {
        idleJob?.cancel()
        idleJob = scope.launch {
            delay(5 * 60_000L)
            mutex.withLock { closeEngine() }
        }
    }

    private fun closeEngine() {
        try { engine?.close() } catch (_: Throwable) { }
        engine = null
    }

    suspend fun releaseNow() {
        idleJob?.cancel()
        mutex.withLock { closeEngine() }
    }
}

fun guessEmotion(reply: String): String {
    val t = Norm.of(reply)
    return when {
        t.contains("lo siento") || t.contains("lamento") || t.contains("desafortunadamente") -> "sad"
        t.contains("increible") || t.contains("wow") || t.contains("vaya") -> "surprised"
        t.contains("genial") || t.contains("excelente") || t.contains("felicidades") ||
            t.contains("que bueno") || t.contains("con gusto") -> "happy"
        else -> "calm"
    }
}

class LocalResult(val reply: String, val actions: List<JSONObject>, val remember: List<String> = emptyList())

/** Órdenes simples que se entienden sin internet y sin IA: abrir apps, linterna, volumen, alarmas... */
object LocalIntents {
    private val WORDS = mapOf(
        "un" to 1, "una" to 1, "uno" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5,
        "seis" to 6, "siete" to 7, "ocho" to 8, "nueve" to 9, "diez" to 10, "once" to 11, "doce" to 12,
        "trece" to 13, "catorce" to 14, "quince" to 15, "dieciseis" to 16, "diecisiete" to 17,
        "dieciocho" to 18, "diecinueve" to 19, "veinte" to 20, "treinta" to 30, "cuarenta" to 40,
        "cincuenta" to 50, "sesenta" to 60,
    )

    private fun num(t: String): Int? = t.toIntOrNull() ?: WORDS[t]

    private fun action(type: String): JSONObject = JSONObject().put("type", type)

    private fun clock(t: String): Pair<Int, Int>? {
        val re = Regex("(?:a las|a la|las|la) (\\d{1,2}|[a-z]+)(?:[: ](\\d{2}))?( y media| y cuarto| menos cuarto)?")
        for (m in re.findAll(t)) {
            var h = num(m.groupValues[1]) ?: continue
            var min = m.groupValues[2].toIntOrNull() ?: 0
            when (m.groupValues[3].trim()) {
                "y media" -> min = 30
                "y cuarto" -> min = 15
                "menos cuarto" -> {
                    min = 45
                    h -= 1
                }
            }
            val pm = t.contains("de la tarde") || t.contains("de la noche")
            val am = t.contains("de la manana") || t.contains("de la madrugada")
            if (pm && h < 12) h += 12
            if (am && h == 12) h = 0
            if (h < 0) h += 24
            if (h in 0..23 && min in 0..59) return h to min
        }
        return null
    }

    private fun hm(h: Int, m: Int) = String.format(Locale.US, "%d:%02d", h, m)

    fun parse(raw: String, selfName: String): LocalResult? {
        val trimmed = raw.trim().trimEnd('.', '!', '?', ' ')
        var t = Norm.of(trimmed)
        val self = Norm.of(selfName)
        if (self.isNotEmpty() && t.startsWith("$self ")) t = t.removePrefix("$self ").trim()
        if (t.isEmpty()) return null
        val cal = Calendar.getInstance()

        // Hora y fecha
        if (t.contains("que hora es") || t == "la hora" || t.contains("dime la hora")) {
            val h = cal.get(Calendar.HOUR_OF_DAY)
            val h12 = if (h % 12 == 0) 12 else h % 12
            val part = when {
                h < 6 -> "de la madrugada"
                h < 12 -> "de la mañana"
                h < 19 -> "de la tarde"
                else -> "de la noche"
            }
            return LocalResult("Son las ${hm(h12, cal.get(Calendar.MINUTE))} $part.", emptyList())
        }
        if (t.contains("que dia es") || t.contains("que fecha es") || t.contains("fecha de hoy")) {
            val d = SimpleDateFormat("EEEE d 'de' MMMM", Locale("es")).format(Date())
            return LocalResult("Hoy es $d.", emptyList())
        }

        // Nombre del usuario
        Regex("(?i)^(?:me llamo|mi nombre es)\\s+(.+)$").find(trimmed)?.let { m ->
            val name = m.groupValues[1].trim().replaceFirstChar { it.uppercase() }
            return LocalResult(
                "Mucho gusto, $name.",
                listOf(action("set_name").put("name", name)),
                listOf("Se llama $name"),
            )
        }

        // Linterna
        if (t.contains("linterna")) {
            val off = t.startsWith("apaga") || t.startsWith("desactiva") || t.startsWith("quita") || t.startsWith("cierra")
            return LocalResult(
                if (off) "Linterna apagada." else "Linterna encendida.",
                listOf(action("flashlight").put("on", !off)),
            )
        }

        // Volumen
        if (t.contains("volumen")) {
            Regex("volumen (?:al |a )?(\\d{1,3})").find(t)?.let { m ->
                val level = m.groupValues[1].toInt().coerceIn(0, 100)
                return LocalResult("Volumen al $level por ciento.", listOf(action("volume").put("level", level)))
            }
            if (t.contains("sube") || t.contains("aumenta") || t.contains("mas alto")) {
                return LocalResult("Subiendo el volumen.", listOf(action("volume").put("dir", "up")))
            }
            if (t.contains("baja") || t.contains("disminuye") || t.contains("mas bajo")) {
                return LocalResult("Bajando el volumen.", listOf(action("volume").put("dir", "down")))
            }
        }

        // Temporizador
        if (t.contains("temporizador") || t.contains("cronometro") || t.contains("avisame en") || t.contains("cuenta regresiva")) {
            if (t.contains("media hora")) {
                return LocalResult(
                    "Listo, temporizador de media hora.",
                    listOf(action("timer").put("seconds", 1800).put("label", "")),
                )
            }
            for (m in Regex("(\\d+|[a-z]+) (segundos?|minutos?|horas?)").findAll(t)) {
                val n = num(m.groupValues[1]) ?: continue
                val unit = m.groupValues[2]
                val secs = when {
                    unit.startsWith("segundo") -> n
                    unit.startsWith("minuto") -> n * 60
                    else -> n * 3600
                }
                if (secs > 0) {
                    return LocalResult(
                        "Listo, temporizador de $n $unit.",
                        listOf(action("timer").put("seconds", secs).put("label", "")),
                    )
                }
            }
        }

        // Alarma
        if (t.contains("alarma") || t.startsWith("despiertame") || t.startsWith("levantame")) {
            clock(t)?.let { (h, m) ->
                return LocalResult(
                    "Listo, alarma a las ${hm(h, m)}.",
                    listOf(action("alarm").put("hour", h).put("minute", m).put("label", "")),
                )
            }
        }

        // Recordatorio diario
        Regex("^recuerdame (?:que )?(.+?) todos los dias a las (.+)$").find(t)?.let { m ->
            val title = m.groupValues[1].trim()
            val c = clock("a las " + m.groupValues[2])
            if (title.isNotEmpty() && c != null) {
                return LocalResult(
                    "Listo, te lo recordaré todos los días a las ${hm(c.first, c.second)}.",
                    listOf(
                        action("habit_add").put("title", title).put("hour", c.first)
                            .put("minute", c.second).put("days", JSONArray())
                    ),
                )
            }
        }

        // Llamadas y mensajes (se usan las palabras originales para buscar el contacto)
        Regex("(?i)^(?:llama|llámame|llamame|llámale|llamale|marca|telefonea)\\s+(?:a\\s+)?(.+)$").find(trimmed)?.let { m ->
            val who = m.groupValues[1].trim()
            return LocalResult("Llamando a $who.", listOf(action("call").put("to", who)))
        }
        Regex("(?i)^(?:manda|mándale|mandale|envía|envia|escribe)(?:le)?\\s+(?:un\\s+)?(?:mensaje|sms|texto)?\\s*(?:a\\s+)?(.+?)\\s+(?:que diga|diciendo|que dice|que)\\s+(.+)$").find(trimmed)?.let { m ->
            val to = m.groupValues[1].trim()
            val msg = m.groupValues[2].trim()
            if (to.isNotEmpty() && msg.isNotEmpty()) {
                return LocalResult("Mensaje para $to.", listOf(action("sms").put("to", to).put("text", msg)))
            }
        }

        // Abrir una app
        Regex("^(?:abre|abrir|abreme|entra a|entra en|inicia|lanza|ejecuta) (?:la app de |la aplicacion de |mi aplicacion de |la app |la aplicacion |mi app |el |la |a )?(.+)$").find(t)?.let { m ->
            val app = m.groupValues[1].trim()
            if (app.isNotEmpty()) return LocalResult("Abriendo $app.", listOf(action("open_app").put("app", app)))
        }
        return null
    }
}
