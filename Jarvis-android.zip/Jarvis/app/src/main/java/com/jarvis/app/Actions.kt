package com.jarvis.app

import android.Manifest
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.telephony.SmsManager
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Ejecuta las acciones que pide el modelo. Devuelve null si todo salió bien,
 * o un texto (datos o error) que se le devuelve al modelo para que se lo explique al usuario.
 */
class ActionExecutor(
    private val ctx: Context,
    private val prefs: SharedPreferences,
    private val dao: MemoryDao,
) {

    suspend fun run(a: JSONObject): String? {
        val type = a.optString("type")
        val result = when (type) {
            "open_app" -> openApp(a.optString("app"))
            "call" -> call(a.optString("to"))
            "sms" -> sms(a.optString("to"), a.optString("text"))
            "alarm" -> alarm(a.optInt("hour"), a.optInt("minute"), a.optString("label"))
            "timer" -> timer(a.optInt("seconds"), a.optString("label"))
            "flashlight" -> flashlight(a.optBoolean("on", true))
            "volume" -> volume(a)
            "habit_add" -> habitAdd(a)
            "habit_delete" -> habitDelete(a.optString("title"))
            "set_name" -> setName(a.optString("name"))
            "ui_global" -> uiGlobal(a.optString("action"))
            "ui_click" -> uiClick(a.optString("text"))
            "ui_scroll" -> uiScroll(a.optString("dir"))
            "ui_read" -> uiRead()
            else -> null
        }
        if (type in setOf("open_app", "ui_global", "ui_click", "ui_scroll")) delay(1500)
        return result
    }

    // ---------- Apps, llamadas, mensajes ----------

    private fun openApp(name: String): String? {
        if (name.isBlank()) return "ERROR: no dijiste qué app abrir"
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val q = name.lowercase()
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "ERROR: no encontré la app \"$name\""
        val intent = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?: return "ERROR: no pude abrir \"$name\""
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return null
    }

    private suspend fun resolveNumber(to: String): String? {
        if (to.isBlank()) return null
        if (Regex("^[+0-9][0-9 ()+\\-]{4,}\$").matches(to.trim())) {
            return to.filter { it.isDigit() || it == '+' }
        }
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        return withContext(Dispatchers.IO) {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$to%"),
                null,
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        }
    }

    private suspend fun call(to: String): String? {
        val number = resolveNumber(to)
            ?: return "ERROR: no encontré el contacto \"$to\" (o falta el permiso de contactos)"
        val granted = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val intent = Intent(
            if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL,
            Uri.fromParts("tel", number, null),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return null
    }

    @Suppress("DEPRECATION")
    private suspend fun sms(to: String, text: String): String? {
        if (text.isBlank()) return "ERROR: el mensaje está vacío"
        if (ctx.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            return "ERROR: falta el permiso de SMS; el usuario debe darlo en los ajustes de ${Brand.NAME}"
        }
        val number = resolveNumber(to)
            ?: return "ERROR: no encontré el contacto \"$to\" (o falta el permiso de contactos)"
        val manager = ctx.getSystemService(SmsManager::class.java) ?: SmsManager.getDefault()
        val sent = PendingIntent.getBroadcast(
            ctx,
            (System.currentTimeMillis() % 100000).toInt(),
            Intent(ctx, SmsSentReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val parts = manager.divideMessage(text)
        val sentList = ArrayList<PendingIntent?>()
        repeat(parts.size) { sentList.add(null) }
        sentList[parts.size - 1] = sent
        manager.sendMultipartTextMessage(number, null, parts, sentList, null)
        return null
    }

    // ---------- Alarmas, hábitos ----------

    private fun alarm(hour: Int, minute: Int, label: String): String? {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
            .putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
            .putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { Brand.NAME })
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            val c = java.util.Calendar.getInstance().apply {
                set(java.util.Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
                set(java.util.Calendar.MINUTE, minute.coerceIn(0, 59))
                set(java.util.Calendar.SECOND, 0)
                set(java.util.Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR, 1)
            }
            val what = label.trim()
            val msg = if (what.isEmpty() || what == Brand.NAME) "¡YA ES LA HORA${who()}! ⏰"
            else "¡YA ES HORA DE ${what.uppercase()}${who()}! ⏰"
            Notices.schedule(ctx, c.timeInMillis, "SYS // ALARMA // PRIORITY_1", msg)
            null
        } catch (_: ActivityNotFoundException) {
            "ERROR: no hay una app de reloj para crear la alarma"
        }
    }

    private fun timer(seconds: Int, label: String): String? {
        if (seconds <= 0) return "ERROR: duración inválida"
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { Brand.NAME })
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            val what = label.trim()
            val msg = if (what.isEmpty() || what == Brand.NAME) "¡Tu temporizador ha terminado${who()}! ⏰"
            else "¡Tu temporizador de $what ha terminado${who()}! ⏰"
            Notices.schedule(ctx, System.currentTimeMillis() + seconds * 1000L, "SYS // TEMPORIZADOR // FIN", msg)
            null
        } catch (_: ActivityNotFoundException) {
            "ERROR: no hay una app de reloj para crear el temporizador"
        }
    }

    private suspend fun habitAdd(a: JSONObject): String? {
        val title = a.optString("title").trim()
        if (title.isEmpty()) return "ERROR: falta el nombre del hábito"
        val arr = a.optJSONArray("days")
        val days = if (arr == null) "" else
            (0 until arr.length()).map { arr.optInt(it) }.filter { it in 1..7 }.joinToString(",")
        val h = Habit(
            title = title,
            hour = a.optInt("hour").coerceIn(0, 23),
            minute = a.optInt("minute").coerceIn(0, 59),
            days = days,
        )
        val id = withContext(Dispatchers.IO) { dao.addHabit(h) }
        HabitScheduler.schedule(ctx, h.copy(id = id))
        return if (NotificationManagerCompat.from(ctx).areNotificationsEnabled()) null
        else "AVISO: hábito guardado, pero las notificaciones están desactivadas; el usuario debe darlas en los ajustes de ${Brand.NAME}"
    }

    private suspend fun habitDelete(title: String): String? {
        val q = title.trim().lowercase()
        if (q.isEmpty()) return "ERROR: falta el nombre del hábito"
        val hits = withContext(Dispatchers.IO) { dao.habits().filter { it.title.lowercase().contains(q) } }
        if (hits.isEmpty()) return "ERROR: no encontré un hábito llamado \"$title\""
        hits.forEach {
            HabitScheduler.cancel(ctx, it.id)
            withContext(Dispatchers.IO) { dao.deleteHabit(it.id) }
        }
        return null
    }

    private fun who(): String {
        val n = prefs.getString("name", "").orEmpty()
        return if (n.isBlank()) "" else ", $n"
    }

    private fun setName(name: String): String? {
        if (name.isNotBlank()) prefs.edit().putString("name", name.trim()).apply()
        return null
    }

    // ---------- Linterna y volumen ----------

    private fun flashlight(on: Boolean): String? {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "ERROR: este celular no tiene linterna"
        cm.setTorchMode(id, on)
        return null
    }

    private fun volume(a: JSONObject): String? {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        when {
            a.has("level") -> {
                val level = a.optInt("level").coerceIn(0, 100)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, max * level / 100, AudioManager.FLAG_SHOW_UI)
            }
            a.optString("dir") == "up" ->
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            a.optString("dir") == "down" ->
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        }
        return null
    }

    // ---------- Accesibilidad ----------

    private val noA11y = "ERROR: la accesibilidad de ${Brand.NAME} no está activada; el usuario debe activarla en los ajustes de ${Brand.NAME}"

    private fun uiGlobal(action: String): String? {
        val s = JarvisAccessibilityService.instance ?: return noA11y
        return if (s.global(action)) null else "ERROR: no pude hacer la acción \"$action\""
    }

    private fun uiClick(text: String): String? {
        val s = JarvisAccessibilityService.instance ?: return noA11y
        return if (s.clickText(text)) null else "ERROR: no encontré \"$text\" en la pantalla"
    }

    private fun uiScroll(dir: String): String? {
        val s = JarvisAccessibilityService.instance ?: return noA11y
        return if (s.scroll(dir != "up")) null else "ERROR: no encontré nada que desplazar"
    }

    private fun uiRead(): String? {
        val s = JarvisAccessibilityService.instance ?: return noA11y
        val t = s.readScreen()
        return if (t.isBlank()) "PANTALLA: (no hay texto legible)" else "PANTALLA:\n$t"
    }
}
