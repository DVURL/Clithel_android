package com.jarvis.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.RemoteViews

object EyesWidget {
    private var bmp: Bitmap? = null

    private fun bitmap(): Bitmap =
        bmp ?: Bitmap.createBitmap(480, 240, Bitmap.Config.ARGB_8888).also { bmp = it }

    private fun ids(ctx: Context): IntArray =
        AppWidgetManager.getInstance(ctx).getAppWidgetIds(ComponentName(ctx, EyesWidgetProvider::class.java))

    fun hasWidgets(ctx: Context): Boolean = ids(ctx).isNotEmpty()

    @Synchronized
    fun render(ctx: Context, phase: Phase, emotion: Emotion, t: Float, level: Float, full: Boolean) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val widgetIds = ids(ctx)
        if (widgetIds.isEmpty()) return

        val style = Eyes.style(phase, emotion, ThemeStore.load(ctx).palette())
        val pose = Eyes.pose(style, phase, t, level)
        val b = bitmap()
        Eyes.drawBitmap(b, style, pose)

        val rv = RemoteViews(ctx.packageName, R.layout.widget_eyes)
        rv.setImageViewBitmap(R.id.eyes_img, b)
        if (full) {
            val tap = PendingIntent.getActivity(
                ctx, 7,
                Intent(ctx, MainActivity::class.java)
                    .putExtra("listen", true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            rv.setOnClickPendingIntent(R.id.eyes_root, tap)
            mgr.updateAppWidget(widgetIds, rv)
        } else {
            mgr.partiallyUpdateAppWidget(widgetIds, rv)
        }
    }
}

class EyesWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        EyesWidget.render(context, Phase.IDLE, Emotion.CALM, 0f, 0f, true)
    }
}
