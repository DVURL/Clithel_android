package com.jarvis.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat

/** ok = true (listo), false (falta) o null (no se puede comprobar, es manual). */
data class SetupItem(
    val id: String,
    val title: String,
    val detail: String,
    val ok: Boolean?,
    val button: String,
)

object SetupCheck {
    fun isXiaomi(): Boolean {
        val m = Build.MANUFACTURER.lowercase()
        return m.contains("xiaomi") || m.contains("redmi") || m.contains("poco")
    }

    fun items(ctx: Context, hasKey: Boolean): List<SetupItem> {
        fun perm(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
        val power = ctx.getSystemService(PowerManager::class.java)
        val list = mutableListOf<SetupItem>()
        list += SetupItem(
            "gemini", "Clave de Gemini",
            "Sin ella no puede responderte. Se saca gratis en aistudio.google.com/apikey.",
            hasKey, "Abrir ajustes",
        )
        list += SetupItem(
            "perms", "Micrófono, contactos, llamadas y SMS",
            "Para escucharte, llamar y mandar mensajes.",
            perm(Manifest.permission.RECORD_AUDIO) && perm(Manifest.permission.READ_CONTACTS) &&
                perm(Manifest.permission.CALL_PHONE) && perm(Manifest.permission.SEND_SMS),
            "Dar permisos",
        )
        list += SetupItem(
            "notif", "Notificaciones",
            "Para tus recordatorios y avisos.",
            NotificationManagerCompat.from(ctx).areNotificationsEnabled(), "Activar",
        )
        list += SetupItem(
            "access", "Accesibilidad",
            "Para leer la pantalla y tocar botones en otras apps.",
            JarvisAccessibilityService.instance != null, "Activar",
        )
        list += SetupItem(
            "overlay", "Mostrar sobre otras apps",
            "Ayuda a abrir apps cuando ${Brand.NAME} está en segundo plano.",
            Settings.canDrawOverlays(ctx), "Activar",
        )
        list += SetupItem(
            "battery", "Batería sin restricciones",
            "Para que los recordatorios y la escucha no se corten.",
            power.isIgnoringBatteryOptimizations(ctx.packageName), "Permitir",
        )
        if (isXiaomi()) {
            list += SetupItem(
                "xiaomi", "Permisos de Xiaomi",
                "Activa \"Mostrar ventanas emergentes mientras se ejecuta en segundo plano\" e \"Inicio automático\".",
                null, "Abrir permisos",
            )
        }
        return list
    }
}
