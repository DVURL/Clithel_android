package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/** Mantiene viva la lectura de un libro y muestra los controles en la notificación. */
class ReaderService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val engine = Engine.get(applicationContext)
        when (intent?.action) {
            ACTION_PAUSE -> { engine.readerPause(); return START_NOT_STICKY }
            ACTION_RESUME -> { engine.readerResume(); return START_NOT_STICKY }
            ACTION_FASTER -> { engine.readerRate(0.15f); return START_NOT_STICKY }
            ACTION_SLOWER -> { engine.readerRate(-0.15f); return START_NOT_STICKY }
            ACTION_STOP -> {
                engine.readerStop()
                stopSelf()
                return START_NOT_STICKY
            }
        }
        val title = intent?.getStringExtra("title") ?: Brand.NAME
        val playing = intent?.getBooleanExtra("playing", true) ?: true
        startForeground(NOTIF_ID, build(title, playing), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        return START_NOT_STICKY
    }

    private fun build(title: String, playing: Boolean): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Lectura de libros", NotificationManager.IMPORTANCE_LOW)
        )
        fun act(action: String, code: Int) = PendingIntent.getService(
            this, code,
            Intent(this, ReaderService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle(title)
            .setContentText(if (playing) "Leyendo en voz alta" else "En pausa")
            .setContentIntent(open)
            .addAction(0, if (playing) "Pausa" else "Seguir", act(if (playing) ACTION_PAUSE else ACTION_RESUME, 1))
            .addAction(0, "Más rápido", act(ACTION_FASTER, 2))
            .addAction(0, "Más lento", act(ACTION_SLOWER, 3))
            .addAction(0, "Detener", act(ACTION_STOP, 4))
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val CHANNEL = "clithel_reader"
        private const val NOTIF_ID = 78
        private const val ACTION_PAUSE = "com.jarvis.app.READER_PAUSE"
        private const val ACTION_RESUME = "com.jarvis.app.READER_RESUME"
        private const val ACTION_FASTER = "com.jarvis.app.READER_FASTER"
        private const val ACTION_SLOWER = "com.jarvis.app.READER_SLOWER"
        private const val ACTION_STOP = "com.jarvis.app.READER_STOP"

        fun show(ctx: Context, title: String, playing: Boolean) {
            ContextCompat.startForegroundService(
                ctx,
                Intent(ctx, ReaderService::class.java).putExtra("title", title).putExtra("playing", playing),
            )
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, ReaderService::class.java))
        }
    }
}
