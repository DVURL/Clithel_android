@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.jarvis.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

// Colores por estado
private val ColIdle = Color(0xFF00E5FF)      // cian
private val ColListening = Color(0xFF00FF9C) // verde menta
private val ColThinking = Color(0xFFFFB300)  // ámbar
private val ColSpeaking = Color(0xFF4DA6FF)  // azul

@Composable
fun JarvisScreen(vm: JarvisViewModel) {
    val ui by vm.ui.collectAsState()
    val level by vm.level.collectAsState()
    val ctx = LocalContext.current

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.onOrbTap() else vm.setCaption("Necesito el micrófono para escucharte")
    }
    fun tap() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) vm.onOrbTap() else launcher.launch(Manifest.permission.RECORD_AUDIO)
    }

    // Arranque: los elementos aparecen de a poco
    val boot = remember { Animatable(0f) }
    LaunchedEffect(Unit) { boot.animateTo(1f, tween(2200, easing = FastOutSlowInEasing)) }

    val style = Eyes.style(ui.phase, ui.emotion)
    val color by animateColorAsState(Color(style.ring), tween(500), label = "color")
    val eyeColor by animateColorAsState(Color(style.eye), tween(500), label = "eyeColor")
    val speed by animateFloatAsState(
        when (ui.phase) {
            Phase.IDLE -> 12f
            Phase.LISTENING -> 40f
            Phase.THINKING -> 220f
            Phase.SPEAKING -> 70f
        },
        tween(600), label = "speed",
    )

    val phaseNow = rememberUpdatedState(ui.phase)
    val levelNow = rememberUpdatedState(level)
    val speedNow = rememberUpdatedState(speed)

    var angle by remember { mutableFloatStateOf(0f) }
    var t by remember { mutableFloatStateOf(0f) }
    var lvl by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = (now - last) / 1_000_000_000f
            last = now
            angle = (angle + speedNow.value * dt) % 360f
            t += dt
            val target = when (phaseNow.value) {
                Phase.LISTENING -> levelNow.value
                Phase.SPEAKING -> (0.45f + 0.25f * sin(t * 7.3f) + 0.2f * sin(t * 11.1f + 1f)).coerceIn(0f, 1f)
                Phase.THINKING -> 0.2f + 0.1f * sin(t * 4f)
                Phase.IDLE -> 0f
            }
            lvl += (target - lvl) * min(1f, dt * 12f)
        }
    }

    val booting = boot.value < 1f
    val status = if (booting) "INICIANDO SISTEMAS" else when (ui.phase) {
        Phase.IDLE -> "EN ESPERA"
        Phase.LISTENING -> "ESCUCHANDO"
        Phase.THINKING -> "PROCESANDO"
        Phase.SPEAKING -> "RESPONDIENDO"
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Text(
            Brand.NAME.uppercase(),
            color = color.copy(alpha = 0.45f),
            fontSize = 12.sp,
            letterSpacing = 8.sp,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 56.dp),
        )

        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Canvas(
                Modifier
                    .size(300.dp)
                    .combinedClickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = { tap() },
                        onLongClick = { vm.openSettings() },
                    )
            ) {
                val c = center
                val r = size.minDimension / 2f
                val b = boot.value
                val sc = 0.6f + 0.4f * b
                val a = angle
                val l = lvl
                val col = color
                val k = 1f + (0.015f + 0.05f * l) * sin(t * 3f)

                // Resplandor y núcleo (reaccionan al volumen)
                val gr = r * (0.5f + 0.22f * l) * k * sc
                drawCircle(
                    Brush.radialGradient(
                        listOf(col.copy(alpha = 0.85f * b), col.copy(alpha = 0f)),
                        center = c, radius = gr,
                    ),
                    radius = gr, center = c,
                )
                // Ojos (parpadean, miran, se mueven y cambian de color según la emoción)
                val pose = Eyes.pose(style, ui.phase, t, l)
                val s = r * 0.27f * sc
                val ec = eyeColor.copy(alpha = b)
                for (i in 0..1) {
                    val sign = if (i == 0) -1f else 1f
                    val ex = c.x + (sign * pose.gap + pose.look) * s
                    val ey = c.y + pose.y * s
                    val ew = pose.w * s
                    val eh = pose.h * s
                    rotate(if (i == 0) pose.tilt else -pose.tilt, Offset(ex, ey)) {
                        drawRoundRect(
                            ec,
                            topLeft = Offset(ex - ew / 2f, ey - eh / 2f),
                            size = Size(ew, eh),
                            cornerRadius = CornerRadius(min(ew, eh) / 2f),
                        )
                    }
                }

                // Onda de voz
                if (l > 0.02f) {
                    drawCircle(
                        col.copy(alpha = 0.15f + 0.4f * l),
                        radius = r * (0.30f + 0.22f * l) * sc, center = c,
                        style = Stroke(1.5.dp.toPx()),
                    )
                }

                // Anillo exterior fino
                drawCircle(col.copy(alpha = 0.25f * b), radius = r * 0.97f * sc, center = c, style = Stroke(1.dp.toPx()))

                // Marcas tipo panel de control
                val tickCount = 72
                val visible = (tickCount * b).toInt()
                val rot = a * 0.25f
                for (i in 0 until visible) {
                    val long = i % 6 == 0
                    val ang = Math.toRadians(i * 360.0 / tickCount + rot).toFloat()
                    val r0 = r * (if (long) 0.85f else 0.89f) * sc
                    val r1 = r * 0.93f * sc
                    drawLine(
                        col.copy(alpha = if (long) 0.8f else 0.35f),
                        Offset(c.x + cos(ang) * r0, c.y + sin(ang) * r0),
                        Offset(c.x + cos(ang) * r1, c.y + sin(ang) * r1),
                        strokeWidth = (if (long) 2.dp else 1.dp).toPx(),
                    )
                }

                // Anillo medio: dos arcos finos, giro inverso
                val r2 = r * 0.78f * sc
                for (i in 0 until 2) {
                    drawArc(
                        col.copy(alpha = 0.55f * b), startAngle = -a * 0.7f + i * 180f, sweepAngle = 50f,
                        useCenter = false, topLeft = Offset(c.x - r2, c.y - r2), size = Size(r2 * 2, r2 * 2),
                        style = Stroke(2.dp.toPx(), cap = StrokeCap.Round),
                    )
                }

                // Anillo principal: tres arcos gruesos
                val r1 = r * 0.64f * (1f + 0.04f * l) * sc
                for (i in 0 until 3) {
                    drawArc(
                        col.copy(alpha = 0.9f * b), startAngle = a + i * 120f, sweepAngle = 80f,
                        useCenter = false, topLeft = Offset(c.x - r1, c.y - r1), size = Size(r1 * 2, r1 * 2),
                        style = Stroke(4.dp.toPx(), cap = StrokeCap.Round),
                    )
                }

                // Anillo interior: segmentos cortos
                val r3 = r * 0.26f * sc
                for (i in 0 until 12) {
                    drawArc(
                        col.copy(alpha = 0.6f * b), startAngle = -a * 1.6f + i * 30f, sweepAngle = 16f,
                        useCenter = false, topLeft = Offset(c.x - r3, c.y - r3), size = Size(r3 * 2, r3 * 2),
                        style = Stroke(2.dp.toPx(), cap = StrokeCap.Round),
                    )
                }
            }

            Spacer(Modifier.height(28.dp))
            Text(
                status,
                color = color.copy(alpha = 0.9f),
                fontSize = 12.sp,
                letterSpacing = 4.sp,
                fontWeight = FontWeight.Medium,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                ui.caption,
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 16.sp,
                fontWeight = FontWeight.Light,
                textAlign = TextAlign.Center,
                modifier = Modifier.heightIn(min = 90.dp),
            )
        }
    }

    if (ui.showSettings) {
        SettingsDialog(
            initialName = vm.savedName(),
            hasKey = vm.hasKey(),
            hasWakeKey = vm.hasWakeKey(),
            wakeOn = vm.wakeEnabled(),
            onSave = vm::saveSettings,
            onToggleWake = vm::setWake,
            onDismiss = vm::closeSettings,
        )
    }
}

private fun permissionList(): Array<String> = buildList {
    add(Manifest.permission.RECORD_AUDIO)
    add(Manifest.permission.READ_CONTACTS)
    add(Manifest.permission.CALL_PHONE)
    add(Manifest.permission.SEND_SMS)
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.toTypedArray()

@Composable
private fun SettingsDialog(
    initialName: String,
    hasKey: Boolean,
    hasWakeKey: Boolean,
    wakeOn: Boolean,
    onSave: (String, String, String) -> Unit,
    onToggleWake: (Boolean, String) -> Boolean,
    onDismiss: () -> Unit,
) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf("") }
    var wakeKey by remember { mutableStateOf("") }
    var name by remember { mutableStateOf(initialName) }
    var wake by remember { mutableStateOf(wakeOn) }
    val permsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ajustes de ${Brand.NAME}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true,
                    label = { Text("Tu nombre") },
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = key, onValueChange = { key = it }, singleLine = true,
                    label = { Text(if (hasKey) "Clave de Gemini (ya guardada)" else "Clave de API de Gemini") },
                    placeholder = { Text("AIza...") },
                    visualTransformation = PasswordVisualTransformation(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = wakeKey, onValueChange = { wakeKey = it }, singleLine = true,
                    label = { Text(if (hasWakeKey) "AccessKey de Picovoice (ya guardada)" else "AccessKey de Picovoice") },
                    visualTransformation = PasswordVisualTransformation(),
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Escuchar «Jarvis» siempre", Modifier.weight(1f))
                    Switch(
                        checked = wake,
                        onCheckedChange = { want -> wake = onToggleWake(want, wakeKey) },
                    )
                }
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { permsLauncher.launch(permissionList()) }) {
                    Text("Dar permisos (micrófono, contactos, llamadas, SMS y avisos)")
                }
                TextButton(onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                    )
                }) { Text("Mostrar sobre otras apps (para abrir apps con «Jarvis»)") }
                TextButton(onClick = {
                    if (NotificationManagerCompat.from(ctx).areNotificationsEnabled()) {
                        Hud.notify(ctx, 3000, "SYS // ${Brand.NAME.uppercase()} // PRUEBA", "Notificación de prueba. Todo en orden. 😉")
                    } else {
                        ctx.startActivity(
                            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                        )
                    }
                }) { Text("Probar notificación") }
                TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) {
                    Text("Activar accesibilidad")
                }
                TextButton(onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                    )
                }) { Text("Ajustes de la app") }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(key, name, wakeKey) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
