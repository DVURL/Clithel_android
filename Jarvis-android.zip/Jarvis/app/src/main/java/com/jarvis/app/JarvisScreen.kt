@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.jarvis.app

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlin.math.sin

private val Cyan = Color(0xFF00E5FF)

@Composable
fun JarvisScreen(vm: JarvisViewModel) {
    val ui by vm.ui.collectAsState()
    val ctx = LocalContext.current

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.onOrbTap() else vm.setCaption("Necesito el micrófono para escucharte")
    }
    fun tap() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) vm.onOrbTap() else launcher.launch(Manifest.permission.RECORD_AUDIO)
    }

    // Animación: ángulo y pulso, con velocidad según la fase.
    var angle by remember { mutableFloatStateOf(0f) }
    var pulse by remember { mutableFloatStateOf(0f) }
    val speed by animateFloatAsState(
        when (ui.phase) {
            Phase.IDLE -> 12f
            Phase.LISTENING -> 40f
            Phase.THINKING -> 220f
            Phase.SPEAKING -> 70f
        },
        tween(600), label = "speed",
    )
    LaunchedEffect(Unit) {
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = (now - last) / 1_000_000_000f
            last = now
            angle = (angle + speed * dt) % 360f
            pulse += dt
        }
    }
    val amp = when (ui.phase) {
        Phase.LISTENING -> 0.07f
        Phase.SPEAKING -> 0.05f
        Phase.THINKING -> 0.03f
        Phase.IDLE -> 0.015f
    }

    Column(
        Modifier.fillMaxSize().background(Color.Black).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Canvas(
            Modifier
                .size(280.dp)
                .combinedClickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = { tap() },
                    onLongClick = { vm.openKeyDialog() },
                )
        ) {
            val c = center
            val r = size.minDimension / 2f
            val k = 1f + amp * sin(pulse * 3f)

            // Resplandor del núcleo
            drawCircle(
                Brush.radialGradient(
                    listOf(Cyan.copy(alpha = 0.85f), Cyan.copy(alpha = 0f)),
                    center = c, radius = r * 0.5f * k,
                ),
                radius = r * 0.5f * k, center = c,
            )
            drawCircle(Cyan, radius = r * 0.11f * k, center = c)

            // Anillo exterior fino
            drawCircle(Cyan.copy(alpha = 0.25f), radius = r * 0.96f, center = c, style = Stroke(1.5.dp.toPx()))

            // Anillo 1: tres arcos girando
            val r1 = r * 0.66f
            for (i in 0 until 3) {
                drawArc(
                    Cyan.copy(alpha = 0.9f), startAngle = angle + i * 120f, sweepAngle = 80f,
                    useCenter = false, topLeft = Offset(c.x - r1, c.y - r1), size = Size(r1 * 2, r1 * 2),
                    style = Stroke(4.dp.toPx(), cap = StrokeCap.Round),
                )
            }
            // Anillo 2: contra-rotación
            val r2 = r * 0.82f
            for (i in 0 until 2) {
                drawArc(
                    Cyan.copy(alpha = 0.55f), startAngle = -angle * 0.7f + i * 180f, sweepAngle = 50f,
                    useCenter = false, topLeft = Offset(c.x - r2, c.y - r2), size = Size(r2 * 2, r2 * 2),
                    style = Stroke(2.dp.toPx(), cap = StrokeCap.Round),
                )
            }
        }

        Spacer(Modifier.height(36.dp))
        Text(
            ui.caption,
            color = Cyan.copy(alpha = 0.85f),
            fontSize = 16.sp,
            fontWeight = FontWeight.Light,
            textAlign = TextAlign.Center,
            modifier = Modifier.heightIn(min = 90.dp),
        )
    }

    if (ui.askKey) KeyDialog(onSave = vm::saveKey, onDismiss = vm::closeKeyDialog)
}

@Composable
private fun KeyDialog(onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var key by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Clave de API de Gemini") },
        text = {
            OutlinedTextField(
                value = key, onValueChange = { key = it }, singleLine = true,
                placeholder = { Text("AIza...") },
                visualTransformation = PasswordVisualTransformation(),
            )
        },
        confirmButton = { TextButton(onClick = { onSave(key) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
