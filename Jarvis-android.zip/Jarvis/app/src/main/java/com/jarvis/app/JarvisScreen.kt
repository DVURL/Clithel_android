@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.jarvis.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Pantalla raíz: inicio de sesión si hace falta, si no la pantalla principal. */
@Composable
fun JarvisScreen(vm: JarvisViewModel) {
    val account by vm.account.collectAsState()
    val upd by vm.update.collectAsState()
    val rootCtx = LocalContext.current
    var crash by remember { mutableStateOf(Diag.hasCrash(rootCtx)) }
    var showDiag by remember { mutableStateOf(false) }

    if (account.enabled && !account.signedIn && !account.skipped) {
        AuthScreen(vm, account)
    } else {
        JarvisMain(vm)
    }

    if (upd.show) {
        UpdateDialog(upd, onUpdate = { vm.startUpdate() }, onDismiss = { vm.dismissUpdate() })
    }

    if (crash) {
        AlertDialog(
            onDismissRequest = {
                crash = false
                Diag.dismissCrash(rootCtx)
            },
            title = { Text("${Brand.NAME} se cerró por un error") },
            text = { Text("La última vez la app se cerró sola. Puedes ver y copiar el reporte para que se pueda arreglar.") },
            confirmButton = {
                TextButton(onClick = {
                    crash = false
                    showDiag = true
                }) { Text("Ver reporte") }
            },
            dismissButton = {
                TextButton(onClick = {
                    crash = false
                    Diag.dismissCrash(rootCtx)
                }) { Text("Ahora no") }
            },
        )
    }
    if (showDiag) {
        DiagDialog(vm = vm, onDismiss = {
            showDiag = false
            Diag.dismissCrash(rootCtx)
        })
    }
}

@Composable
private fun JarvisMain(vm: JarvisViewModel) {
    val ui by vm.ui.collectAsState()
    val level by vm.level.collectAsState()
    val theme by vm.theme.collectAsState()
    val ctx = LocalContext.current

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.onOrbTap() else vm.setCaption("Necesito el micrófono para escucharte")
    }
    fun tap() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) vm.onOrbTap() else launcher.launch(Manifest.permission.RECORD_AUDIO)
    }

    // Arranque: los elementos aparecen de a poco
    val boot = remember { Animatable(0f) }
    LaunchedEffect(Unit) { boot.animateTo(1f, tween(2200, easing = FastOutSlowInEasing)) }

    val pal = theme.palette()
    val style = Eyes.style(ui.phase, ui.emotion, pal)
    val color by animateColorAsState(Color(style.ring), tween(500), label = "color")
    val eyeColor by animateColorAsState(Color(style.eye), tween(500), label = "eyeColor")
    val speed by animateFloatAsState(
        when (ui.phase) {
            Phase.IDLE -> 12f
            Phase.LISTENING -> 40f
            Phase.THINKING -> 220f
            Phase.SPEAKING -> 70f
        },
        tween(600), label = "speed",
    )

    val phaseNow = rememberUpdatedState(ui.phase)
    val levelNow = rememberUpdatedState(level)
    val speedNow = rememberUpdatedState(speed)

    var angle by remember { mutableFloatStateOf(0f) }
    var t by remember { mutableFloatStateOf(0f) }
    var lvl by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = (now - last) / 1_000_000_000f
            last = now
            angle = (angle + speedNow.value * dt) % 360f
            t += dt
            val target = when (phaseNow.value) {
                Phase.LISTENING -> levelNow.value
                Phase.SPEAKING -> (0.45f + 0.25f * sin(t * 7.3f) + 0.2f * sin(t * 11.1f + 1f)).coerceIn(0f, 1f)
                Phase.THINKING -> 0.2f + 0.1f * sin(t * 4f)
                Phase.IDLE -> 0f
            }
            lvl += (target - lvl) * min(1f, dt * 12f)
        }
    }

    val booting = boot.value < 1f
    val status = if (booting) "INICIANDO SISTEMAS" else when (ui.phase) {
        Phase.IDLE -> "EN ESPERA"
        Phase.LISTENING -> "ESCUCHANDO"
        Phase.THINKING -> "PROCESANDO"
        Phase.SPEAKING -> "RESPONDIENDO"
    }

    Box(Modifier.fillMaxSize()) {
        Background(theme = theme, tint = color, time = { t })

        Text(
            Brand.NAME.uppercase(),
            color = color.copy(alpha = 0.45f),
            fontSize = 12.sp,
            letterSpacing = 8.sp,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 56.dp),
        )

        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Canvas(
                Modifier
                    .size(300.dp)
                    .combinedClickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = { tap() },
                        onLongClick = { vm.openSettings() },
                    )
            ) {
                val c = center
                val r = size.minDimension / 2f
                val b = boot.value
                val sc = 0.6f + 0.4f * b
                val a = angle
                val l = lvl
                val col = color
                val k = 1f + (0.015f + 0.05f * l) * sin(t * 3f)

                // Resplandor (reacciona al volumen)
                val gr = r * (0.5f + 0.22f * l) * k * sc
                drawCircle(
                    Brush.radialGradient(
                        listOf(col.copy(alpha = 0.85f * b), col.copy(alpha = 0f)),
                        center = c, radius = gr,
                    ),
                    radius = gr, center = c,
                )

                // Ojos (parpadean, miran, se mueven y cambian de color según la emoción)
                val pose = Eyes.pose(style, ui.phase, t, l)
                val s = r * 0.27f * sc
                val ec = eyeColor.copy(alpha = b)
                for (i in 0..1) {
                    val sign = if (i == 0) -1f else 1f
                    val ex = c.x + (sign * pose.gap + pose.look) * s
                    val ey = c.y + pose.y * s
                    val ew = pose.w * s
                    val eh = pose.h * s
                    rotate(if (i == 0) pose.tilt else -pose.tilt, Offset(ex, ey)) {
                        drawRoundRect(
                            ec,
                            topLeft = Offset(ex - ew / 2f, ey - eh / 2f),
                            size = Size(ew, eh),
                            cornerRadius = CornerRadius(min(ew, eh) / 2f),
                        )
                    }
                }

                // Onda de voz
                if (l > 0.02f) {
                    drawCircle(
                        col.copy(alpha = 0.15f + 0.4f * l),
                        radius = r * (0.30f + 0.22f * l) * sc, center = c,
                        style = Stroke(1.5.dp.toPx()),
                    )
                }

                // Anillo exterior fino
                drawCircle(col.copy(alpha = 0.25f * b), radius = r * 0.97f * sc, center = c, style = Stroke(1.dp.toPx()))

                // Marcas tipo panel de control
                val tickCount = 72
                val visible = (tickCount * b).toInt()
                val rot = a * 0.25f
                for (i in 0 until visible) {
                    val long = i % 6 == 0
                    val ang = Math.toRadians(i * 360.0 / tickCount + rot).toFloat()
                    val r0 = r * (if (long) 0.85f else 0.89f) * sc
                    val rOut = r * 0.93f * sc
                    drawLine(
                        col.copy(alpha = if (long) 0.8f else 0.35f),
                        Offset(c.x + cos(ang) * r0, c.y + sin(ang) * r0),
                        Offset(c.x + cos(ang) * rOut, c.y + sin(ang) * rOut),
                        strokeWidth = (if (long) 2.dp else 1.dp).toPx(),
                    )
                }

                // Anillo medio: dos arcos finos, giro inverso
                val r2 = r * 0.78f * sc
                for (i in 0 until 2) {
                    drawArc(
                        col.copy(alpha = 0.55f * b), startAngle = -a * 0.7f + i * 180f, sweepAngle = 50f,
                        useCenter = false, topLeft = Offset(c.x - r2, c.y - r2), size = Size(r2 * 2, r2 * 2),
                        style = Stroke(2.dp.toPx(), cap = StrokeCap.Round),
                    )
                }

                // Anillo principal: tres arcos gruesos
                val rMain = r * 0.64f * (1f + 0.04f * l) * sc
                for (i in 0 until 3) {
                    drawArc(
                        col.copy(alpha = 0.9f * b), startAngle = a + i * 120f, sweepAngle = 80f,
                        useCenter = false, topLeft = Offset(c.x - rMain, c.y - rMain), size = Size(rMain * 2, rMain * 2),
                        style = Stroke(4.dp.toPx(), cap = StrokeCap.Round),
                    )
                }

                // Anillo interior: segmentos cortos
                val r3 = r * 0.26f * sc
                for (i in 0 until 12) {
                    drawArc(
                        col.copy(alpha = 0.6f * b), startAngle = -a * 1.6f + i * 30f, sweepAngle = 16f,
                        useCenter = false, topLeft = Offset(c.x - r3, c.y - r3), size = Size(r3 * 2, r3 * 2),
                        style = Stroke(2.dp.toPx(), cap = StrokeCap.Round),
                    )
                }
            }

            Spacer(Modifier.height(28.dp))
            Text(
                status,
                color = color.copy(alpha = 0.9f),
                fontSize = 12.sp,
                letterSpacing = 4.sp,
                fontWeight = FontWeight.Medium,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                ui.caption,
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 16.sp,
                fontWeight = FontWeight.Light,
                textAlign = TextAlign.Center,
                modifier = Modifier.heightIn(min = 90.dp),
            )
        }

        Text(
            "AJUSTES",
            color = color.copy(alpha = 0.45f),
            fontSize = 11.sp,
            letterSpacing = 4.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 36.dp)
                .clickable { vm.openSettings() }
                .padding(12.dp),
        )
    }

    if (ui.showSettings) {
        SettingsDialog(vm = vm, onDismiss = { vm.closeSettings() })
    }
}

// ============================ Fondo ============================

private fun loadImage(ctx: Context, uriStr: String): ImageBitmap? = try {
    val uri = Uri.parse(uriStr)
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }?.asImageBitmap()
} catch (_: Exception) {
    null
}

@Composable
private fun Background(theme: ThemeSettings, tint: Color, time: () -> Float) {
    val ctx = LocalContext.current
    val stars = remember {
        List(90) { i ->
            val rnd = java.util.Random(i * 7919L + 13L)
            floatArrayOf(
                rnd.nextFloat(),                    // x
                rnd.nextFloat(),                    // y
                0.6f + rnd.nextFloat() * 1.6f,      // tamaño
                rnd.nextFloat() * 6.28f,            // fase
                0.4f + rnd.nextFloat(),             // velocidad
            )
        }
    }
    var image by remember { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(theme.bg, theme.bgImage) {
        image = if (theme.bg == "imagen" && theme.bgImage.isNotBlank()) {
            withContext(Dispatchers.IO) { loadImage(ctx, theme.bgImage) }
        } else {
            null
        }
    }

    Canvas(Modifier.fillMaxSize()) {
        when (theme.bg) {
            "noche" -> drawRect(Color(0xFF050A18))
            "carbon" -> drawRect(Color(0xFF14161A))
            "degradado" -> drawRect(
                Brush.verticalGradient(
                    listOf(Color.Black, Color(ColorUtils.blendARGB(0xFF000000.toInt(), tint.toArgb(), 0.28f)))
                )
            )
            "estrellas" -> {
                drawRect(Color(0xFF02030A))
                val tt = time()
                for (s in stars) {
                    val tw = 0.35f + 0.65f * abs(sin(tt * s[4] + s[3]))
                    val x = s[0] * size.width
                    val y = ((s[1] + tt * 0.004f * s[4]) % 1f) * size.height
                    drawCircle(Color.White.copy(alpha = tw * 0.9f), radius = s[2] * density, center = Offset(x, y))
                }
            }
            "imagen" -> {
                val img = image
                if (img != null) {
                    val scale = max(size.width / img.width, size.height / img.height)
                    val srcW = (size.width / scale).toInt().coerceIn(1, img.width)
                    val srcH = (size.height / scale).toInt().coerceIn(1, img.height)
                    drawImage(
                        img,
                        srcOffset = IntOffset((img.width - srcW) / 2, (img.height - srcH) / 2),
                        srcSize = IntSize(srcW, srcH),
                        dstSize = IntSize(size.width.toInt(), size.height.toInt()),
                    )
                } else {
                    drawRect(Color.Black)
                }
                drawRect(Color.Black.copy(alpha = 0.45f))
            }
            else -> drawRect(Color.Black)
        }
    }
}

// ============================ Ajustes ============================

private fun permissionList(): Array<String> = buildList {
    add(Manifest.permission.RECORD_AUDIO)
    add(Manifest.permission.READ_CONTACTS)
    add(Manifest.permission.CALL_PHONE)
    add(Manifest.permission.SEND_SMS)
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.toTypedArray()

@Composable
private fun SettingsDialog(vm: JarvisViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val account by vm.account.collectAsState()
    var key by remember { mutableStateOf("") }
    var assistant by remember { mutableStateOf(vm.assistantName()) }
    var showAliases by remember { mutableStateOf(false) }
    var showDiag by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(vm.savedName()) }
    val wakeUi by vm.wake.collectAsState()
    var showTheme by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val permsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }
    val version = remember {
        try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
        } catch (_: Exception) {
            ""
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ajustes de ${Brand.NAME}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true,
                    label = { Text("Tu nombre") },
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = key, onValueChange = { key = it }, singleLine = true,
                    label = { Text(if (vm.hasKey()) "Clave de Gemini (ya guardada)" else "Clave de API de Gemini") },
                    placeholder = { Text("AIza...") },
                    visualTransformation = PasswordVisualTransformation(),
                )

                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = assistant, onValueChange = { assistant = it }, singleLine = true,
                    label = { Text("Cómo quieres llamar a tu asistente") },
                    supportingText = { Text("${Brand.NAME} es la marca de la app. Este es el nombre con el que te responde.") },
                )

                if (account.enabled) {
                    Spacer(Modifier.height(14.dp))
                    Text(
                        if (account.signedIn) "Cuenta: ${account.email}" else "Sin cuenta (tu memoria solo está en este celular)",
                        fontWeight = FontWeight.Medium,
                    )
                    if (account.message.isNotBlank()) {
                        Text(account.message, fontSize = 13.sp, color = Color(0xFFFFB300))
                    }
                    if (account.signedIn) {
                        TextButton(onClick = { vm.syncNow() }) { Text("Sincronizar ahora") }
                        TextButton(onClick = {
                            vm.signOut()
                            onDismiss()
                        }) { Text("Cerrar sesión") }
                        TextButton(onClick = { confirmDelete = true }) { Text("Eliminar mi cuenta") }
                    } else {
                        TextButton(onClick = {
                            vm.showAuth()
                            onDismiss()
                        }) { Text("Iniciar sesión o crear cuenta") }
                    }
                }

                Spacer(Modifier.height(6.dp))
                TextButton(onClick = { showTheme = true }) { Text("Colores y fondo") }
                TextButton(onClick = { showAliases = true }) { Text("Etiquetas de apps") }
                TextButton(onClick = { showDiag = true }) { Text("Reporte de errores") }
                TextButton(onClick = {
                    vm.checkUpdates(true)
                    onDismiss()
                }) { Text("Buscar actualización (versión $version)") }

                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Escuchar «${assistant.ifBlank { Brand.NAME }}» siempre", Modifier.weight(1f))
                    Switch(
                        checked = wakeUi.enabled,
                        onCheckedChange = { want ->
                            vm.setAssistantName(assistant)
                            vm.setWake(want)
                        },
                    )
                }
                if (wakeUi.status.isNotBlank()) {
                    Text(wakeUi.status, fontSize = 13.sp, color = Color(0xFFFFB300))
                }
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { permsLauncher.launch(permissionList()) }) {
                    Text("Dar permisos (micrófono, contactos, llamadas, SMS y avisos)")
                }
                TextButton(onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                    )
                }) { Text("Mostrar sobre otras apps") }
                TextButton(onClick = {
                    if (NotificationManagerCompat.from(ctx).areNotificationsEnabled()) {
                        Hud.notify(ctx, 3000, "SYS // ${Brand.NAME.uppercase()} // PRUEBA", "Notificación de prueba. Todo en orden. 😉")
                    } else {
                        ctx.startActivity(
                            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                        )
                    }
                }) { Text("Probar notificación") }
                TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) {
                    Text("Activar accesibilidad")
                }
                TextButton(onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                    )
                }) { Text("Ajustes de la app") }
            }
        },
        confirmButton = { TextButton(onClick = { vm.saveSettings(key, name, assistant) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )

    if (showTheme) {
        ThemeDialog(vm = vm, onDismiss = { showTheme = false })
    }

    if (showAliases) {
        AliasDialog(vm = vm, onDismiss = { showAliases = false })
    }

    if (showDiag) {
        DiagDialog(vm = vm, onDismiss = { showDiag = false })
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("¿Eliminar tu cuenta?") },
            text = { Text("Se borrarán tu cuenta y los datos guardados en la nube. Esto no se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.deleteAccount()
                    onDismiss()
                }) { Text("Eliminar") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } },
        )
    }
}

// ============================ Colores y fondo ============================

@Composable
private fun PaletteRow(p: Palette, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(p.name, Modifier.weight(1f))
        listOf(p.idleRing, p.listening, p.thinking, p.speaking, p.happy).forEach {
            Box(Modifier.padding(start = 4.dp).size(14.dp).background(Color(it), CircleShape))
        }
    }
}

@Composable
private fun ThemeDialog(vm: JarvisViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val theme by vm.theme.collectAsState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            vm.setTheme(theme.copy(bg = "imagen", bgImage = uri.toString()))
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Colores y fondo") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Paleta de colores", fontWeight = FontWeight.Medium)
                Palettes.ALL.forEach { p ->
                    PaletteRow(p, selected = theme.paletteId == p.id) {
                        vm.setTheme(theme.copy(paletteId = p.id))
                    }
                }
                PaletteRow(Palettes.custom(theme.hue), selected = theme.paletteId == "custom") {
                    vm.setTheme(theme.copy(paletteId = "custom"))
                }
                if (theme.paletteId == "custom") {
                    Text("Elige el tono", fontSize = 13.sp)
                    Slider(
                        value = theme.hue.toFloat(),
                        onValueChange = { vm.setTheme(theme.copy(paletteId = "custom", hue = it.toInt())) },
                        valueRange = 0f..360f,
                    )
                }

                Spacer(Modifier.height(14.dp))
                Text("Fondo", fontWeight = FontWeight.Medium)
                BACKGROUNDS.forEach { (id, label) ->
                    val choose = {
                        if (id == "imagen") picker.launch(arrayOf("image/*"))
                        else vm.setTheme(theme.copy(bg = id))
                    }
                    Row(
                        Modifier.fillMaxWidth().clickable { choose() }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = theme.bg == id, onClick = { choose() })
                        Text(if (id == "imagen") "Mi foto (elegir de la galería)" else label)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Listo") } },
    )
}

// ============================ Actualizaciones ============================

@Composable
private fun UpdateDialog(u: UpdateUi, onUpdate: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = { if (!u.downloading) onDismiss() },
        title = { Text("Nueva versión disponible") },
        text = {
            Column {
                Text("Versión ${u.info?.tag.orEmpty()}")
                val notes = u.info?.notes.orEmpty().take(400)
                if (notes.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(notes, fontSize = 13.sp)
                }
                if (u.downloading) {
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(progress = { u.progress / 100f }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(4.dp))
                    Text("Descargando… ${u.progress}%", fontSize = 13.sp)
                }
                if (u.message.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(u.message, fontSize = 13.sp, color = Color(0xFFFFB300))
                }
            }
        },
        confirmButton = { TextButton(enabled = !u.downloading, onClick = onUpdate) { Text("Actualizar") } },
        dismissButton = { TextButton(enabled = !u.downloading, onClick = onDismiss) { Text("Ahora no") } },
    )
}

// ============================ Iniciar sesión ============================

@Composable
private fun AuthScreen(vm: JarvisViewModel, account: AccountUi) {
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(
                Brand.NAME.uppercase(),
                color = Color(Eyes.CYAN),
                fontSize = 22.sp,
                letterSpacing = 10.sp,
            )
            Spacer(Modifier.height(20.dp))
            Text(
                "Inicia sesión o crea tu cuenta para que ${Brand.NAME} te recuerde, incluso si reinstalas la app.",
                color = Color.White.copy(alpha = 0.75f),
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(
                value = email, onValueChange = { email = it }, singleLine = true,
                label = { Text("Correo") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = pass, onValueChange = { pass = it }, singleLine = true,
                label = { Text("Contraseña") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(16.dp))

            if (account.busy) {
                CircularProgressIndicator()
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { vm.signIn(email, pass) }) { Text("Iniciar sesión") }
                    Spacer(Modifier.width(12.dp))
                    OutlinedButton(onClick = { vm.signUp(email, pass) }) { Text("Crear cuenta") }
                }
            }

            if (account.message.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Text(
                    account.message,
                    color = Color(0xFFFFB300),
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                )
            }

            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { vm.resetPassword(email) }) { Text("Olvidé mi contraseña") }
            TextButton(onClick = { vm.skipAuth() }) { Text("Continuar sin cuenta") }
            Text(
                "Sin cuenta, tu memoria se perderá si desinstalas la app.",
                color = Color.White.copy(alpha = 0.45f),
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
            )
        }
    }
}

// ============================ Etiquetas de apps ============================

@Composable
private fun AliasDialog(vm: JarvisViewModel, onDismiss: () -> Unit) {
    val aliases by vm.aliases.collectAsState()
    var picking by remember { mutableStateOf(false) }
    var picked by remember { mutableStateOf<AppEntry?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Etiquetas de apps") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "Ponle a tus apps el nombre con el que quieras llamarlas. Después di, por ejemplo, \"abre billar\" y se abrirá directo, sin internet.",
                    fontSize = 13.sp,
                )
                Spacer(Modifier.height(10.dp))
                if (aliases.isEmpty()) {
                    Text("Todavía no tienes etiquetas.", fontSize = 13.sp)
                }
                aliases.forEach { a ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(a.alias, fontWeight = FontWeight.Medium)
                            Text(a.label, fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
                        }
                        TextButton(onClick = { vm.removeAlias(a.alias) }) { Text("Quitar") }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = { picking = true }) { Text("Agregar etiqueta") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Listo") } },
    )

    if (picking) {
        AppPickerDialog(
            onPick = {
                picked = it
                picking = false
            },
            onDismiss = { picking = false },
        )
    }

    picked?.let { app ->
        NewAliasDialog(
            app = app,
            onSave = { alias ->
                vm.addAlias(alias, app.pkg, app.label)
                picked = null
            },
            onDismiss = { picked = null },
        )
    }
}

@Composable
private fun AppPickerDialog(onPick: (AppEntry) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { AppCatalog.list(ctx) } }
    val shown = remember(apps, query) {
        val q = Norm.of(query)
        if (q.isEmpty()) apps else apps.filter { Norm.of(it.label).contains(q) }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Elige la app") },
        text = {
            Column {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    label = { Text("Buscar") },
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(shown) { app ->
                        Text(
                            app.label,
                            Modifier.fillMaxWidth().clickable { onPick(app) }.padding(vertical = 12.dp),
                        )
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
private fun NewAliasDialog(app: AppEntry, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var alias by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Etiqueta para ${app.label}") },
        text = {
            Column {
                Text("¿Cómo quieres llamarla? Por ejemplo: billar, música, libros.", fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = alias, onValueChange = { alias = it }, singleLine = true,
                    label = { Text("Etiqueta") },
                )
            }
        },
        confirmButton = { TextButton(enabled = alias.isNotBlank(), onClick = { onSave(alias) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

// ============================ Reporte de errores ============================

@Composable
private fun DiagDialog(vm: JarvisViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val text by vm.diag.collectAsState()
    LaunchedEffect(Unit) { vm.runDiagnostics() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Reporte de errores") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "Copia el reporte y mándaselo a quien te ayuda a arreglar la app. No incluye tus claves, tu correo ni lo que has dicho.",
                    fontSize = 12.sp,
                )
                Spacer(Modifier.height(8.dp))
                if (text.isBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Revisando…", fontSize = 13.sp)
                    }
                } else {
                    Text(text, fontSize = 11.sp, fontFamily = FontFamily.Monospace, lineHeight = 14.sp)
                }
            }
        },
        confirmButton = {
            Row {
                TextButton(enabled = text.isNotBlank(), onClick = {
                    val cm = ctx.getSystemService(ClipboardManager::class.java)
                    cm.setPrimaryClip(ClipData.newPlainText("Reporte de ${Brand.NAME}", text))
                    Toast.makeText(ctx, "Reporte copiado", Toast.LENGTH_SHORT).show()
                }) { Text("Copiar") }
                TextButton(enabled = text.isNotBlank(), onClick = {
                    val send = Intent(Intent.ACTION_SEND)
                        .setType("text/plain")
                        .putExtra(Intent.EXTRA_TEXT, text)
                    ctx.startActivity(Intent.createChooser(send, "Compartir reporte"))
                }) { Text("Compartir") }
            }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { vm.clearDiagnostics() }) { Text("Borrar") }
                TextButton(onClick = onDismiss) { Text("Cerrar") }
            }
        },
    )
}
