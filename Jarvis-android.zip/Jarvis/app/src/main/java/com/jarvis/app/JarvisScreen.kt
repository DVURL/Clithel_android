@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.jarvis.app

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

// Colores por estado
private val ColIdle = Color(0xFF00E5FF)      // cian
private val ColListening = Color(0xFF00FF9C) // verde menta
private val ColThinking = Color(0xFFFFB300)  // ámbar
private val ColSpeaking = Color(0xFF4DA6FF)  // azul

@Composable
fun JarvisScreen(vm: JarvisViewModel) {
    val ui by vm.ui.collectAsState()
    val level by vm.level.collectAsState()
    val ctx = LocalContext.current

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.onOrbTap() else vm.setCaption("Necesito el micrófono para escucharte")
    }
    fun tap() {
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) vm.onOrbTap() else launcher.launch(Manifest.permission.RECORD_AUDIO)
    }

    // Arranque: los elementos aparecen de a poco
    val boot = remember { Animatable(0f) }
    LaunchedEffect(Unit) { boot.animateTo(1f, tween(2200, easing = FastOutSlowInEasing)) }

    val color by animateColorAsState(
        when (ui.phase) {
            Phase.IDLE -> ColIdle
            Phase.LISTENING -> ColListening
            Phase.THINKING -> ColThinking
            Phase.SPEAKING -> ColSpeaking
        },
        tween(500), label = "color",
    )
    val speed by animateFloatAsState(
        when (ui.phase) {
            Phase.IDLE -> 12f
            Phase.LISTENING -> 40f
            Phase.THINKING -> 220f
            Phase.SPEAKING -> 70f
        },
        tween(600), label = "speed",
    )

    val phaseNow = rememberUpdatedState(ui.phase)
    val levelNow = rememberUpdatedState(level)
    val speedNow = rememberUpdatedState(speed)

    var angle by remember { mutableFloatStateOf(0f) }
    var t by remember { mutableFloatStateOf(0f) }
    var lvl by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = (now - last) / 1_000_000_000f
            last = now
            angle = (angle + speedNow.value * dt) % 360f
            t += dt
            val target = when (phaseNow.value) {
                Phase.LISTENING -> levelNow.value
                Phase.SPEAKING -> (0.45f + 0.25f * sin(t * 7.3f) + 0.2f * sin(t * 11.1f + 1f)).coerceIn(0f, 1f)
                Phase.THINKING -> 0.2f + 0.1f * sin(t * 4f)
                Phase.IDLE -> 0f
            }
            lvl += (target - lvl) * min(1f, dt * 12f)
        }
    }

    val booting = boot.value < 1f
    val status = if (booting) "INICIANDO SISTEMAS" else when (ui.phase) {
        Phase.IDLE -> "EN ESPERA"
        Phase.LISTENING -> "ESCUCHANDO"
        Phase.THINKING -> "PROCESANDO"
        Phase.SPEAKING -> "RESPONDIENDO"
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Text(
            "J.A.R.V.I.S",
            color = color.copy(alpha = 0.45f),
            fontSize = 12.sp,
            letterSpacing = 6.sp,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 56.dp),
        )

        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Canvas(
                Modifier
                    .size(300.dp)
                    .combinedClickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = { tap() },
                        onLongClick = { vm.openKeyDialog() },
                    )
            ) {
                val c = center
                val r = size.minDimension / 2f
                val b = boot.value
                val sc = 0.6f + 0.4f * b
                val a = angle
                val l = lvl
                val col = color
                val k = 1f + (0.015f + 0.05f * l) * sin(t * 3f)

                // Resplandor y núcleo (reaccionan al volumen)
                val gr = r * (0.5f + 0.22f * l) * k * sc
                drawCircle(
                    Brush.radialGradient(
                        listOf(col.copy(alpha = 0.85f * b), col.copy(alpha = 0f)),
                        center = c, radius = gr,
                    ),
                    radius = gr, center = c,
                )
                drawCircle(col.copy(alpha = b), radius = r * (0.10f + 0.045f * l) * k * sc, center = c)

                // Onda de voz
                if (l > 0.02f) {
                    drawCircle(
                        col.copy(alpha = 0.15f + 0.4f * l),
                        radius = r * (0.30f + 0.22f * l) * sc, center = c,
                        style = Stroke(1.5.dp.toPx()),
                    )
                }

                // Anillo exterior fino
                drawCircle(col.copy(alpha = 0.25f * b), radius = r * 0.97f * sc, center = c, style = Stroke(1.dp.toPx()))

                // Marcas tipo panel de control
                val tickCount = 72
                val visible = (tickCount * b).toInt()
                val rot = a * 0.25f
                for (i in 0 until visible) {
                    val long = i % 6 == 0
                    val ang = Math.toRadians(i * 360.0 / tickCount + rot).toFloat()
                    val r0 = r * (if (long) 0.85f else 0.89f) * sc
                    val r1 = r * 0.93f * sc
                    drawLine(
                        col.copy(alpha = if (long) 0.8f else 0.35f),
                        Offset(c.x + cos(ang) * r0, c.y + sin(ang) * r0),
                        Offset(c.x + cos(ang) * r1, c.y + sin(ang) * r1),
                        strokeWidth = (if (long) 2.dp else 1.dp).toPx(),
                    )
                }

                // Anillo medio: dos arcos finos, giro inverso
                val r2 = r * 0.78f * sc
                for (i in 0 until 2) {
                    drawArc(
                        col.copy(alpha = 0.55f * b), startAngle = -a * 0.7f + i * 180f, sweepAngle = 50f,
                        useCenter = false, topLeft = Offset(c.x - r2, c.y - r2), size = Size(r2 * 2, r2 * 2),
                        style = Stroke(2.dp.toPx(), cap = StrokeCap.Round),
                    )
                }

                // Anillo principal: tres arcos gruesos
                val r1 = r * 0.64f * (1f + 0.04f * l) * sc
                for (i in 0 until 3) {
                    drawArc(
                        col.copy(alpha = 0.9f * b), startAngle = a + i * 120f, sweepAngle = 80f,
                        useCenter = false, topLeft = Offset(c.x - r1, c.y - r1), size = Size(r1 * 2, r1 * 2),
                        style = Stroke(4.dp.toPx(), cap = StrokeCap.Round),
                    )
                }

                // Anillo interior: segmentos cortos
                val r3 = r * 0.26f * sc
                for (i in 0 until 12) {
                    drawArc(
                        col.copy(alpha = 0.6f * b), startAngle = -a * 1.6f + i * 30f, sweepAngle = 16f,
                        useCenter = false, topLeft = Offset(c.x - r3, c.y - r3), size = Size(r3 * 2, r3 * 2),
                        style = Stroke(2.dp.toPx(), cap = StrokeCap.Round),
                    )
                }
            }

            Spacer(Modifier.height(28.dp))
            Text(
                status,
                color = color.copy(alpha = 0.9f),
                fontSize = 12.sp,
                letterSpacing = 4.sp,
                fontWeight = FontWeight.Medium,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                ui.caption,
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 16.sp,
                fontWeight = FontWeight.Light,
                textAlign = TextAlign.Center,
                modifier = Modifier.heightIn(min = 90.dp),
            )
        }
    }

    if (ui.askKey) KeyDialog(onSave = vm::saveKey, onDismiss = vm::closeKeyDialog)
}

@Composable
private fun KeyDialog(onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var key by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Clave de API de Gemini") },
        text = {
            OutlinedTextField(
                value = key, onValueChange = { key = it }, singleLine = true,
                placeholder = { Text("AIza...") },
                visualTransformation = PasswordVisualTransformation(),
            )
        },
        confirmButton = { TextButton(onClick = { onSave(key) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
