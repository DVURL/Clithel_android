package com.jarvis.app

import android.content.Context
import android.graphics.Color as AColor

data class Palette(
    val id: String,
    val name: String,
    val idleRing: Int,
    val idleEye: Int,
    val listening: Int,
    val thinking: Int,
    val speaking: Int,
    val happy: Int,
    val sad: Int,
    val angry: Int,
    val surprised: Int,
)

object Palettes {
    private fun c(hex: Long): Int = hex.toInt()

    val CLASSIC = Palette(
        "clasico", "Clásico",
        c(0xFF00E5FF), c(0xFFF2F7FF), c(0xFF00FF9C), c(0xFFFFB300), c(0xFF4DA6FF),
        c(0xFFFFD54F), c(0xFF8C9EFF), c(0xFFFF5252), c(0xFFB3F5FF),
    )
    val NEON = Palette(
        "neon", "Neón",
        c(0xFFFF2BD6), c(0xFFFFFFFF), c(0xFF39FF14), c(0xFFFFE600), c(0xFF00F0FF),
        c(0xFFFF6EC7), c(0xFF9D6BFF), c(0xFFFF1744), c(0xFFFFFFFF),
    )
    val FUEGO = Palette(
        "fuego", "Fuego",
        c(0xFFFF6D00), c(0xFFFFF3E0), c(0xFFFFC400), c(0xFFFF9100), c(0xFFFF3D00),
        c(0xFFFFD740), c(0xFFBCAAA4), c(0xFFD50000), c(0xFFFFE57F),
    )
    val HIELO = Palette(
        "hielo", "Hielo",
        c(0xFF7DD3FC), c(0xFFF0F9FF), c(0xFF5EEAD4), c(0xFFA5B4FC), c(0xFF38BDF8),
        c(0xFFFDE68A), c(0xFF93C5FD), c(0xFFF87171), c(0xFFE0F2FE),
    )
    val BOSQUE = Palette(
        "bosque", "Bosque",
        c(0xFF34D399), c(0xFFECFDF5), c(0xFFA3E635), c(0xFFFBBF24), c(0xFF2DD4BF),
        c(0xFFFDE047), c(0xFF86EFAC), c(0xFFF97316), c(0xFFD9F99D),
    )
    val VIOLETA = Palette(
        "violeta", "Violeta",
        c(0xFFA78BFA), c(0xFFF5F3FF), c(0xFF34D399), c(0xFFF59E0B), c(0xFFC084FC),
        c(0xFFF9A8D4), c(0xFF818CF8), c(0xFFFB7185), c(0xFFE9D5FF),
    )
    val MONO = Palette(
        "mono", "Monocromo",
        c(0xFFE5E7EB), c(0xFFFFFFFF), c(0xFFFFFFFF), c(0xFFD1D5DB), c(0xFFE5E7EB),
        c(0xFFFFFFFF), c(0xFF9CA3AF), c(0xFFF3F4F6), c(0xFFFFFFFF),
    )

    val ALL = listOf(CLASSIC, NEON, FUEGO, HIELO, BOSQUE, VIOLETA, MONO)

    /** Paleta personalizada: un solo tono (0-360) para los anillos y al hablar. */
    fun custom(hue: Int): Palette {
        val main = AColor.HSVToColor(floatArrayOf(hue.coerceIn(0, 360).toFloat(), 0.85f, 1f))
        return CLASSIC.copy(id = "custom", name = "Personalizado", idleRing = main, speaking = main)
    }

    fun get(id: String, hue: Int): Palette =
        if (id == "custom") custom(hue) else ALL.firstOrNull { it.id == id } ?: CLASSIC
}

/** Fondos disponibles: id y nombre. */
val BACKGROUNDS = listOf(
    "negro" to "Negro",
    "noche" to "Azul noche",
    "carbon" to "Carbón",
    "degradado" to "Degradado",
    "estrellas" to "Estrellas",
    "imagen" to "Mi foto",
)

data class ThemeSettings(
    val paletteId: String = "clasico",
    val hue: Int = 190,
    val bg: String = "negro",
    val bgImage: String = "",
) {
    fun palette(): Palette = Palettes.get(paletteId, hue)
}

object ThemeStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("theme", Context.MODE_PRIVATE)

    fun load(ctx: Context): ThemeSettings {
        val p = prefs(ctx)
        return ThemeSettings(
            paletteId = p.getString("palette", null) ?: "clasico",
            hue = p.getInt("hue", 190),
            bg = p.getString("bg", null) ?: "negro",
            bgImage = p.getString("bgImage", null) ?: "",
        )
    }

    fun save(ctx: Context, t: ThemeSettings) {
        prefs(ctx).edit()
            .putString("palette", t.paletteId)
            .putInt("hue", t.hue)
            .putString("bg", t.bg)
            .putString("bgImage", t.bgImage)
            .apply()
    }
}
