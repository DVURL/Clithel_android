package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import kotlin.math.abs
import kotlin.math.min

/** ¿Lo que se oyó contiene el nombre del asistente? Compara por sonido, tolera pronunciaciones distintas. */
object WakeMatcher {
    /** Aproximación fonética del español: "Clithel", "clítel" y "quitel" quedan muy cerca. */
    private fun phon(s: String): String {
        var t = Norm.of(s).replace(" ", "")
        t = t.replace("qu", "k").replace("ll", "i").replace("th", "t")
        val sb = StringBuilder()
        for (i in t.indices) {
            val c = t[i]
            val next = if (i + 1 < t.length) t[i + 1] else ' '
            val mapped = when (c) {
                'c' -> if (next == 'e' || next == 'i') 's' else 'k'
                'z' -> 's'
                'v' -> 'b'
                'w' -> 'u'
                'y' -> 'i'
                'h' -> null
                else -> c
            }
            if (mapped != null && (sb.isEmpty() || sb.last() != mapped)) sb.append(mapped)
        }
        return sb.toString()
    }

    fun matches(heard: String, name: String): Boolean {
        val target = phon(name)
        if (target.length < 3) return false
        val words = Norm.of(heard).split(" ").filter { it.isNotEmpty() }
        if (words.isEmpty()) return false
        // palabras sueltas y pares pegados ("cli tel" -> "clitel")
        val candidates = (words + words.zipWithNext { a, b -> a + b }).map { phon(it) }
        val maxDist = if (target.length <= 4) 1 else 2
        return candidates.any { c ->
            abs(c.length - target.length) <= maxDist && distance(c, target) <= maxDist
        }
    }

    private fun distance(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = min(min(dp[j] + 1, dp[j - 1] + 1), prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }
}

/**
 * Escucha el nombre del asistente con Vosk: reconocimiento de voz gratuito y sin internet,
 * dentro de la propia app. No usa los servicios de Google, así que no hay pitidos.
 */
class WakeWordService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var speech: SpeechService? = null
    private var wanted = false
    private var phaseJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences("jarvis", Context.MODE_PRIVATE)

        if (intent?.action == ACTION_STOP) {
            prefs.edit().putBoolean("wake_enabled", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)

        phaseJob?.cancel()
        phaseJob = scope.launch {
            if (model == null) {
                model = withContext(Dispatchers.IO) { VoskModel.load(applicationContext) }
            }
            if (model == null) {
                Hud.notify(
                    this@WakeWordService, 4000, "SYS // VOZ // ERROR",
                    "No pude cargar la voz. Vuelve a activar \"Escuchar siempre\" en Ajustes.",
                )
                prefs.edit().putBoolean("wake_enabled", false).apply()
                stopSelf()
                return@launch
            }
            // Solo escucha cuando Clithel está en espera, para no chocar con su propia voz
            Engine.get(applicationContext).ui
                .map { it.phase }
                .distinctUntilChanged()
                .collect { phase -> if (phase == Phase.IDLE) resume() else pause() }
        }
        return START_STICKY
    }

    private fun assistantName(): String =
        getSharedPreferences("jarvis", Context.MODE_PRIVATE)
            .getString("assistant_name", "").orEmpty().ifBlank { Brand.NAME }

    private fun resume() {
        wanted = true
        begin()
    }

    private fun pause() {
        wanted = false
        main.removeCallbacksAndMessages(null)
        stopRecognition()
    }

    private val listener = object : org.vosk.android.RecognitionListener {
        override fun onPartialResult(hypothesis: String?) { check(hypothesis) }
        override fun onResult(hypothesis: String?) { check(hypothesis) }
        override fun onFinalResult(hypothesis: String?) { check(hypothesis) }
        override fun onError(exception: Exception?) { restartSoon(1500L) }
        override fun onTimeout() { restartSoon(400L) }
    }

    private fun begin() {
        if (!wanted || speech != null) return
        val m = model ?: return
        try {
            val rec = Recognizer(m, 16000.0f)
            val svc = SpeechService(rec, 16000.0f)
            recognizer = rec
            speech = svc
            svc.startListening(listener)
        } catch (_: Throwable) {
            stopRecognition()
            restartSoon(2000L)
        }
    }

    private fun restartSoon(delayMs: Long) {
        stopRecognition()
        if (wanted) main.postDelayed({ begin() }, delayMs)
    }

    private fun stopRecognition() {
        val svc = speech
        val rec = recognizer
        speech = null
        recognizer = null
        if (svc != null) {
            try { svc.cancel() } catch (_: Throwable) { }
            try { svc.shutdown() } catch (_: Throwable) { }
        }
        if (rec != null) {
            try { (rec as? AutoCloseable)?.close() } catch (_: Throwable) { }
        }
    }

    private fun check(hypothesis: String?) {
        if (hypothesis.isNullOrBlank()) return
        val text = try {
            val o = JSONObject(hypothesis)
            o.optString("partial").ifBlank { o.optString("text") }
        } catch (_: Exception) {
            ""
        }
        if (text.isBlank()) return
        if (WakeMatcher.matches(text, assistantName())) onKeyword()
    }

    private fun onKeyword() {
        if (!wanted) return
        wanted = false
        main.post {
            stopRecognition()
            val engine = Engine.get(applicationContext)
            engine.onWake()
            // Si no empezó a escuchar (por ejemplo, falta la clave de Gemini), seguir esperando
            if (engine.ui.value.phase == Phase.IDLE) resume()
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "${Brand.NAME} escuchando", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, WakeWordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle(Brand.NAME)
            .setContentText("Escuchando. Di «${assistantName()}»")
            .setContentIntent(open)
            .addAction(0, "Detener", stop)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        phaseJob?.cancel()
        scope.cancel()
        wanted = false
        main.removeCallbacksAndMessages(null)
        stopRecognition()
        try { (model as? AutoCloseable)?.close() } catch (_: Throwable) { }
        model = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "jarvis_service"
        private const val NOTIF_ID = 77
        private const val ACTION_STOP = "com.jarvis.app.STOP_WAKE"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeWordService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, WakeWordService::class.java))
        }
    }
}
