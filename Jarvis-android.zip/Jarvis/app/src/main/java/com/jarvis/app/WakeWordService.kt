package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min

/** ¿Lo que se oyó contiene el nombre del asistente? Tolera pequeñas diferencias de pronunciación. */
object WakeMatcher {
    fun matches(heard: String, name: String): Boolean {
        val target = Norm.of(name).replace(" ", "")
        if (target.length < 3) return false
        val words = Norm.of(heard).split(" ").filter { it.isNotEmpty() }
        if (words.isEmpty()) return false
        // palabras sueltas y pares pegados ("cli tel" -> "clitel")
        val candidates = words + words.zipWithNext { a, b -> a + b }
        val maxDist = if (target.length <= 4) 1 else 2
        return candidates.any { c ->
            abs(c.length - target.length) <= maxDist && distance(c, target) <= maxDist
        }
    }

    private fun distance(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = min(min(dp[j] + 1, dp[j - 1] + 1), prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }
}

/**
 * Escucha el nombre del asistente con el reconocedor de voz de Android (gratis, sin claves).
 * Es experimental: gasta más batería y en algunos celulares puede sonar un pitido al reiniciar.
 */
class WakeWordService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var recognizer: SpeechRecognizer? = null
    private var wanted = false
    private var running = false
    private var phaseJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences("jarvis", Context.MODE_PRIVATE)

        if (intent?.action == ACTION_STOP) {
            prefs.edit().putBoolean("wake_enabled", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)

        // Solo escucha cuando Clithel está en espera, para no chocar con su propia voz
        phaseJob?.cancel()
        phaseJob = scope.launch {
            Engine.get(applicationContext).ui
                .map { it.phase }
                .distinctUntilChanged()
                .collect { phase -> if (phase == Phase.IDLE) resume() else pause() }
        }
        return START_STICKY
    }

    private fun assistantName(): String =
        getSharedPreferences("jarvis", Context.MODE_PRIVATE)
            .getString("assistant_name", "").orEmpty().ifBlank { Brand.NAME }

    private fun resume() {
        wanted = true
        begin()
    }

    private fun pause() {
        wanted = false
        main.removeCallbacksAndMessages(null)
        stopRecognizer()
    }

    private fun begin() {
        if (!wanted || running) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        running = true
        r.setRecognitionListener(object : RecognitionListener {
            override fun onPartialResults(partialResults: Bundle?) { heard(partialResults) }
            override fun onResults(results: Bundle?) {
                heard(results)
                restartSoon(400L)
            }
            override fun onError(error: Int) {
                when (error) {
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> stopSelf()
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> restartSoon(1500L)
                    else -> restartSoon(400L)
                }
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try {
            r.startListening(intent)
        } catch (_: Exception) {
            restartSoon(1500L)
        }
    }

    private fun restartSoon(delayMs: Long) {
        stopRecognizer()
        if (wanted) main.postDelayed({ begin() }, delayMs)
    }

    private fun stopRecognizer() {
        running = false
        val r = recognizer
        recognizer = null
        if (r != null) {
            try { r.cancel() } catch (_: Exception) { }
            try { r.destroy() } catch (_: Exception) { }
        }
    }

    private fun heard(b: Bundle?) {
        val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
        val name = assistantName()
        if (list.any { WakeMatcher.matches(it, name) }) onKeyword()
    }

    private fun onKeyword() {
        if (!wanted) return
        wanted = false
        main.post {
            stopRecognizer()
            val engine = Engine.get(applicationContext)
            engine.onWake()
            // Si no empezó a escuchar (por ejemplo, falta la clave de Gemini), seguir esperando
            if (engine.ui.value.phase == Phase.IDLE) resume()
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "${Brand.NAME} escuchando", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, WakeWordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle(Brand.NAME)
            .setContentText("Escuchando. Di «${assistantName()}»")
            .setContentIntent(open)
            .addAction(0, "Detener", stop)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        phaseJob?.cancel()
        scope.cancel()
        wanted = false
        main.removeCallbacksAndMessages(null)
        stopRecognizer()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "jarvis_service"
        private const val NOTIF_ID = 77
        private const val ACTION_STOP = "com.jarvis.app.STOP_WAKE"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeWordService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, WakeWordService::class.java))
        }
    }
}
