package com.jarvis.app

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/** Escucha la palabra «Jarvis» todo el tiempo (con una notificación fija). */
class WakeWordService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var porcupine: PorcupineManager? = null
    private var active = false
    private var phaseJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences("jarvis", Context.MODE_PRIVATE)

        if (intent?.action == ACTION_STOP) {
            prefs.edit().putBoolean("wake_enabled", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)

        val key = prefs.getString("porcupine_key", "").orEmpty()
        if (key.isBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (porcupine == null) {
            try {
                porcupine = PorcupineManager.Builder()
                    .setAccessKey(key)
                    .setKeywords(arrayOf(Porcupine.BuiltInKeyword.JARVIS))
                    .build(applicationContext, PorcupineManagerCallback { _ -> main.post { onKeyword() } })
            } catch (e: Exception) {
                Hud.notify(
                    this, 4000, "SYS // WAKE_WORD // ERROR",
                    "No pude activar «Jarvis»: revisa tu AccessKey de Picovoice.",
                )
                prefs.edit().putBoolean("wake_enabled", false).apply()
                stopSelf()
                return START_NOT_STICKY
            }
        }

        // Porcupine escucha salvo mientras Jarvis usa el micrófono para entenderte
        phaseJob?.cancel()
        phaseJob = scope.launch {
            Engine.get(applicationContext).ui
                .map { it.phase }
                .distinctUntilChanged()
                .collect { phase -> if (phase == Phase.LISTENING) pause() else resume() }
        }
        return START_STICKY
    }

    private fun onKeyword() {
        pause()
        val engine = Engine.get(applicationContext)
        engine.onWake()
        if (engine.ui.value.phase != Phase.LISTENING) resume()
    }

    private fun pause() {
        if (active) {
            try { porcupine?.stop() } catch (_: Exception) { }
            active = false
        }
    }

    private fun resume() {
        if (!active) {
            try {
                porcupine?.start()
                active = true
            } catch (_: Exception) {
            }
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "${Brand.NAME} escuchando", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, WakeWordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_jarvis)
            .setContentTitle(Brand.NAME)
            .setContentText("Escuchando. Di «Jarvis»")
            .setContentIntent(open)
            .addAction(0, "Detener", stop)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        phaseJob?.cancel()
        scope.cancel()
        try {
            porcupine?.stop()
            porcupine?.delete()
        } catch (_: Exception) {
        }
        porcupine = null
        active = false
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "jarvis_service"
        private const val NOTIF_ID = 77
        private const val ACTION_STOP = "com.jarvis.app.STOP_WAKE"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeWordService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, WakeWordService::class.java))
        }
    }
}
