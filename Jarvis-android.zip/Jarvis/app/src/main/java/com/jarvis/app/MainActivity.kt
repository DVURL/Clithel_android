package com.jarvis.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Si la escucha permanente estaba activada, volver a encenderla al abrir la app
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (prefs.getBoolean("wake_enabled", false) && micOk && VoskModel.isReady(this)) {
            try { WakeWordService.start(this) } catch (_: Exception) { }
        }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                JarvisScreen(viewModel<JarvisViewModel>())
            }
        }
        handleListen(intent)
        Engine.get(this).checkUpdates(false)
    }

    override fun onStart() {
        super.onStart()
        Engine.get(this).visible = true
    }

    override fun onStop() {
        super.onStop()
        Engine.get(this).visible = false
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleListen(intent)
    }

    /** Si venimos del widget, empezar a escuchar de inmediato. */
    private fun handleListen(source: Intent?) {
        val i = source ?: return
        if (!i.getBooleanExtra("listen", false)) return
        i.removeExtra("listen")
        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val engine = Engine.get(this)
        if (micOk && engine.hasKey() && engine.ui.value.phase == Phase.IDLE) engine.onOrbTap()
    }
}
