package com.jarvis.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

data class UpdateInfo(val tag: String, val code: Long, val apkUrl: String, val notes: String)

data class UpdateUi(
    val info: UpdateInfo? = null,
    val show: Boolean = false,
    val downloading: Boolean = false,
    val progress: Int = 0,
    val message: String = "",
)

/** Busca versiones nuevas en los Releases de GitHub, las descarga y abre el instalador. */
object Updater {
    private val http = OkHttpClient.Builder().callTimeout(180, TimeUnit.SECONDS).build()

    fun installedCode(ctx: Context): Long = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).longVersionCode
    } catch (_: Exception) {
        0L
    }

    suspend fun check(ctx: Context): UpdateInfo? = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("https://api.github.com/repos/${Brand.REPO}/releases/latest")
            .header("Accept", "application/vnd.github+json")
            .build()
        http.newCall(req).execute().use { res ->
            if (!res.isSuccessful) throw IOException("HTTP ${res.code}")
            val o = JSONObject(res.body?.string().orEmpty())
            val tag = o.optString("tag_name")
            val code = tag.filter { it.isDigit() }.toLongOrNull()
            val assets = o.optJSONArray("assets")
            var url: String? = null
            if (assets != null) {
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name").endsWith(".apk")) url = a.optString("browser_download_url")
                }
            }
            if (code != null && url != null && code > installedCode(ctx)) {
                UpdateInfo(tag, code, url, o.optString("body"))
            } else {
                null
            }
        }
    }

    suspend fun download(ctx: Context, info: UpdateInfo, onProgress: (Int) -> Unit): File =
        withContext(Dispatchers.IO) {
            val dir = File(ctx.cacheDir, "updates").apply { mkdirs() }
            val out = File(dir, "${Brand.NAME}.apk")
            http.newCall(Request.Builder().url(info.apkUrl).build()).execute().use { res ->
                if (!res.isSuccessful) throw IOException("HTTP ${res.code}")
                val body = res.body ?: throw IOException("Respuesta vacía")
                val total = body.contentLength()
                body.byteStream().use { input ->
                    out.outputStream().use { output ->
                        val buf = ByteArray(32 * 1024)
                        var done = 0L
                        var last = -1
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val p = (done * 100 / total).toInt()
                                if (p != last) {
                                    last = p
                                    onProgress(p)
                                }
                            }
                        }
                    }
                }
            }
            out
        }

    /** Abre el instalador. Devuelve un mensaje si falta el permiso de instalar apps. */
    fun install(ctx: Context, apk: File): String? {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "Permite instalar apps desde ${Brand.NAME} y vuelve a tocar Actualizar."
        }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", apk)
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return null
    }
}
