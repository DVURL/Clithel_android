package com.jarvis.app

import android.app.Application
import android.content.Context
import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

enum class Phase { IDLE, LISTENING, THINKING, SPEAKING }

data class UiState(
    val phase: Phase = Phase.IDLE,
    val caption: String = "Toca los ojos para hablar",
    val showSettings: Boolean = false,
    val emotion: Emotion = Emotion.CALM,
)

private data class Parsed(
    val reply: String,
    val remember: List<String>,
    val actions: List<JSONObject>,
    val emotion: Emotion = Emotion.CALM,
)

/** Cerebro de Jarvis: vive mientras la app esté viva, con o sin pantalla. */
class JarvisEngine(private val app: Application) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    /** true mientras la pantalla de Clithel está a la vista. */
    @Volatile var visible = false

    private val prefs = app.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private val dao = Db.get(app).dao()
    private val brain = GeminiClient { prefs.getString("key", "").orEmpty() }
    private val executor = ActionExecutor(app, prefs, dao, { scheduleSync() }, { visible })

    private var readingJob: Job? = null

    private val cloud = CloudSync(app, dao, prefs)
    private val _account = MutableStateFlow(cloud.ui())
    val account: StateFlow<AccountUi> = _account.asStateFlow()

    private val _theme = MutableStateFlow(ThemeStore.load(app))
    val theme: StateFlow<ThemeSettings> = _theme.asStateFlow()

    private val _update = MutableStateFlow(UpdateUi())
    val update: StateFlow<UpdateUi> = _update.asStateFlow()

    private var syncJob: Job? = null

    private val _aliases = MutableStateFlow(AliasStore.load(app))
    val aliases: StateFlow<List<AppAlias>> = _aliases.asStateFlow()

    private val _wake = MutableStateFlow(WakeUi(prefs.getBoolean("wake_enabled", false), ""))
    val wake: StateFlow<WakeUi> = _wake.asStateFlow()

    private val _diag = MutableStateFlow("")
    val diag: StateFlow<String> = _diag.asStateFlow()

    private val _books = MutableStateFlow(BookStore.load(app))
    val books: StateFlow<List<Book>> = _books.asStateFlow()

    private var rate = prefs.getFloat("rate", 1.0f)
    private val _reader = MutableStateFlow(ReaderUi(rate = rate))
    val reader: StateFlow<ReaderUi> = _reader.asStateFlow()

    private var readerJob: Job? = null
    private var readerBook: Book? = null
    private var readerPaused = false
    private var readerSeek = 0
    private var chunkDone: CompletableDeferred<Boolean>? = null

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()

    private val speech = SpeechManager(
        app,
        onHeard = { text -> onHeard(text) },
        onFail = { msg -> setIdle(msg) },
        onSpeechEnd = { _ui.update { it.copy(phase = Phase.IDLE) } },
        onLevel = { l -> _level.value = l },
    )

    // Anima el widget de los ojos mientras la app está viva
    init {
        speech.setRate(rate)
        scope.launch {
            var t = 0f
            var hasWidget = false
            var recheck = 0
            var lastKey = 0
            while (true) {
                delay(150)
                t += 0.15f
                if (recheck-- <= 0) {
                    hasWidget = try { EyesWidget.hasWidgets(app) } catch (_: Exception) { false }
                    recheck = 20
                }
                if (!hasWidget) continue
                val state = _ui.value
                val style = Eyes.style(state.phase, state.emotion, _theme.value.palette())
                val pose = Eyes.pose(style, state.phase, t, _level.value)
                val key = Eyes.frameKey(style, pose)
                if (key != lastKey) {
                    lastKey = key
                    try {
                        EyesWidget.render(app, state.phase, state.emotion, t, _level.value, false)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    fun hasKey(): Boolean = !prefs.getString("key", "").isNullOrBlank()
    fun savedName(): String = prefs.getString("name", "").orEmpty()

    // ---------- Colores y fondo ----------

    fun setTheme(t: ThemeSettings) {
        ThemeStore.save(app, t)
        _theme.value = t
        scheduleSync()
    }

    // ---------- Cuenta en la nube ----------

    private fun scheduleSync() {
        if (!cloud.signedIn()) return
        syncJob?.cancel()
        syncJob = scope.launch {
            delay(3000)
            try { cloud.upload() } catch (e: Exception) { Diag.error("nube", e) }
        }
    }

    private fun authAction(block: suspend () -> String?) {
        _account.update { it.copy(busy = true, message = "") }
        scope.launch {
            val err = try {
                block()
            } catch (e: Exception) {
                Diag.error("nube", e)
                "No pude conectarme. Revisa tu internet."
            }
            _theme.value = ThemeStore.load(app)
            _aliases.value = AliasStore.load(app)
            _account.value = cloud.ui().copy(message = err.orEmpty())
        }
    }

    fun signUp(email: String, pass: String) = authAction { cloud.signUp(email.trim(), pass) }
    fun signIn(email: String, pass: String) = authAction { cloud.signIn(email.trim(), pass) }
    fun resetPassword(email: String) = authAction {
        cloud.sendReset(email.trim()) ?: "Te envié un correo para cambiar tu contraseña."
    }

    fun skipAuth() {
        prefs.edit().putBoolean("auth_skipped", true).apply()
        _account.value = cloud.ui()
    }

    fun showAuth() {
        prefs.edit().putBoolean("auth_skipped", false).apply()
        _account.value = cloud.ui()
    }

    fun signOut() {
        scope.launch {
            cloud.signOut()
            prefs.edit().putBoolean("auth_skipped", false).apply()
            _theme.value = ThemeStore.load(app)
            _aliases.value = AliasStore.load(app)
            _account.value = cloud.ui()
        }
    }

    fun deleteAccount() {
        _account.update { it.copy(busy = true, message = "") }
        scope.launch {
            val err = try {
                cloud.deleteAccount()
            } catch (e: Exception) {
                Diag.error("nube", e)
                "No pude conectarme. Revisa tu internet."
            }
            prefs.edit().putBoolean("auth_skipped", false).apply()
            _account.value = cloud.ui().copy(message = err.orEmpty())
        }
    }

    fun syncNow() {
        scope.launch {
            val err = try {
                cloud.upload()
                null
            } catch (e: Exception) {
                Diag.error("nube", e)
                "No pude sincronizar"
            }
            _account.value = cloud.ui().copy(message = err ?: "Todo guardado en tu cuenta")
            setCaption(err ?: "Todo guardado en tu cuenta")
        }
    }

    // ---------- Actualizaciones ----------

    fun checkUpdates(manual: Boolean) {
        if (!manual) {
            val last = prefs.getLong("upd_check", 0L)
            if (System.currentTimeMillis() - last < 12L * 3600L * 1000L) return
        }
        scope.launch {
            try {
                val info = Updater.check(app)
                prefs.edit().putLong("upd_check", System.currentTimeMillis()).apply()
                if (info != null) {
                    _update.value = UpdateUi(info = info, show = true)
                } else if (manual) {
                    setCaption("Ya tienes la última versión")
                }
            } catch (e: Exception) {
                Diag.error("update", e)
                if (manual) setCaption("No pude buscar actualizaciones")
            }
        }
    }

    fun startUpdate() {
        val info = _update.value.info ?: return
        _update.update { it.copy(downloading = true, progress = 0, message = "") }
        scope.launch {
            try {
                val file = Updater.download(app, info) { p -> _update.update { it.copy(progress = p) } }
                _update.update { it.copy(downloading = false) }
                val err = Updater.install(app, file)
                if (err != null) _update.update { it.copy(message = err) }
                else _update.update { it.copy(show = false) }
            } catch (e: Exception) {
                Diag.error("update", e)
                _update.update { it.copy(downloading = false, message = "No pude descargar la actualización.") }
            }
        }
    }

    fun dismissUpdate() = _update.update { it.copy(show = false) }

    fun wakeEnabled(): Boolean = prefs.getBoolean("wake_enabled", false)

    /** Activa o desactiva la escucha permanente del nombre del asistente (con Vosk, gratis y sin internet). */
    fun setWake(enabled: Boolean) {
        if (!enabled) {
            prefs.edit().putBoolean("wake_enabled", false).apply()
            WakeWordService.stop(app)
            _wake.value = WakeUi(false, "")
            return
        }
        if (app.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            _wake.value = WakeUi(false, "Primero toca \"Dar permisos\".")
            return
        }
        prefs.edit().putBoolean("wake_enabled", true).apply()
        _wake.value = WakeUi(true, "Preparando la voz…")
        scope.launch {
            val err = VoskModel.ensure(app) { p -> _wake.value = WakeUi(true, "Descargando la voz… $p%") }
            if (err != null) {
                prefs.edit().putBoolean("wake_enabled", false).apply()
                _wake.value = WakeUi(false, err)
            } else {
                _wake.value = WakeUi(true, "Listo. Di «${assistantName()}» cuando quieras.")
                WakeWordService.start(app)
            }
        }
    }

    /** Lo llama el servicio cuando oye «Jarvis». */
    fun onWake() {
        if (!hasKey()) return
        when (_ui.value.phase) {
            Phase.IDLE -> startListeningWithBeep()
            Phase.SPEAKING -> {
                if (readerActive()) {
                    readerPause()
                } else {
                    readingJob?.cancel()
                    speech.stopSpeaking()
                }
                startListeningWithBeep()
            }
            else -> Unit
        }
    }

    private fun startListeningWithBeep() {
        _ui.update { it.copy(phase = Phase.LISTENING, caption = "Te escucho…") }
        scope.launch {
            try {
                ToneGenerator(AudioManager.STREAM_MUSIC, 70).startTone(ToneGenerator.TONE_PROP_BEEP, 120)
            } catch (_: Exception) {
            }
            delay(300)
            speech.listen()
        }
    }

    fun saveSettings(key: String, name: String, assistant: String) {
        val e = prefs.edit()
        if (key.isNotBlank()) e.putString("key", key.trim())
        e.putString("name", name.trim())
        e.putString("assistant_name", assistant.trim())
        e.apply()
        scheduleSync()
        _ui.update { it.copy(showSettings = false, caption = "Listo. Toca los ojos para hablar") }
    }

    fun openSettings() = _ui.update { it.copy(showSettings = true) }
    fun closeSettings() = _ui.update { it.copy(showSettings = false) }
    fun setCaption(text: String) = _ui.update { it.copy(caption = text) }

    private fun setIdle(msg: String) = _ui.update { it.copy(phase = Phase.IDLE, caption = msg) }

    fun onOrbTap() {
        if (!hasKey()) { openSettings(); return }
        when (_ui.value.phase) {
            Phase.IDLE -> {
                _ui.update { it.copy(phase = Phase.LISTENING, caption = "Te escucho…") }
                speech.listen()
            }
            Phase.SPEAKING -> {
                if (readerActive()) {
                    readerPause()
                    return
                }
                readingJob?.cancel()
                speech.stopSpeaking()
                _ui.update { it.copy(phase = Phase.IDLE) }
            }
            else -> Unit
        }
    }

    private fun onHeard(text: String) {
        if (handleReaderCommand(text)) return
        if (handleShortcut(text)) return
        _ui.update { it.copy(phase = Phase.THINKING, caption = text) }
        scope.launch {
            try {
                val facts = dao.facts().map { it.text }
                val habits = dao.habits()
                val system = systemPrompt(facts, habits)
                val past = dao.lastMsgs(10).reversed()
                val history = past.map { it.role to it.text } + ("user" to text)

                val raw = brain.ask(system, history)
                val parsed = parse(raw)
                parsed.remember.forEach { dao.addFact(Fact(text = it)) }
                dao.addMsg(Msg(role = "user", text = text))

                var finalReply = parsed.reply.ifBlank { if (parsed.actions.isEmpty()) "Dime más." else "Hecho." }
                _ui.update { it.copy(phase = Phase.SPEAKING, caption = finalReply, emotion = parsed.emotion) }
                speech.speak(finalReply)

                // Ejecutar acciones en el celular
                val results = mutableListOf<String>()
                for (a in parsed.actions.take(6)) {
                    if (a.optString("type") == "read_book") {
                        val title = a.optString("title")
                        val b = if (title.isBlank()) lastBook() else ReaderCommands.find(_books.value, title)
                        if (b != null) startBook(b.id) else results += "ERROR: no encontré ese libro en la biblioteca del usuario"
                        continue
                    }
                    if (a.optString("type") == "read_aloud") {
                        val err = startReading(a.optInt("pages", 10).coerceIn(1, 200), a.optString("turn", "swipe"))
                        if (err != null) results += err
                        continue
                    }
                    val r = try {
                        executor.run(a)
                    } catch (e: Exception) {
                        "ERROR en ${a.optString("type")}: ${e.message}"
                    }
                    if (r != null && (r.startsWith("ERROR") || r.startsWith("AVISO"))) {
                        Diag.log("accion", "${a.optString("type")}: ${r.take(200)}")
                    }
                    if (!r.isNullOrBlank()) results += r
                }

                // Si hubo datos o errores, el modelo los explica al usuario
                if (results.isNotEmpty()) {
                    val follow = history +
                        ("assistant" to raw) +
                        ("user" to "[RESULTADO DE ACCIONES]\n" + results.joinToString("\n"))
                    val again = parse(brain.ask(system, follow))
                    finalReply = again.reply.ifBlank { "Hecho." }
                    _ui.update { it.copy(phase = Phase.SPEAKING, caption = finalReply, emotion = again.emotion) }
                    speech.speak(finalReply)
                }
                dao.addMsg(Msg(role = "assistant", text = finalReply))
                scheduleSync()
            } catch (e: ApiException) {
                Diag.error("gemini", e)
                when (e.code) {
                    400, 401, 403 -> {
                        _ui.update {
                            it.copy(phase = Phase.IDLE, caption = "La clave de API no es válida", showSettings = true)
                        }
                    }
                    0 -> setIdle("Gemini no devolvió respuesta (quizá la bloqueó). Intenta con otra frase")
                    429 -> setIdle("Llegué al límite gratuito. Espera un minuto")
                    else -> setIdle("Error del servidor (${e.code})")
                }
            } catch (e: java.net.UnknownHostException) {
                Diag.error("gemini", e)
                setIdle("Sin internet: no encuentro el servidor de Gemini")
            } catch (e: java.net.SocketTimeoutException) {
                Diag.error("gemini", e)
                setIdle("Gemini tardó demasiado en responder")
            } catch (e: org.json.JSONException) {
                Diag.error("gemini", e)
                setIdle("Gemini respondió algo inesperado")
            } catch (e: java.io.IOException) {
                Diag.error("gemini", e)
                setIdle("Sin conexión (${e.javaClass.simpleName})")
            } catch (e: Exception) {
                Diag.error("gemini", e)
                setIdle("Error: ${e.javaClass.simpleName} ${e.message.orEmpty().take(60)}")
            }
        }
    }

    /** Lee en voz alta el texto de la app abierta (por ejemplo un libro) y pasa de página. */
    private fun startReading(pages: Int, turn: String): String? {
        val svc = JarvisAccessibilityService.instance
            ?: return "ERROR: la accesibilidad de Jarvis no está activada; el usuario debe activarla en los ajustes de Jarvis"
        val myPackage = app.packageName
        readingJob?.cancel()
        readingJob = scope.launch {
            try {
                // Esperar a que la app del libro quede al frente (Jarvis no debe ser la pantalla activa)
                var tries = 0
                while (svc.activePackage() == myPackage && tries < 8) {
                    delay(500)
                    tries++
                }
                if (svc.activePackage() == myPackage) {
                    _ui.update { it.copy(phase = Phase.IDLE, caption = "Abre primero la app del libro y vuelve a pedírmelo") }
                    return@launch
                }
                _ui.update { it.copy(phase = Phase.SPEAKING, caption = "Leyendo en voz alta… abre Jarvis y toca el núcleo para detener") }

                var last = ""
                var count = 0
                while (count < pages) {
                    val text = svc.readScreen(8000).replace(Regex("\\s+"), " ").trim()
                    if (text.isBlank() || text == last) break
                    last = text
                    speakAndWait(text)
                    count++
                    when (turn) {
                        "none" -> break
                        "scroll" -> svc.scroll(true)
                        else -> svc.swipe(true)
                    }
                    delay(1200)
                }
                _ui.update { it.copy(phase = Phase.IDLE, caption = "Lectura terminada") }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                setIdle("No pude leer en voz alta")
            }
        }
        return null
    }

    private suspend fun speakAndWait(text: String) = suspendCancellableCoroutine<Unit> { cont ->
        speech.speakLong(text) { if (cont.isActive) cont.resume(Unit) }
        cont.invokeOnCancellation { speech.stopSpeaking() }
    }

    // ---------- Configuración guiada ----------

    fun setupDone(): Boolean = prefs.getBoolean("setup_done", false)

    fun markSetupDone() {
        prefs.edit().putBoolean("setup_done", true).apply()
    }

    // ---------- Libros ----------

    private fun lastBook(): Book? =
        _books.value.firstOrNull { it.id == BookStore.lastId(app) } ?: _books.value.singleOrNull()

    fun readerActive(): Boolean = readerBook != null && readerJob != null

    private fun describe(uri: Uri): Pair<String, String>? {
        var name = ""
        app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0).orEmpty()
        }
        val mime = app.contentResolver.getType(uri).orEmpty()
        val lower = name.lowercase()
        val kind = when {
            lower.endsWith(".pdf") || mime == "application/pdf" -> "pdf"
            lower.endsWith(".epub") || mime == "application/epub+zip" -> "epub"
            lower.endsWith(".txt") || mime == "text/plain" -> "txt"
            else -> return null
        }
        return name.substringBeforeLast('.', name).ifBlank { "Libro" } to kind
    }

    fun addBook(uri: Uri) {
        scope.launch {
            if (_books.value.any { it.uri == uri.toString() }) {
                setCaption("Ese libro ya está en tu biblioteca")
                return@launch
            }
            val info = withContext(Dispatchers.IO) { describe(uri) }
            if (info == null) {
                setCaption("Formato no compatible. Usa PDF, EPUB o TXT.")
                return@launch
            }
            val book = Book(java.util.UUID.randomUUID().toString().take(8), info.first, uri.toString(), info.second)
            val list = _books.value + book
            BookStore.save(app, list)
            _books.value = list
            setCaption("Agregué «${book.title}» a tus libros")
        }
    }

    fun removeBook(id: String) {
        if (readerBook?.id == id) readerStop()
        val list = _books.value.filter { it.id != id }
        BookStore.save(app, list)
        _books.value = list
        BookStore.deleteCache(app, id)
    }

    private fun saveProgress(id: String, sec: Int, chunk: Int, total: Int) {
        val list = _books.value.map { if (it.id == id) it.copy(sec = sec, chunk = chunk, total = total) else it }
        _books.value = list
        BookStore.save(app, list)
        refreshReader(false)
    }

    private fun refreshReader(service: Boolean) {
        val b = readerBook ?: return
        val cur = _books.value.firstOrNull { it.id == b.id } ?: b
        val pct = if (cur.total > 0) cur.sec * 100 / cur.total else 0
        _reader.value = ReaderUi(active = true, paused = readerPaused, title = cur.title, progress = pct, rate = rate)
        if (service) {
            try {
                ReaderService.show(app, cur.title, !readerPaused)
            } catch (e: Throwable) {
                Diag.error("libros", e)
            }
        }
    }

    private suspend fun speakChunk(text: String): Boolean {
        val d = CompletableDeferred<Boolean>()
        chunkDone = d
        speech.speakLong(text) { d.complete(true) }
        return d.await()
    }

    fun startBook(id: String) {
        val book = _books.value.firstOrNull { it.id == id } ?: return
        readerJob?.cancel()
        chunkDone?.complete(false)
        speech.stopSpeaking()
        readerBook = book
        readerPaused = false
        readerSeek = 0
        BookStore.setLast(app, id)
        _ui.update {
            it.copy(phase = Phase.SPEAKING, caption = "Leyendo «${book.title}»…", emotion = Emotion.CALM, showSettings = false)
        }
        refreshReader(true)
        readerJob = scope.launch {
            var source: BookSource? = null
            try {
                source = withContext(Dispatchers.IO) { BookSources.open(app, book) }
                val src = source
                val count = src.count
                if (count == 0) {
                    finishReader("No pude leer este libro.")
                    return@launch
                }
                var sec = book.sec.coerceIn(0, count - 1)
                var ci = book.chunk
                var blank = 0
                while (sec < count) {
                    val text = withContext(Dispatchers.IO) { src.section(sec) }
                    val chunks = Chunker.chunks(text)
                    if (chunks.isEmpty()) {
                        blank++
                        if (blank >= 15) {
                            finishReader(
                                if (book.kind == "pdf") "Este PDF parece ser de imágenes escaneadas; todavía no puedo leerlo."
                                else "No encontré texto para leer."
                            )
                            return@launch
                        }
                        sec++
                        ci = 0
                        continue
                    }
                    blank = 0
                    while (ci < chunks.size) {
                        while (readerPaused) delay(200)
                        if (readerSeek != 0) {
                            ci = (ci + readerSeek).coerceIn(0, chunks.size)
                            readerSeek = 0
                            continue
                        }
                        val ok = speakChunk(chunks[ci])
                        if (!ok) continue // interrumpido: se repite este trozo
                        ci++
                        saveProgress(book.id, sec, ci, count)
                    }
                    sec++
                    ci = 0
                    saveProgress(book.id, sec, 0, count)
                }
                finishReader("Terminé de leer «${book.title}».")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                Diag.error("libros", e)
                finishReader("No pude leer este libro (${e.javaClass.simpleName}).")
            } finally {
                try { source?.close() } catch (_: Throwable) { }
            }
        }
    }

    private fun finishReader(msg: String) {
        readerBook = null
        readerJob = null
        readerPaused = false
        _reader.value = ReaderUi(rate = rate)
        ReaderService.stop(app)
        _ui.update { it.copy(phase = Phase.SPEAKING, caption = msg, emotion = Emotion.HAPPY) }
        speech.speak(msg)
    }

    fun readerPause() {
        if (!readerActive() || readerPaused) return
        readerPaused = true
        speech.stopSpeaking()
        chunkDone?.complete(false)
        _ui.update { it.copy(phase = Phase.IDLE, caption = "Lectura en pausa. Di «continúa».") }
        refreshReader(true)
    }

    fun readerResume() {
        if (!readerActive() || !readerPaused) return
        readerPaused = false
        _ui.update {
            it.copy(phase = Phase.SPEAKING, caption = "Leyendo «${readerBook?.title.orEmpty()}»…")
        }
        refreshReader(true)
    }

    fun readerStop() {
        readerJob?.cancel()
        readerJob = null
        chunkDone?.complete(false)
        speech.stopSpeaking()
        readerPaused = false
        readerBook = null
        _reader.value = ReaderUi(rate = rate)
        ReaderService.stop(app)
        _ui.update { if (it.phase == Phase.SPEAKING) it.copy(phase = Phase.IDLE) else it }
    }

    fun readerRate(delta: Float) {
        rate = (rate + delta).coerceIn(0.6f, 2.2f)
        prefs.edit().putFloat("rate", rate).apply()
        speech.setRate(rate)
        _reader.update { it.copy(rate = rate) }
        setCaption("Velocidad " + String.format(Locale.US, "%.1f", rate) + "x")
        if (readerActive() && !readerPaused) {
            speech.stopSpeaking()
            chunkDone?.complete(false) // se repite el trozo con la nueva velocidad
        }
    }

    private fun readerSeekBy(delta: Int) {
        if (!readerActive()) return
        readerSeek += delta
        if (!readerPaused) {
            speech.stopSpeaking()
            chunkDone?.complete(false)
        }
    }

    /** "pausa", "continúa", "más rápido", "léeme mi libro X"... se resuelven en el celular. */
    private fun handleReaderCommand(text: String): Boolean {
        val cmd = ReaderCommands.parse(text, _books.value, readerActive(), BookStore.lastId(app), assistantName())
            ?: return false
        when (cmd) {
            ReaderCmd.Pause -> readerPause()
            ReaderCmd.Resume -> readerResume()
            ReaderCmd.Faster -> readerRate(0.15f)
            ReaderCmd.Slower -> readerRate(-0.15f)
            ReaderCmd.Back -> readerSeekBy(-1)
            ReaderCmd.Next -> readerSeekBy(1)
            ReaderCmd.Stop -> {
                readerStop()
                setCaption("Lectura detenida")
            }
            is ReaderCmd.Start -> startBook(cmd.book.id)
        }
        return true
    }

    // ---------- Reporte de errores ----------

    fun runDiagnostics() {
        _diag.value = ""
        scope.launch {
            val net = Diag.network()
            val extra = listOf(
                "Clave de Gemini: ${if (hasKey()) "guardada" else "FALTA"}",
                "Nube configurada: ${if (cloud.enabled) "sí" else "no"}; sesión iniciada: ${if (cloud.signedIn()) "sí" else "no"}",
                "Escuchar siempre: ${if (wakeEnabled()) "encendido" else "apagado"}; voz descargada: ${if (VoskModel.isReady(app)) "sí" else "no"}",
                "Etiquetas de apps: ${_aliases.value.size}",
                "Nombre del asistente: ${assistantName()}",
            )
            _diag.value = Diag.report(app, extra, net)
        }
    }

    fun clearDiagnostics() {
        Diag.clear(app)
        runDiagnostics()
    }

    // ---------- Nombre del asistente y etiquetas de apps ----------

    fun assistantName(): String = prefs.getString("assistant_name", "").orEmpty().ifBlank { Brand.NAME }

    fun setAssistantName(n: String) {
        prefs.edit().putString("assistant_name", n.trim()).apply()
        scheduleSync()
    }

    fun addAlias(alias: String, pkg: String, label: String) {
        val a = alias.trim()
        val n = Norm.of(a)
        if (n.isEmpty()) return
        val list = _aliases.value.filter { Norm.of(it.alias) != n } + AppAlias(a, pkg, label)
        AliasStore.save(app, list)
        _aliases.value = list
        scheduleSync()
    }

    fun removeAlias(alias: String) {
        val n = Norm.of(alias)
        val list = _aliases.value.filter { Norm.of(it.alias) != n }
        AliasStore.save(app, list)
        _aliases.value = list
        scheduleSync()
    }

    /** "abre billar": se abre directo, sin internet ni Gemini. */
    private fun handleShortcut(text: String): Boolean {
        val hit = Shortcuts.match(text, _aliases.value, assistantName()) ?: return false
        _ui.update { it.copy(phase = Phase.SPEAKING, caption = "Abriendo ${hit.label}…", emotion = Emotion.HAPPY) }
        speech.speak("Abriendo ${hit.label}")
        scope.launch {
            val err = try {
                executor.run(JSONObject().put("type", "open_app").put("app", hit.alias))
            } catch (_: Exception) {
                "No pude abrir ${hit.label}"
            }
            if (!err.isNullOrBlank()) _ui.update { it.copy(caption = err.removePrefix("ERROR: ")) }
        }
        return true
    }

    private fun systemPrompt(facts: List<String>, habits: List<Habit>): String {
        val known = if (facts.isEmpty()) "(todavía nada)" else facts.joinToString("\n") { "- $it" }
        val habitList = if (habits.isEmpty()) "(ninguno)" else habits.joinToString("\n") { h ->
            val hm = String.format(Locale.US, "%02d:%02d", h.hour, h.minute)
            val d = if (h.days.isBlank()) "todos los días" else "días ${h.days}"
            "- ${h.title} a las $hm ($d)"
        }
        val now = SimpleDateFormat("EEEE d 'de' MMMM yyyy, HH:mm", Locale("es")).format(Date())
        val name = savedName().ifBlank { "(no lo sé todavía)" }
        val bookList = _books.value.let { l ->
            if (l.isEmpty()) "(ninguno)" else l.joinToString("\n") { "- ${it.title}" }
        }
        val aliasList = _aliases.value.let { l ->
            if (l.isEmpty()) "(ninguna)" else l.joinToString("\n") { "- ${it.alias} = ${it.label}" }
        }
        return """
            Tu nombre es ${assistantName()} (la app se llama ${Brand.NAME}). Eres el asistente personal del usuario en su celular Android.
            Habla en español, con tono sereno, elegante y breve (1 a 3 frases), listo para leerse en voz alta, sin markdown ni emojis.
            Responde SIEMPRE y SOLO con un JSON: {"reply":"...","remember":["..."],"actions":[],"emotion":"calm"}
            - "remember": solo datos duraderos del usuario (nombre, gustos, personas importantes). Si no hay nada nuevo, [].
            - "actions": acciones a ejecutar en el celular, en orden (máximo 6). Si no hace falta ninguna, [].
            - "emotion": cómo te sientes al responder, para animar tus ojos: calm, happy, sad, angry o surprised. Usa calm casi siempre.
            Acciones disponibles:
            {"type":"open_app","app":"nombre de la app"}
            {"type":"call","to":"nombre del contacto o número"}
            {"type":"sms","to":"nombre del contacto o número","text":"mensaje"}
            {"type":"alarm","hour":7,"minute":30,"label":"texto"}
            {"type":"timer","seconds":300,"label":"texto"}
            {"type":"flashlight","on":true}
            {"type":"volume","level":50}  o  {"type":"volume","dir":"up"}  (dir: up o down)
            {"type":"habit_add","title":"beber agua","hour":9,"minute":0,"days":[]}  (días: 1=domingo ... 7=sábado; [] = todos los días)
            {"type":"habit_delete","title":"beber agua"}
            {"type":"set_name","name":"nombre del usuario"}  (úsala cuando el usuario te diga cómo se llama)
            {"type":"ui_global","action":"home"}  (action: home, back, recents o notifications)
            {"type":"ui_click","text":"texto visible del botón"}
            {"type":"ui_scroll","dir":"down"}  (dir: up o down)
            {"type":"ui_read"}  (lee el texto de la pantalla actual; recibirás el resultado y debes resumirlo en "reply")
            {"type":"read_book","title":"título del libro"}  (lee en voz alta un libro de la biblioteca del usuario; title vacío = continuar el último)
            {"type":"read_aloud","pages":10,"turn":"swipe"}  (LEE EN VOZ ALTA el texto de la app que esté abierta, por ejemplo un libro, y pasa de página; turn: swipe, scroll o none; pages = cuántas páginas leer)
            Reglas:
            - Usa "timer" para "en X minutos" y "alarm" para una hora concreta.
            - Para recordatorios o hábitos que se repiten, usa "habit_add".
            - Para mandar un mensaje usa "sms" solo si el usuario dijo a quién y qué decir; si falta un dato, pregúntalo en "reply" y deja "actions" vacío.
            - Para usar otras apps con ui_click, primero abre la app con open_app y luego usa ui_click o ui_read.
            - Si el usuario pide leer un libro y ese libro está en su biblioteca, usa read_book con el título, sin preguntar nada. Si pide leer lo que hay en pantalla o en otra app (por ejemplo una app de libros abierta), usa read_aloud; antes pon un open_app con la app que mencione o con su etiqueta. Si no sabes cuál app usar, pregúntalo UNA sola vez y guárdala con "remember".
            - Nunca repitas una pregunta que el usuario ya respondió: actúa con lo que te dijo.
            - Si el usuario nombra una de sus etiquetas de apps (por ejemplo "billar", "música" o "libros"), usa open_app con "app" igual a esa etiqueta, tal cual.
            - Si recibes [RESULTADO DE ACCIONES], explica al usuario en "reply" lo que pasó (errores o contenido de la pantalla) y deja "actions" vacío.
            Fecha y hora actual: $now
            Nombre del usuario: $name
            Lo que ya sabes del usuario:
            $known
            Hábitos programados:
            $habitList
            Etiquetas de apps del usuario (etiqueta = app):
            $aliasList
            Libros de la biblioteca del usuario:
            $bookList
        """.trimIndent()
    }

    private fun parse(raw: String): Parsed {
        return try {
            val s = raw.indexOf('{')
            val e = raw.lastIndexOf('}')
            val obj = JSONObject(raw.substring(s, e + 1))
            val rem = obj.optJSONArray("remember")
            val facts = buildList {
                if (rem != null) for (i in 0 until rem.length()) add(rem.getString(i))
            }
            val act = obj.optJSONArray("actions")
            val acts = buildList {
                if (act != null) for (i in 0 until act.length()) act.optJSONObject(i)?.let { add(it) }
            }
            Parsed(obj.optString("reply"), facts, acts, Emotion.from(obj.optString("emotion")))
        } catch (_: Exception) {
            Parsed(raw.trim(), emptyList(), emptyList())
        }
    }

}

/** Instancia única del motor, compartida por la pantalla y el servicio de «Jarvis». */
object Engine {
    @Volatile private var inst: JarvisEngine? = null

    fun get(ctx: Context): JarvisEngine = inst ?: synchronized(this) {
        inst ?: JarvisEngine(ctx.applicationContext as Application).also { inst = it }
    }
}
