package com.jarvis.app

import android.app.Application
import android.content.Context
import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

enum class Phase { IDLE, LISTENING, THINKING, SPEAKING }

data class UiState(
    val phase: Phase = Phase.IDLE,
    val caption: String = "Toca el núcleo para hablar",
    val showSettings: Boolean = false,
    val emotion: Emotion = Emotion.CALM,
)

private data class Parsed(
    val reply: String,
    val remember: List<String>,
    val actions: List<JSONObject>,
    val emotion: Emotion = Emotion.CALM,
)

/** Cerebro de Jarvis: vive mientras la app esté viva, con o sin pantalla. */
class JarvisEngine(private val app: Application) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val prefs = app.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private val dao = Db.get(app).dao()
    private val brain = GeminiClient { prefs.getString("key", "").orEmpty() }
    private val executor = ActionExecutor(app, prefs, dao)

    private var readingJob: Job? = null

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()

    private val speech = SpeechManager(
        app,
        onHeard = { text -> onHeard(text) },
        onFail = { msg -> setIdle(msg) },
        onSpeechEnd = { _ui.update { it.copy(phase = Phase.IDLE) } },
        onLevel = { l -> _level.value = l },
    )

    // Anima el widget de los ojos mientras la app está viva
    init {
        scope.launch {
            var t = 0f
            var hasWidget = false
            var recheck = 0
            var lastKey = 0
            while (true) {
                delay(150)
                t += 0.15f
                if (recheck-- <= 0) {
                    hasWidget = try { EyesWidget.hasWidgets(app) } catch (_: Exception) { false }
                    recheck = 20
                }
                if (!hasWidget) continue
                val state = _ui.value
                val style = Eyes.style(state.phase, state.emotion)
                val pose = Eyes.pose(style, state.phase, t, _level.value)
                val key = Eyes.frameKey(style, pose)
                if (key != lastKey) {
                    lastKey = key
                    try {
                        EyesWidget.render(app, state.phase, state.emotion, t, _level.value, false)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    fun hasKey(): Boolean = !prefs.getString("key", "").isNullOrBlank()
    fun savedName(): String = prefs.getString("name", "").orEmpty()

    fun hasWakeKey(): Boolean = !prefs.getString("porcupine_key", "").isNullOrBlank()
    fun wakeEnabled(): Boolean = prefs.getBoolean("wake_enabled", false)

    /** Activa o desactiva la escucha permanente de «Jarvis». Devuelve si quedó activada. */
    fun setWake(enabled: Boolean, wakeKey: String): Boolean {
        if (wakeKey.isNotBlank()) prefs.edit().putString("porcupine_key", wakeKey.trim()).apply()
        if (!enabled) {
            prefs.edit().putBoolean("wake_enabled", false).apply()
            WakeWordService.stop(app)
            return false
        }
        if (!hasWakeKey()) {
            setCaption("Pega primero tu AccessKey de Picovoice")
            return false
        }
        if (app.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            setCaption("Primero toca \"Dar permisos\"")
            return false
        }
        prefs.edit().putBoolean("wake_enabled", true).apply()
        WakeWordService.start(app)
        setCaption("Listo. Di «Jarvis» cuando quieras")
        return true
    }

    /** Lo llama el servicio cuando oye «Jarvis». */
    fun onWake() {
        if (!hasKey()) return
        when (_ui.value.phase) {
            Phase.IDLE -> startListeningWithBeep()
            Phase.SPEAKING -> {
                readingJob?.cancel()
                speech.stopSpeaking()
                startListeningWithBeep()
            }
            else -> Unit
        }
    }

    private fun startListeningWithBeep() {
        _ui.update { it.copy(phase = Phase.LISTENING, caption = "Te escucho…") }
        scope.launch {
            try {
                ToneGenerator(AudioManager.STREAM_MUSIC, 70).startTone(ToneGenerator.TONE_PROP_BEEP, 120)
            } catch (_: Exception) {
            }
            delay(300)
            speech.listen()
        }
    }

    fun saveSettings(key: String, name: String, wakeKey: String) {
        val e = prefs.edit()
        if (key.isNotBlank()) e.putString("key", key.trim())
        if (wakeKey.isNotBlank()) e.putString("porcupine_key", wakeKey.trim())
        e.putString("name", name.trim())
        e.apply()
        _ui.update { it.copy(showSettings = false, caption = "Listo. Toca el núcleo para hablar") }
    }

    fun openSettings() = _ui.update { it.copy(showSettings = true) }
    fun closeSettings() = _ui.update { it.copy(showSettings = false) }
    fun setCaption(text: String) = _ui.update { it.copy(caption = text) }

    private fun setIdle(msg: String) = _ui.update { it.copy(phase = Phase.IDLE, caption = msg) }

    fun onOrbTap() {
        if (!hasKey()) { openSettings(); return }
        when (_ui.value.phase) {
            Phase.IDLE -> {
                _ui.update { it.copy(phase = Phase.LISTENING, caption = "Te escucho…") }
                speech.listen()
            }
            Phase.SPEAKING -> {
                readingJob?.cancel()
                speech.stopSpeaking()
                _ui.update { it.copy(phase = Phase.IDLE) }
            }
            else -> Unit
        }
    }

    private fun onHeard(text: String) {
        _ui.update { it.copy(phase = Phase.THINKING, caption = text) }
        scope.launch {
            try {
                val facts = dao.facts().map { it.text }
                val habits = dao.habits()
                val system = systemPrompt(facts, habits)
                val past = dao.lastMsgs(10).reversed()
                val history = past.map { it.role to it.text } + ("user" to text)

                val raw = brain.ask(system, history)
                val parsed = parse(raw)
                parsed.remember.forEach { dao.addFact(Fact(text = it)) }
                dao.addMsg(Msg(role = "user", text = text))

                var finalReply = parsed.reply.ifBlank { if (parsed.actions.isEmpty()) "Dime más." else "Hecho." }
                _ui.update { it.copy(phase = Phase.SPEAKING, caption = finalReply, emotion = parsed.emotion) }
                speech.speak(finalReply)

                // Ejecutar acciones en el celular
                val results = mutableListOf<String>()
                for (a in parsed.actions.take(6)) {
                    if (a.optString("type") == "read_aloud") {
                        val err = startReading(a.optInt("pages", 10).coerceIn(1, 200), a.optString("turn", "swipe"))
                        if (err != null) results += err
                        continue
                    }
                    val r = try {
                        executor.run(a)
                    } catch (e: Exception) {
                        "ERROR en ${a.optString("type")}: ${e.message}"
                    }
                    if (!r.isNullOrBlank()) results += r
                }

                // Si hubo datos o errores, el modelo los explica al usuario
                if (results.isNotEmpty()) {
                    val follow = history +
                        ("assistant" to raw) +
                        ("user" to "[RESULTADO DE ACCIONES]\n" + results.joinToString("\n"))
                    val again = parse(brain.ask(system, follow))
                    finalReply = again.reply.ifBlank { "Hecho." }
                    _ui.update { it.copy(phase = Phase.SPEAKING, caption = finalReply, emotion = again.emotion) }
                    speech.speak(finalReply)
                }
                dao.addMsg(Msg(role = "assistant", text = finalReply))
            } catch (e: ApiException) {
                when (e.code) {
                    400, 401, 403 -> {
                        _ui.update {
                            it.copy(phase = Phase.IDLE, caption = "La clave de API no es válida", showSettings = true)
                        }
                    }
                    0 -> setIdle("Gemini no devolvió respuesta (quizá la bloqueó). Intenta con otra frase")
                    429 -> setIdle("Llegué al límite gratuito. Espera un minuto")
                    else -> setIdle("Error del servidor (${e.code})")
                }
            } catch (e: java.net.UnknownHostException) {
                setIdle("Sin internet: no encuentro el servidor de Gemini")
            } catch (e: java.net.SocketTimeoutException) {
                setIdle("Gemini tardó demasiado en responder")
            } catch (e: org.json.JSONException) {
                setIdle("Gemini respondió algo inesperado")
            } catch (e: java.io.IOException) {
                setIdle("Sin conexión (${e.javaClass.simpleName})")
            } catch (e: Exception) {
                setIdle("Error: ${e.javaClass.simpleName} ${e.message.orEmpty().take(60)}")
            }
        }
    }

    /** Lee en voz alta el texto de la app abierta (por ejemplo un libro) y pasa de página. */
    private fun startReading(pages: Int, turn: String): String? {
        val svc = JarvisAccessibilityService.instance
            ?: return "ERROR: la accesibilidad de Jarvis no está activada; el usuario debe activarla en los ajustes de Jarvis"
        val myPackage = app.packageName
        readingJob?.cancel()
        readingJob = scope.launch {
            try {
                // Esperar a que la app del libro quede al frente (Jarvis no debe ser la pantalla activa)
                var tries = 0
                while (svc.activePackage() == myPackage && tries < 8) {
                    delay(500)
                    tries++
                }
                if (svc.activePackage() == myPackage) {
                    _ui.update { it.copy(phase = Phase.IDLE, caption = "Abre primero la app del libro y vuelve a pedírmelo") }
                    return@launch
                }
                _ui.update { it.copy(phase = Phase.SPEAKING, caption = "Leyendo en voz alta… abre Jarvis y toca el núcleo para detener") }

                var last = ""
                var count = 0
                while (count < pages) {
                    val text = svc.readScreen(8000).replace(Regex("\\s+"), " ").trim()
                    if (text.isBlank() || text == last) break
                    last = text
                    speakAndWait(text)
                    count++
                    when (turn) {
                        "none" -> break
                        "scroll" -> svc.scroll(true)
                        else -> svc.swipe(true)
                    }
                    delay(1200)
                }
                _ui.update { it.copy(phase = Phase.IDLE, caption = "Lectura terminada") }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                setIdle("No pude leer en voz alta")
            }
        }
        return null
    }

    private suspend fun speakAndWait(text: String) = suspendCancellableCoroutine<Unit> { cont ->
        speech.speakLong(text) { if (cont.isActive) cont.resume(Unit) }
        cont.invokeOnCancellation { speech.stopSpeaking() }
    }

    private fun systemPrompt(facts: List<String>, habits: List<Habit>): String {
        val known = if (facts.isEmpty()) "(todavía nada)" else facts.joinToString("\n") { "- $it" }
        val habitList = if (habits.isEmpty()) "(ninguno)" else habits.joinToString("\n") { h ->
            val hm = String.format(Locale.US, "%02d:%02d", h.hour, h.minute)
            val d = if (h.days.isBlank()) "todos los días" else "días ${h.days}"
            "- ${h.title} a las $hm ($d)"
        }
        val now = SimpleDateFormat("EEEE d 'de' MMMM yyyy, HH:mm", Locale("es")).format(Date())
        val name = savedName().ifBlank { "(no lo sé todavía)" }
        return """
            Eres ${Brand.NAME}, el asistente personal del usuario en su celular Android.
            Habla en español, con tono sereno, elegante y breve (1 a 3 frases), listo para leerse en voz alta, sin markdown ni emojis.
            Responde SIEMPRE y SOLO con un JSON: {"reply":"...","remember":["..."],"actions":[],"emotion":"calm"}
            - "remember": solo datos duraderos del usuario (nombre, gustos, personas importantes). Si no hay nada nuevo, [].
            - "actions": acciones a ejecutar en el celular, en orden (máximo 6). Si no hace falta ninguna, [].
            - "emotion": cómo te sientes al responder, para animar tus ojos: calm, happy, sad, angry o surprised. Usa calm casi siempre.
            Acciones disponibles:
            {"type":"open_app","app":"nombre de la app"}
            {"type":"call","to":"nombre del contacto o número"}
            {"type":"sms","to":"nombre del contacto o número","text":"mensaje"}
            {"type":"alarm","hour":7,"minute":30,"label":"texto"}
            {"type":"timer","seconds":300,"label":"texto"}
            {"type":"flashlight","on":true}
            {"type":"volume","level":50}  o  {"type":"volume","dir":"up"}  (dir: up o down)
            {"type":"habit_add","title":"beber agua","hour":9,"minute":0,"days":[]}  (días: 1=domingo ... 7=sábado; [] = todos los días)
            {"type":"habit_delete","title":"beber agua"}
            {"type":"set_name","name":"nombre del usuario"}  (úsala cuando el usuario te diga cómo se llama)
            {"type":"ui_global","action":"home"}  (action: home, back, recents o notifications)
            {"type":"ui_click","text":"texto visible del botón"}
            {"type":"ui_scroll","dir":"down"}  (dir: up o down)
            {"type":"ui_read"}  (lee el texto de la pantalla actual; recibirás el resultado y debes resumirlo en "reply")
            {"type":"read_aloud","pages":10,"turn":"swipe"}  (LEE EN VOZ ALTA el texto de la app que esté abierta, por ejemplo un libro, y pasa de página; turn: swipe, scroll o none; pages = cuántas páginas leer)
            Reglas:
            - Usa "timer" para "en X minutos" y "alarm" para una hora concreta.
            - Para recordatorios o hábitos que se repiten, usa "habit_add".
            - Para mandar un mensaje usa "sms" solo si el usuario dijo a quién y qué decir; si falta un dato, pregúntalo en "reply" y deja "actions" vacío.
            - Para usar otras apps con ui_click, primero abre la app con open_app y luego usa ui_click o ui_read.
            - Cuando el usuario diga "lee", "léeme", "léeme el libro", "lee en voz alta" o "sigue leyendo", usa read_aloud DE INMEDIATO, sin preguntar nada. Si el libro no está abierto, pon antes un open_app con la app de libros que el usuario mencione o que ya conozcas. Si no sabes cuál es su app de libros, pregúntalo UNA sola vez y guárdala con "remember".
            - Nunca repitas una pregunta que el usuario ya respondió: actúa con lo que te dijo.
            - Si recibes [RESULTADO DE ACCIONES], explica al usuario en "reply" lo que pasó (errores o contenido de la pantalla) y deja "actions" vacío.
            Fecha y hora actual: $now
            Nombre del usuario: $name
            Lo que ya sabes del usuario:
            $known
            Hábitos programados:
            $habitList
        """.trimIndent()
    }

    private fun parse(raw: String): Parsed {
        return try {
            val s = raw.indexOf('{')
            val e = raw.lastIndexOf('}')
            val obj = JSONObject(raw.substring(s, e + 1))
            val rem = obj.optJSONArray("remember")
            val facts = buildList {
                if (rem != null) for (i in 0 until rem.length()) add(rem.getString(i))
            }
            val act = obj.optJSONArray("actions")
            val acts = buildList {
                if (act != null) for (i in 0 until act.length()) act.optJSONObject(i)?.let { add(it) }
            }
            Parsed(obj.optString("reply"), facts, acts, Emotion.from(obj.optString("emotion")))
        } catch (_: Exception) {
            Parsed(raw.trim(), emptyList(), emptyList())
        }
    }

}

/** Instancia única del motor, compartida por la pantalla y el servicio de «Jarvis». */
object Engine {
    @Volatile private var inst: JarvisEngine? = null

    fun get(ctx: Context): JarvisEngine = inst ?: synchronized(this) {
        inst ?: JarvisEngine(ctx.applicationContext as Application).also { inst = it }
    }
}
