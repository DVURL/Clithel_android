package com.jarvis.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject

enum class Phase { IDLE, LISTENING, THINKING, SPEAKING }

data class UiState(
    val phase: Phase = Phase.IDLE,
    val caption: String = "Toca el núcleo para hablar",
    val askKey: Boolean = false,
)

class JarvisViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private val dao = Room.databaseBuilder(app, AppDb::class.java, "jarvis.db").build().dao()
    private val claude = ClaudeClient { prefs.getString("key", "").orEmpty() }

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private val speech = SpeechManager(
        app,
        onHeard = { text -> onHeard(text) },
        onFail = { msg -> setIdle(msg) },
        onSpeechEnd = { _ui.update { it.copy(phase = Phase.IDLE) } },
    )

    private fun hasKey() = !prefs.getString("key", "").isNullOrBlank()

    fun saveKey(key: String) {
        prefs.edit().putString("key", key.trim()).apply()
        _ui.update { it.copy(askKey = false, caption = "Listo. Toca el núcleo para hablar") }
    }

    fun openKeyDialog() = _ui.update { it.copy(askKey = true) }
    fun closeKeyDialog() = _ui.update { it.copy(askKey = false) }
    fun setCaption(text: String) = _ui.update { it.copy(caption = text) }

    private fun setIdle(msg: String) = _ui.update { it.copy(phase = Phase.IDLE, caption = msg) }

    fun onOrbTap() {
        if (!hasKey()) { openKeyDialog(); return }
        when (_ui.value.phase) {
            Phase.IDLE -> {
                _ui.update { it.copy(phase = Phase.LISTENING, caption = "Te escucho…") }
                speech.listen()
            }
            Phase.SPEAKING -> {
                speech.stopSpeaking()
                _ui.update { it.copy(phase = Phase.IDLE) }
            }
            else -> Unit
        }
    }

    private fun onHeard(text: String) {
        _ui.update { it.copy(phase = Phase.THINKING, caption = text) }
        viewModelScope.launch {
            try {
                val facts = dao.facts()
                val past = dao.lastMsgs(10).reversed()
                val history = past.map { it.role to it.text } + ("user" to text)
                val raw = claude.ask(systemPrompt(facts.map { it.text }), history)

                val (reply, remember) = parse(raw)
                remember.forEach { dao.addFact(Fact(text = it)) }
                dao.addMsg(Msg(role = "user", text = text))
                dao.addMsg(Msg(role = "assistant", text = reply))

                _ui.update { it.copy(phase = Phase.SPEAKING, caption = reply) }
                speech.speak(reply)
            } catch (e: ApiException) {
                if (e.code == 401) {
                    _ui.update { it.copy(phase = Phase.IDLE, caption = "La clave de API no es válida", askKey = true) }
                } else setIdle("Error del servidor (${e.code})")
            } catch (e: Exception) {
                setIdle("No pude conectarme")
            }
        }
    }

    private fun systemPrompt(facts: List<String>): String {
        val known = if (facts.isEmpty()) "(todavía nada)" else facts.joinToString("\n") { "- $it" }
        return """
            Eres JARVIS, el asistente personal del usuario en su celular Android.
            Habla en español, con tono sereno, elegante y breve (1 a 3 frases), listo para leerse en voz alta, sin markdown ni emojis.
            Responde SIEMPRE y SOLO con un JSON: {"reply":"...","remember":["..."]}
            En "remember" pon únicamente datos duraderos del usuario que valga la pena recordar (nombre, gustos, rutinas, personas importantes). Si no hay nada nuevo, usa [].
            Lo que ya sabes del usuario:
            $known
        """.trimIndent()
    }

    private fun parse(raw: String): Pair<String, List<String>> {
        return try {
            val s = raw.indexOf('{')
            val e = raw.lastIndexOf('}')
            val obj = JSONObject(raw.substring(s, e + 1))
            val arr = obj.optJSONArray("remember")
            val facts = buildList { if (arr != null) for (i in 0 until arr.length()) add(arr.getString(i)) }
            obj.getString("reply") to facts
        } catch (_: Exception) {
            raw.trim() to emptyList()
        }
    }

    override fun onCleared() {
        speech.shutdown()
    }
}
