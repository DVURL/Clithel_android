package com.jarvis.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.StateFlow

class JarvisViewModel(app: Application) : AndroidViewModel(app) {
    private val engine = Engine.get(app)

    val ui: StateFlow<UiState> = engine.ui
    val level: StateFlow<Float> = engine.level

    fun onOrbTap() = engine.onOrbTap()
    fun setCaption(text: String) = engine.setCaption(text)
    fun openSettings() = engine.openSettings()
    fun closeSettings() = engine.closeSettings()
    fun hasKey(): Boolean = engine.hasKey()
    fun savedName(): String = engine.savedName()
    fun hasWakeKey(): Boolean = engine.hasWakeKey()
    fun wakeEnabled(): Boolean = engine.wakeEnabled()
    fun saveSettings(key: String, name: String, wakeKey: String) = engine.saveSettings(key, name, wakeKey)
    fun setWake(enabled: Boolean, wakeKey: String): Boolean = engine.setWake(enabled, wakeKey)
}
