package com.jarvis.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Phase { IDLE, LISTENING, THINKING, SPEAKING }

data class UiState(
    val phase: Phase = Phase.IDLE,
    val caption: String = "Toca el núcleo para hablar",
    val showSettings: Boolean = false,
)

private data class Parsed(val reply: String, val remember: List<String>, val actions: List<JSONObject>)

class JarvisViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private val dao = Db.get(app).dao()
    private val brain = GeminiClient { prefs.getString("key", "").orEmpty() }
    private val executor = ActionExecutor(app, prefs, dao)

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()

    private val speech = SpeechManager(
        app,
        onHeard = { text -> onHeard(text) },
        onFail = { msg -> setIdle(msg) },
        onSpeechEnd = { _ui.update { it.copy(phase = Phase.IDLE) } },
        onLevel = { l -> _level.value = l },
    )

    fun hasKey(): Boolean = !prefs.getString("key", "").isNullOrBlank()
    fun savedName(): String = prefs.getString("name", "").orEmpty()

    fun saveSettings(key: String, name: String) {
        val e = prefs.edit()
        if (key.isNotBlank()) e.putString("key", key.trim())
        e.putString("name", name.trim())
        e.apply()
        _ui.update { it.copy(showSettings = false, caption = "Listo. Toca el núcleo para hablar") }
    }

    fun openSettings() = _ui.update { it.copy(showSettings = true) }
    fun closeSettings() = _ui.update { it.copy(showSettings = false) }
    fun setCaption(text: String) = _ui.update { it.copy(caption = text) }

    private fun setIdle(msg: String) = _ui.update { it.copy(phase = Phase.IDLE, caption = msg) }

    fun onOrbTap() {
        if (!hasKey()) { openSettings(); return }
        when (_ui.value.phase) {
            Phase.IDLE -> {
                _ui.update { it.copy(phase = Phase.LISTENING, caption = "Te escucho…") }
                speech.listen()
            }
            Phase.SPEAKING -> {
                speech.stopSpeaking()
                _ui.update { it.copy(phase = Phase.IDLE) }
            }
            else -> Unit
        }
    }

    private fun onHeard(text: String) {
        _ui.update { it.copy(phase = Phase.THINKING, caption = text) }
        viewModelScope.launch {
            try {
                val facts = dao.facts().map { it.text }
                val habits = dao.habits()
                val system = systemPrompt(facts, habits)
                val past = dao.lastMsgs(10).reversed()
                val history = past.map { it.role to it.text } + ("user" to text)

                val raw = brain.ask(system, history)
                val parsed = parse(raw)
                parsed.remember.forEach { dao.addFact(Fact(text = it)) }
                dao.addMsg(Msg(role = "user", text = text))

                var finalReply = parsed.reply.ifBlank { if (parsed.actions.isEmpty()) "Dime más." else "Hecho." }
                _ui.update { it.copy(phase = Phase.SPEAKING, caption = finalReply) }
                speech.speak(finalReply)

                // Ejecutar acciones en el celular
                val results = mutableListOf<String>()
                for (a in parsed.actions.take(6)) {
                    val r = try {
                        executor.run(a)
                    } catch (e: Exception) {
                        "ERROR en ${a.optString("type")}: ${e.message}"
                    }
                    if (!r.isNullOrBlank()) results += r
                }

                // Si hubo datos o errores, el modelo los explica al usuario
                if (results.isNotEmpty()) {
                    val follow = history +
                        ("assistant" to raw) +
                        ("user" to "[RESULTADO DE ACCIONES]\n" + results.joinToString("\n"))
                    val again = parse(brain.ask(system, follow))
                    finalReply = again.reply.ifBlank { "Hecho." }
                    _ui.update { it.copy(phase = Phase.SPEAKING, caption = finalReply) }
                    speech.speak(finalReply)
                }
                dao.addMsg(Msg(role = "assistant", text = finalReply))
            } catch (e: ApiException) {
                when (e.code) {
                    400, 401, 403 -> {
                        _ui.update {
                            it.copy(phase = Phase.IDLE, caption = "La clave de API no es válida", showSettings = true)
                        }
                    }
                    429 -> setIdle("Llegué al límite gratuito. Espera un minuto")
                    else -> setIdle("Error del servidor (${e.code})")
                }
            } catch (e: Exception) {
                setIdle("No pude conectarme")
            }
        }
    }

    private fun systemPrompt(facts: List<String>, habits: List<Habit>): String {
        val known = if (facts.isEmpty()) "(todavía nada)" else facts.joinToString("\n") { "- $it" }
        val habitList = if (habits.isEmpty()) "(ninguno)" else habits.joinToString("\n") { h ->
            val hm = String.format(Locale.US, "%02d:%02d", h.hour, h.minute)
            val d = if (h.days.isBlank()) "todos los días" else "días ${h.days}"
            "- ${h.title} a las $hm ($d)"
        }
        val now = SimpleDateFormat("EEEE d 'de' MMMM yyyy, HH:mm", Locale("es")).format(Date())
        val name = savedName().ifBlank { "(no lo sé todavía)" }
        return """
            Eres JARVIS, el asistente personal del usuario en su celular Android.
            Habla en español, con tono sereno, elegante y breve (1 a 3 frases), listo para leerse en voz alta, sin markdown ni emojis.
            Responde SIEMPRE y SOLO con un JSON: {"reply":"...","remember":["..."],"actions":[]}
            - "remember": solo datos duraderos del usuario (nombre, gustos, personas importantes). Si no hay nada nuevo, [].
            - "actions": acciones a ejecutar en el celular, en orden (máximo 6). Si no hace falta ninguna, [].
            Acciones disponibles:
            {"type":"open_app","app":"nombre de la app"}
            {"type":"call","to":"nombre del contacto o número"}
            {"type":"sms","to":"nombre del contacto o número","text":"mensaje"}
            {"type":"alarm","hour":7,"minute":30,"label":"texto"}
            {"type":"timer","seconds":300,"label":"texto"}
            {"type":"flashlight","on":true}
            {"type":"volume","level":50}  o  {"type":"volume","dir":"up"}  (dir: up o down)
            {"type":"habit_add","title":"beber agua","hour":9,"minute":0,"days":[]}  (días: 1=domingo ... 7=sábado; [] = todos los días)
            {"type":"habit_delete","title":"beber agua"}
            {"type":"set_name","name":"nombre del usuario"}  (úsala cuando el usuario te diga cómo se llama)
            {"type":"ui_global","action":"home"}  (action: home, back, recents o notifications)
            {"type":"ui_click","text":"texto visible del botón"}
            {"type":"ui_scroll","dir":"down"}  (dir: up o down)
            {"type":"ui_read"}  (lee el texto de la pantalla actual; recibirás el resultado y debes resumirlo en "reply")
            Reglas:
            - Usa "timer" para "en X minutos" y "alarm" para una hora concreta.
            - Para recordatorios o hábitos que se repiten, usa "habit_add".
            - Para mandar un mensaje usa "sms" solo si el usuario dijo a quién y qué decir; si falta un dato, pregúntalo en "reply" y deja "actions" vacío.
            - Para usar otras apps con ui_click, primero abre la app con open_app y luego usa ui_click o ui_read.
            - Si recibes [RESULTADO DE ACCIONES], explica al usuario en "reply" lo que pasó (errores o contenido de la pantalla) y deja "actions" vacío.
            Fecha y hora actual: $now
            Nombre del usuario: $name
            Lo que ya sabes del usuario:
            $known
            Hábitos programados:
            $habitList
        """.trimIndent()
    }

    private fun parse(raw: String): Parsed {
        return try {
            val s = raw.indexOf('{')
            val e = raw.lastIndexOf('}')
            val obj = JSONObject(raw.substring(s, e + 1))
            val rem = obj.optJSONArray("remember")
            val facts = buildList {
                if (rem != null) for (i in 0 until rem.length()) add(rem.getString(i))
            }
            val act = obj.optJSONArray("actions")
            val acts = buildList {
                if (act != null) for (i in 0 until act.length()) act.optJSONObject(i)?.let { add(it) }
            }
            Parsed(obj.optString("reply"), facts, acts)
        } catch (_: Exception) {
            Parsed(raw.trim(), emptyList(), emptyList())
        }
    }

    override fun onCleared() {
        speech.shutdown()
    }
}
