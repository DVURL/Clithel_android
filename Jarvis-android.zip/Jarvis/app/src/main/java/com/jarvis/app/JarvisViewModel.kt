package com.jarvis.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.StateFlow

class JarvisViewModel(app: Application) : AndroidViewModel(app) {
    private val engine = Engine.get(app)

    val ui: StateFlow<UiState> = engine.ui
    val level: StateFlow<Float> = engine.level
    val account: StateFlow<AccountUi> = engine.account
    val theme: StateFlow<ThemeSettings> = engine.theme
    val update: StateFlow<UpdateUi> = engine.update
    val aliases: StateFlow<List<AppAlias>> = engine.aliases

    fun onOrbTap() = engine.onOrbTap()
    fun setCaption(text: String) = engine.setCaption(text)
    fun openSettings() = engine.openSettings()
    fun closeSettings() = engine.closeSettings()
    fun hasKey(): Boolean = engine.hasKey()
    fun savedName(): String = engine.savedName()
    fun assistantName(): String = engine.assistantName()
    fun setAssistantName(n: String) = engine.setAssistantName(n)
    fun wakeEnabled(): Boolean = engine.wakeEnabled()
    fun saveSettings(key: String, name: String, assistant: String) = engine.saveSettings(key, name, assistant)
    fun setWake(enabled: Boolean): Boolean = engine.setWake(enabled)

    fun addAlias(alias: String, pkg: String, label: String) = engine.addAlias(alias, pkg, label)
    fun removeAlias(alias: String) = engine.removeAlias(alias)

    fun setTheme(t: ThemeSettings) = engine.setTheme(t)

    fun signUp(email: String, pass: String) = engine.signUp(email, pass)
    fun signIn(email: String, pass: String) = engine.signIn(email, pass)
    fun resetPassword(email: String) = engine.resetPassword(email)
    fun skipAuth() = engine.skipAuth()
    fun showAuth() = engine.showAuth()
    fun signOut() = engine.signOut()
    fun deleteAccount() = engine.deleteAccount()
    fun syncNow() = engine.syncNow()

    fun checkUpdates(manual: Boolean) = engine.checkUpdates(manual)
    fun startUpdate() = engine.startUpdate()
    fun dismissUpdate() = engine.dismissUpdate()
}
