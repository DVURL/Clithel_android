package com.jarvis.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.StateFlow

class JarvisViewModel(app: Application) : AndroidViewModel(app) {
    private val engine = Engine.get(app)

    val ui: StateFlow<UiState> = engine.ui
    val level: StateFlow<Float> = engine.level
    val account: StateFlow<AccountUi> = engine.account
    val theme: StateFlow<ThemeSettings> = engine.theme
    val update: StateFlow<UpdateUi> = engine.update
    val aliases: StateFlow<List<AppAlias>> = engine.aliases
    val wake: StateFlow<WakeUi> = engine.wake
    val diag: StateFlow<String> = engine.diag
    val books: StateFlow<List<Book>> = engine.books
    val reader: StateFlow<ReaderUi> = engine.reader

    fun onOrbTap() = engine.onOrbTap()
    fun setCaption(text: String) = engine.setCaption(text)
    fun openSettings() = engine.openSettings()
    fun closeSettings() = engine.closeSettings()
    fun hasKey(): Boolean = engine.hasKey()
    fun savedName(): String = engine.savedName()
    fun assistantName(): String = engine.assistantName()
    fun setAssistantName(n: String) = engine.setAssistantName(n)
    fun wakeEnabled(): Boolean = engine.wakeEnabled()
    fun saveSettings(key: String, name: String, assistant: String) = engine.saveSettings(key, name, assistant)
    fun setWake(enabled: Boolean) = engine.setWake(enabled)

    fun addAlias(alias: String, pkg: String, label: String) = engine.addAlias(alias, pkg, label)
    fun removeAlias(alias: String) = engine.removeAlias(alias)

    fun setTheme(t: ThemeSettings) = engine.setTheme(t)

    fun addBook(uri: Uri) = engine.addBook(uri)
    fun removeBook(id: String) = engine.removeBook(id)
    fun startBook(id: String) = engine.startBook(id)
    fun readerPause() = engine.readerPause()
    fun readerResume() = engine.readerResume()
    fun readerStop() = engine.readerStop()
    fun readerFaster() = engine.readerRate(0.15f)
    fun readerSlower() = engine.readerRate(-0.15f)

    fun setupDone(): Boolean = engine.setupDone()
    fun markSetupDone() = engine.markSetupDone()

    fun runDiagnostics() = engine.runDiagnostics()
    fun clearDiagnostics() = engine.clearDiagnostics()

    fun signUp(email: String, pass: String) = engine.signUp(email, pass)
    fun signIn(email: String, pass: String) = engine.signIn(email, pass)
    fun resetPassword(email: String) = engine.resetPassword(email)
    fun skipAuth() = engine.skipAuth()
    fun showAuth() = engine.showAuth()
    fun signOut() = engine.signOut()
    fun deleteAccount() = engine.deleteAccount()
    fun syncNow() = engine.syncNow()

    fun checkUpdates(manual: Boolean) = engine.checkUpdates(manual)
    fun startUpdate() = engine.startUpdate()
    fun dismissUpdate() = engine.dismissUpdate()
}
