package com.jarvis.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

enum class Emotion {
    CALM, HAPPY, SAD, ANGRY, SURPRISED;

    companion object {
        fun from(s: String?): Emotion = when (s?.trim()?.lowercase()) {
            "happy", "feliz", "alegre" -> HAPPY
            "sad", "triste" -> SAD
            "angry", "enojado", "molesto" -> ANGRY
            "surprised", "sorprendido" -> SURPRISED
            else -> CALM
        }
    }
}

/** eye = color de los ojos, ring = color de los anillos (ARGB). */
data class EyeStyle(
    val eye: Int,
    val ring: Int,
    val heightFactor: Float,
    val tilt: Float,
    val look: Float,
    val pulse: Float,
)

/** Medidas en unidades "s"; gap = distancia del centro a cada ojo. */
data class EyePose(
    val gap: Float,
    val look: Float,
    val y: Float,
    val w: Float,
    val h: Float,
    val tilt: Float,
)

object Eyes {
    val WHITE = 0xFFF2F7FF.toInt()
    val CYAN = 0xFF00E5FF.toInt()
    val GREEN = 0xFF00FF9C.toInt()
    val AMBER = 0xFFFFB300.toInt()
    val BLUE = 0xFF4DA6FF.toInt()
    val GOLD = 0xFFFFD54F.toInt()
    val VIOLET = 0xFF8C9EFF.toInt()
    val RED = 0xFFFF5252.toInt()
    val ICE = 0xFFB3F5FF.toInt()

    fun style(phase: Phase, emotion: Emotion): EyeStyle = when (phase) {
        Phase.IDLE -> EyeStyle(WHITE, CYAN, 1f, 0f, 0f, 0f)
        Phase.LISTENING -> EyeStyle(GREEN, GREEN, 1.18f, 0f, 0f, 1f)
        Phase.THINKING -> EyeStyle(AMBER, AMBER, 0.92f, 0f, 1f, 0f)
        Phase.SPEAKING -> when (emotion) {
            Emotion.CALM -> EyeStyle(BLUE, BLUE, 1f, 0f, 0f, 1f)
            Emotion.HAPPY -> EyeStyle(GOLD, GOLD, 0.62f, -6f, 0f, 1f)
            Emotion.SAD -> EyeStyle(VIOLET, VIOLET, 0.85f, -16f, 0f, 0.5f)
            Emotion.ANGRY -> EyeStyle(RED, RED, 0.7f, 16f, 0f, 1f)
            Emotion.SURPRISED -> EyeStyle(ICE, ICE, 1.4f, 0f, 0f, 1.2f)
        }
    }

    /** Postura de los ojos en el instante t (segundos), con parpadeo y mirada. */
    fun pose(style: EyeStyle, phase: Phase, t: Float, level: Float): EyePose {
        val w = 0.46f * (1f + 0.25f * level * style.pulse)
        var h = 0.46f * style.heightFactor * (1f + 0.35f * level * style.pulse)

        val bt = t % 4.6f
        if (bt < 0.18f) h *= (1f - 0.92f * sin(PI.toFloat() * bt / 0.18f))
        h = max(h, 0.04f)

        var look = 0f
        var y = 0f
        when (phase) {
            Phase.THINKING -> look = sin(t * 2.2f) * 0.32f * style.look
            Phase.IDLE -> {
                val g = t % 11f
                if (g in 6f..7.4f) {
                    val dir = if ((t / 11f).toInt() % 2 == 0) 1f else -1f
                    look = sin((g - 6f) / 1.4f * PI.toFloat()) * 0.28f * dir
                }
            }
            Phase.SPEAKING -> {
                look = sin(t * 1.5f) * 0.05f
                y = sin(t * 6f) * 0.025f
            }
            Phase.LISTENING -> Unit
        }
        return EyePose(0.55f, look, y, w, h, style.tilt)
    }

    /** Huella de un cuadro, para no redibujar el widget si nada cambió. */
    fun frameKey(style: EyeStyle, p: EyePose): Int {
        var k = style.eye
        k = k * 31 + (p.look * 20).roundToInt()
        k = k * 31 + (p.y * 40).roundToInt()
        k = k * 31 + (p.w * 40).roundToInt()
        k = k * 31 + (p.h * 40).roundToInt()
        k = k * 31 + p.tilt.roundToInt()
        return k
    }

    /** Dibuja los ojos sobre un bitmap transparente (para el widget). */
    fun drawBitmap(b: Bitmap, style: EyeStyle, p: EyePose) {
        val canvas = Canvas(b)
        canvas.drawColor(0, PorterDuff.Mode.CLEAR)
        val w = b.width.toFloat()
        val h = b.height.toFloat()
        val s = min(w * 0.34f, h * 0.62f)
        val cy = h / 2f + p.y * s
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val rgb = style.eye and 0x00FFFFFF

        for (i in 0..1) {
            val sign = if (i == 0) -1f else 1f
            val cx = w / 2f + (sign * p.gap + p.look) * s
            val ew = p.w * s
            val eh = p.h * s

            paint.shader = RadialGradient(cx, cy, s * 0.55f, rgb or 0x66000000, rgb, Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, s * 0.55f, paint)
            paint.shader = null

            paint.color = style.eye
            canvas.save()
            canvas.rotate(if (i == 0) p.tilt else -p.tilt, cx, cy)
            val rect = RectF(cx - ew / 2f, cy - eh / 2f, cx + ew / 2f, cy + eh / 2f)
            val radius = min(ew, eh) / 2f
            canvas.drawRoundRect(rect, radius, radius, paint)
            canvas.restore()
        }
    }
}
